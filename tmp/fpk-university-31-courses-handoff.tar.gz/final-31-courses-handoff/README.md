# FPK University - 31 Courses Handoff Package

## Package Overview

This is the **complete handoff package** for implementing **31 courses** in the FPK University platform using the "Flow Factory" system. This package follows the successful implementation pattern established with the **EL Spelling** course.

**Package Version:** 1.0  
**Date:** October 2025  
**Total Courses:** 31 (AP Irish History excluded)  
**Status:** Ready for Implementation

## What's Included

This package contains everything needed to implement 31 courses:

### 📁 Directory Structure

```
final-31-courses-handoff/
├── README.md                           # This file
├── IMPLEMENTATION_GUIDE.md             # Detailed implementation instructions
├── VERIFICATION_CHECKLIST.md           # QA checklist for testing
├── 31_courses_database.csv             # Database records for all courses
└── manifests/                          # 31 course directories
    ├── writing-composition/
    │   └── manifest.json
    ├── biology-study-of-life/
    │   └── manifest.json
    ├── [... 29 more courses ...]
    └── music-theory-fundamentals/
        └── manifest.json
```

### 📄 Key Files

1. **IMPLEMENTATION_GUIDE.md** - Comprehensive guide covering:
   - Complete course list with categories
   - Step-by-step implementation instructions
   - Framework configuration details
   - Naming conventions
   - Troubleshooting guide

2. **VERIFICATION_CHECKLIST.md** - Quality assurance checklist with:
   - Pre-implementation checks
   - Course-by-course verification
   - System-wide testing procedures
   - Common issues and solutions

3. **31_courses_database.csv** - Database import file containing:
   - Course slugs, titles, descriptions
   - Framework types, difficulty levels
   - Categories, estimated hours
   - Background images, status flags

4. **manifests/** - 31 course directories, each containing:
   - `manifest.json` with complete course structure
   - Lesson definitions with video/audio URLs
   - Content placeholders for course creators

## Quick Start

### For Developers

1. **Read the Implementation Guide**
   ```bash
   cat IMPLEMENTATION_GUIDE.md
   ```

2. **Import the database**
   ```bash
   # Import 31_courses_database.csv into Supabase courses table
   ```

3. **Deploy manifests**
   ```bash
   # Copy each manifest to: src/content/courses/{slug}/manifest.json
   ```

4. **Verify implementation**
   ```bash
   # Use VERIFICATION_CHECKLIST.md to test each course
   ```

### For Project Managers

1. Review the course list in `IMPLEMENTATION_GUIDE.md`
2. Confirm all 31 courses are approved for deployment
3. Verify AP Irish History is intentionally excluded
4. Use `VERIFICATION_CHECKLIST.md` for acceptance testing

## Course Categories

The 31 courses are organized into these categories:

- **Language Arts** (3 courses)
- **Science** (6 courses)
- **Mathematics** (3 courses)
- **History** (4 courses)
- **Social Studies** (3 courses)
- **Technology** (4 courses)
- **World Languages** (3 courses)
- **Arts** (3 courses)
- **Life Skills** (2 courses)
- **Humanities** (1 course)

## Framework Distribution

- **Sequential Learning** (13 courses) - Linear progression, ideal for narrative content
- **Interactive Micro-Learning** (18 courses) - Bite-sized lessons, flexible pacing

## Important Notes

### ⚠️ Critical Information

1. **AP Irish History Excluded**: This course has been intentionally removed from the package, reducing the total from 32 to 31 courses.

2. **Naming Conventions**: Course titles use specific punctuation (colons, ampersands, commas) that must be preserved exactly as shown in the database CSV.

3. **Content Placeholders**: The manifest files contain placeholder content. Actual lesson content will be provided by course creators.

4. **Video/Audio URLs**: URLs follow the standard Supabase storage pattern. Actual media files need to be uploaded to match these URLs.

5. **Framework Compatibility**: Each course is designed for a specific framework (Sequential or Interactive Micro-Learning). Do not change framework types without reviewing course structure.

## Success Criteria

A course is successfully implemented when:

✅ Course appears in the catalog  
✅ Course page loads without errors  
✅ All lessons are accessible  
✅ Video/audio players work  
✅ Navigation functions correctly  
✅ Progress tracking works  
✅ Metadata displays correctly

## Implementation Timeline

Recommended implementation approach:

### Phase 1: Setup (Day 1)
- Import database CSV
- Verify Supabase configuration
- Review all documentation

### Phase 2: Deployment (Days 2-3)
- Deploy manifest files
- Configure frameworks
- Test basic functionality

### Phase 3: Verification (Days 4-5)
- Complete verification checklist
- Test student experience
- Fix any issues found

### Phase 4: Launch (Day 6)
- Final QA review
- Enable course discovery
- Monitor for errors

## Support & Documentation

### Reference Implementation
The **EL Spelling** course serves as the reference implementation for this system. Review its structure and implementation for guidance.

### Documentation Files
- `IMPLEMENTATION_GUIDE.md` - Technical implementation details
- `VERIFICATION_CHECKLIST.md` - Testing procedures
- `31_courses_database.csv` - Database schema and data

### Common Questions

**Q: Why is AP Irish History excluded?**  
A: This course was removed from the package based on project requirements, reducing the total from 32 to 31 courses.

**Q: Can I change the course slugs?**  
A: No. The slugs are used throughout the system and must match exactly between the database, manifest directories, and video/audio URLs.

**Q: What if I need to add custom content?**  
A: The manifest files contain placeholder content. Replace the placeholder text with actual course content while maintaining the JSON structure.

**Q: How do I handle video/audio files?**  
A: Upload media files to Supabase storage following the naming convention: `course-videos/{slug}/lesson-{n}.mp4` and `course-audio/{slug}/lesson-{n}.m4a`

**Q: Can I mix framework types?**  
A: No. Each course is designed for a specific framework. Changing framework types requires restructuring the entire course.

## Technical Requirements

### System Requirements
- Supabase database access
- Supabase storage buckets: `course-videos`, `course-audio`
- React application with course framework components
- JSON manifest parsing capability

### Framework Components Required
- `SequentialCourseShell` - For sequential learning courses
- `MicroLearningCourseShell` - For interactive micro-learning courses

### Database Schema
The courses table must include these fields:
- slug (unique identifier)
- title (course name)
- description (course overview)
- framework_type (sequential | interactive-micro-learning)
- content_version (v2)
- background_image (URL)
- estimated_hours (integer)
- difficulty_level (text)
- status (published)
- category (text)

## Troubleshooting

### Course Not Appearing
1. Check database import was successful
2. Verify status is "published"
3. Confirm slug matches manifest directory

### Manifest Won't Load
1. Validate JSON syntax
2. Check for special characters
3. Verify all required fields are present

### Videos Won't Play
1. Verify Supabase storage URLs
2. Check files exist in storage bucket
3. Confirm file naming matches manifest

For detailed troubleshooting, see the **IMPLEMENTATION_GUIDE.md**.

## Next Steps

1. ✅ Review this README
2. ✅ Read IMPLEMENTATION_GUIDE.md thoroughly
3. ✅ Import 31_courses_database.csv
4. ✅ Deploy manifest files
5. ✅ Complete VERIFICATION_CHECKLIST.md
6. ✅ Launch courses to students

## Contact & Support

For questions about this package:
- Review the EL Spelling course implementation
- Consult the Flow Factory system documentation
- Check the troubleshooting section in IMPLEMENTATION_GUIDE.md

---

**Ready to implement?** Start with the **IMPLEMENTATION_GUIDE.md** for detailed instructions.

**Need to verify?** Use the **VERIFICATION_CHECKLIST.md** for comprehensive testing.

**Questions about data?** Check the **31_courses_database.csv** for course details.

---

*This package represents the culmination of course planning and preparation. All 31 courses are ready for implementation using the proven Flow Factory system.*

