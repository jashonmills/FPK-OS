# FPK University - 31 Courses Implementation Guide

## Overview

This package contains **31 courses** ready for implementation in the FPK University platform using the "Flow Factory" system. This follows the successful implementation pattern established with the **EL Spelling** course.

**Important:** AP Irish History has been removed from this package, reducing the total from 32 to 31 courses.

## Package Contents

```
final-31-courses-handoff/
├── manifests/                          # 31 course directories
│   ├── writing-composition/
│   │   └── manifest.json
│   ├── biology-study-of-life/
│   │   └── manifest.json
│   ├── [... 29 more courses ...]
│   └── music-theory-fundamentals/
│       └── manifest.json
├── 31_courses_database.csv             # Database records for all 31 courses
├── IMPLEMENTATION_GUIDE.md             # This file
└── VERIFICATION_CHECKLIST.md           # Quality assurance checklist
```

## Course List (31 Courses)

### Language Arts (3 courses)
1. **writing-composition** - Writing & Composition: The Complete Essay
2. **creative-writing-short-stories-poetry** - Creative Writing: Short Stories & Poetry
3. **intro-literature-analyzing-fiction** - Introduction to Literature: Analyzing Fiction

### Science (6 courses)
4. **biology-study-of-life** - Biology: The Study of Life
5. **chemistry-central-science** - Chemistry: The Central Science
6. **physics-motion-energy-matter** - Physics: Motion Energy and Matter
7. **earth-science** - Earth Science: Our Planet in Space
8. **ap-biology** - AP Biology

### Mathematics (3 courses)
9. **pre-calculus** - Pre-Calculus
10. **intro-calculus** - Introduction to Calculus
11. **calculus-2-integrals-series** - Calculus II: Integrals & Series

### History (4 courses)
12. **world-history-ancient-modern** - World History: Ancient Civilizations to the Modern Era
13. **us-history-founding-civil-war** - U.S. History: Founding to Civil War
14. **irish-history-union-famine** - Irish History: From the Union to the Great Famine
15. **ap-us-history** - AP U.S. History

### Social Studies (3 courses)
16. **us-government-civics** - U.S. Government & Civics
17. **irish-government-civics** - Irish Government & Civics: Understanding the Republic
18. **introduction-to-psychology** - Introduction to Psychology

### Technology (4 courses)
19. **intro-coding-python** - Introduction to Coding with Python
20. **web-dev-basics** - Web Development Basics (HTML CSS JS)
21. **intro-data-science** - Introduction to Data Science
22. **cybersecurity-fundamentals** - Cybersecurity Fundamentals

### World Languages (3 courses)
23. **spanish-101** - Spanish 101
24. **french-101** - French for Beginners (French 101)
25. **german-101** - German for Beginners (German 101)

### Arts (3 courses)
26. **digital-art-graphic-design** - Digital Art & Graphic Design
27. **intro-drawing-sketching** - Introduction to Drawing & Sketching
28. **music-theory-fundamentals** - Music Theory Fundamentals

### Life Skills (2 courses)
29. **public-speaking-debate** - Public Speaking & Debate
30. **personal-finance-investing** - Personal Finance & Investing

### Humanities (1 course)
31. **introduction-to-philosophy** - Introduction to Philosophy

## Implementation Steps

### Phase 1: Database Setup

1. **Review the database CSV**
   ```bash
   # Location: 31_courses_database.csv
   # Contains: slug, title, description, framework_type, content_version, 
   #           background_image, estimated_hours, difficulty_level, status, category
   ```

2. **Import courses into Supabase**
   - Use the Supabase MCP server or SQL import
   - Table: `courses`
   - All courses have `status: published` and `content_version: v2`

3. **Verify import**
   - Confirm 31 courses are in the database
   - Verify AP Irish History is NOT included

### Phase 2: Manifest Implementation

Each course has a `manifest.json` file with the following structure:

```json
{
  "courseId": "course-slug",
  "courseSlug": "course-slug",
  "contentVersion": "v2",
  "framework": "sequential | interactive-micro-learning | single-content-embed",
  "title": "Course Title",
  "description": "Course description",
  "backgroundImage": "https://...",
  "estimatedHours": 9,
  "difficultyLevel": "High School | University Level | AP / College Level",
  "category": "Category Name",
  "lessons": [...]
}
```

**Implementation for each course:**

1. **Copy manifest to the correct location**
   ```
   src/content/courses/{course-slug}/manifest.json
   ```

2. **Verify framework type**
   - Sequential: 13 courses
   - Interactive Micro-Learning: 18 courses
   - Single Content Embed: 0 courses (none in this batch)

3. **Update video/audio URLs** (if needed)
   - Default structure: `course-videos/{slug}/lesson-{n}.mp4`
   - Default structure: `course-audio/{slug}/lesson-{n}.m4a`

### Phase 3: Framework Configuration

**Sequential Learning Framework (SequentialCourseShell)**
- Used for: Writing & Composition, Creative Writing, World History, etc.
- Features: Linear progression, video+text content, unit grouping

**Interactive Micro-Learning Framework (MicroLearningCourseShell)**
- Used for: Biology, Chemistry, Physics, Math courses, Languages, etc.
- Features: Bite-sized lessons, interactive elements, flexible pacing

### Phase 4: Content Verification

For each course:

1. ✅ Verify manifest.json is valid JSON
2. ✅ Confirm course slug matches directory name
3. ✅ Check video/audio URLs are properly formatted
4. ✅ Verify lesson count matches estimated hours
5. ✅ Confirm framework type matches course structure
6. ✅ Test course loads in the platform

### Phase 5: Quality Assurance

Use the `VERIFICATION_CHECKLIST.md` to ensure:

- All 31 courses are accessible
- No broken links or missing resources
- Proper framework rendering
- Correct metadata display
- Navigation works correctly

## Framework Distribution

| Framework | Count | Courses |
|-----------|-------|---------|
| Sequential | 13 | Writing, History, Arts, Life Skills, Humanities |
| Interactive Micro-Learning | 18 | Science, Math, Technology, Languages |
| Single Content Embed | 0 | None in this batch |

## Naming Conventions

**Critical:** Use the exact naming conventions from the database CSV:

- ✅ **Correct:** "Writing & Composition: The Complete Essay"
- ❌ **Incorrect:** "Writing and Composition - The Complete Essay"

- ✅ **Correct:** "Biology: The Study of Life"
- ❌ **Incorrect:** "Biology - The Study of Life"

The course titles use specific punctuation (colons, ampersands, commas) that must be preserved exactly.

## Removing Old/Duplicate Courses

If there are existing courses that need to be replaced:

1. **Identify duplicates** in the database
2. **Backup existing data** (student progress, enrollments)
3. **Update course references** in related tables
4. **Archive old courses** (don't delete immediately)
5. **Deploy new courses** with proper slugs
6. **Verify student access** is maintained

## Success Criteria

A course is successfully implemented when:

1. ✅ Course appears in the course catalog
2. ✅ Course page loads without errors
3. ✅ All lessons are accessible
4. ✅ Video/audio players work correctly
5. ✅ Navigation between lessons functions
6. ✅ Progress tracking works
7. ✅ Course metadata is correct

## Troubleshooting

### Course doesn't appear in catalog
- Check database import was successful
- Verify `status: published` in database
- Confirm slug matches manifest directory

### Manifest parsing errors
- Validate JSON syntax
- Check for special characters in content
- Verify all required fields are present

### Video/audio not loading
- Confirm Supabase storage URLs are correct
- Check file permissions in storage bucket
- Verify file naming convention

### Framework not rendering correctly
- Confirm framework type in manifest matches database
- Check that the appropriate shell component exists
- Verify lesson structure matches framework requirements

## Support

For implementation questions or issues:
- Review the EL Spelling course as a reference implementation
- Check the VERIFICATION_CHECKLIST.md for common issues
- Consult the Flow Factory system documentation

## Notes

- **AP Irish History** has been intentionally removed from this package
- All courses use `content_version: v2`
- All courses have `status: published`
- Background images are sourced from Unsplash
- Video/audio URLs follow the standard Supabase storage pattern

## Next Steps

After successful implementation:

1. Test each course with a student account
2. Verify enrollment and progress tracking
3. Confirm certificate generation (if applicable)
4. Update course catalog metadata
5. Enable course discovery and search
6. Monitor for any runtime errors

---

**Package Version:** 1.0  
**Date:** October 2025  
**Total Courses:** 31 (excluding AP Irish History)  
**Status:** Ready for Implementation

