# FPK University - 31 Courses Verification Checklist

## Overview

This checklist ensures all 31 courses are properly implemented and functioning correctly in the FPK University platform. Use this document to verify each course before marking the implementation as complete.

## Pre-Implementation Verification

### Package Integrity

- [ ] Confirmed 31 course directories in `manifests/` folder
- [ ] Verified AP Irish History is NOT included
- [ ] Each course directory contains a `manifest.json` file
- [ ] Database CSV contains exactly 31 course records
- [ ] All manifest files are valid JSON (no syntax errors)

### Database Preparation

- [ ] Backed up existing courses table
- [ ] Reviewed course slugs for conflicts with existing courses
- [ ] Confirmed Supabase connection is working
- [ ] Verified storage buckets exist: `course-videos`, `course-audio`

## Course-by-Course Verification

For each of the 31 courses, verify the following:

### 1. Writing & Composition (writing-composition)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 2. Biology: The Study of Life (biology-study-of-life)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 12 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 3. World History (world-history-ancient-modern)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 10 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 4. U.S. Government & Civics (us-government-civics)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 5. Irish Government & Civics (irish-government-civics)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 6. Chemistry (chemistry-central-science)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 12 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 7. Pre-Calculus (pre-calculus)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 10 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 8. Introduction to Coding with Python (intro-coding-python)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 10 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 9. Spanish 101 (spanish-101)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 10. Creative Writing (creative-writing-short-stories-poetry)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 7 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 11. Digital Art & Graphic Design (digital-art-graphic-design)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 12. Physics (physics-motion-energy-matter)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 12 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 13. U.S. History (us-history-founding-civil-war)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 14. Irish History (irish-history-union-famine)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 15. Introduction to Calculus (intro-calculus)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 10 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 16. Web Development Basics (web-dev-basics)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 10 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 17. French 101 (french-101)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 18. Introduction to Literature (intro-literature-analyzing-fiction)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 7 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 19. Public Speaking & Debate (public-speaking-debate)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 7 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 20. Introduction to Data Science (intro-data-science)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 10 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 21. Introduction to Drawing & Sketching (intro-drawing-sketching)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 22. Earth Science (earth-science)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 23. Calculus II (calculus-2-integrals-series)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 12 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 24. AP Biology (ap-biology)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 12 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 25. AP U.S. History (ap-us-history)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 12 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 26. Cybersecurity Fundamentals (cybersecurity-fundamentals)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 27. Personal Finance & Investing (personal-finance-investing)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 28. Introduction to Psychology (introduction-to-psychology)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 7 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 29. Introduction to Philosophy (introduction-to-philosophy)
- [ ] Manifest loads without errors
- [ ] Framework: sequential
- [ ] 7 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 30. German 101 (german-101)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 9 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

### 31. Music Theory Fundamentals (music-theory-fundamentals)
- [ ] Manifest loads without errors
- [ ] Framework: interactive-micro-learning
- [ ] 8 lessons present
- [ ] Course appears in catalog
- [ ] Video/audio URLs are correct
- [ ] Navigation works

## System-Wide Verification

### Course Catalog
- [ ] All 31 courses appear in the catalog
- [ ] Course cards display correct titles
- [ ] Course cards display correct descriptions
- [ ] Background images load correctly
- [ ] Category filters work correctly
- [ ] Difficulty level filters work correctly
- [ ] Search functionality finds courses

### Course Pages
- [ ] Course overview page loads for each course
- [ ] Estimated hours display correctly
- [ ] Difficulty level displays correctly
- [ ] Category displays correctly
- [ ] Enroll button works
- [ ] Course description is readable

### Framework Rendering
- [ ] Sequential courses use SequentialCourseShell
- [ ] Interactive courses use MicroLearningCourseShell
- [ ] Lesson navigation works in both frameworks
- [ ] Progress tracking works in both frameworks
- [ ] Video players work in both frameworks
- [ ] Audio players work in both frameworks

### Student Experience
- [ ] Students can enroll in courses
- [ ] Students can access enrolled courses
- [ ] Students can navigate between lessons
- [ ] Progress is saved correctly
- [ ] Students can resume where they left off
- [ ] Completion tracking works

### Performance
- [ ] Course pages load in < 3 seconds
- [ ] Manifest parsing is efficient
- [ ] No console errors
- [ ] No memory leaks
- [ ] Mobile responsive design works

## Database Verification

### Courses Table
- [ ] Exactly 31 courses in database
- [ ] All slugs are unique
- [ ] All titles match manifest files
- [ ] All framework types are correct
- [ ] All status fields are "published"
- [ ] All content_version fields are "v2"

### Related Tables
- [ ] No orphaned records
- [ ] Foreign key relationships intact
- [ ] Enrollment table works with new courses
- [ ] Progress tracking table works with new courses

## Content Verification

### Manifest Structure
- [ ] All manifests have required fields
- [ ] courseId matches courseSlug
- [ ] courseSlug matches directory name
- [ ] Lesson IDs are sequential
- [ ] Lesson counts match estimated hours
- [ ] Units are properly organized

### Media URLs
- [ ] Video URLs follow naming convention
- [ ] Audio URLs follow naming convention
- [ ] Storage bucket paths are correct
- [ ] File extensions are correct (.mp4, .m4a)

## Common Issues Checklist

### If a course doesn't appear:
- [ ] Check database import was successful
- [ ] Verify status is "published"
- [ ] Confirm slug matches manifest directory
- [ ] Check for typos in slug

### If manifest won't load:
- [ ] Validate JSON syntax
- [ ] Check for special characters
- [ ] Verify all required fields present
- [ ] Check file permissions

### If videos won't play:
- [ ] Verify Supabase storage URLs
- [ ] Check file exists in storage bucket
- [ ] Confirm file naming matches manifest
- [ ] Test URL directly in browser

### If navigation doesn't work:
- [ ] Check lesson IDs are sequential
- [ ] Verify framework type is correct
- [ ] Confirm lesson array is properly formatted
- [ ] Check for JavaScript errors

## Final Sign-Off

### Implementation Complete
- [ ] All 31 courses verified
- [ ] No critical errors found
- [ ] All frameworks working correctly
- [ ] Student experience tested
- [ ] Performance acceptable
- [ ] Documentation complete

### Deployment Checklist
- [ ] Production database updated
- [ ] Manifest files deployed
- [ ] Cache cleared
- [ ] CDN updated (if applicable)
- [ ] Monitoring enabled
- [ ] Rollback plan prepared

### Post-Deployment
- [ ] Monitor error logs for 24 hours
- [ ] Check user enrollment metrics
- [ ] Verify no broken links reported
- [ ] Confirm search indexing updated
- [ ] Update course catalog cache

---

**Verification Date:** __________  
**Verified By:** __________  
**Status:** ☐ Passed ☐ Failed ☐ Needs Review  
**Notes:**

---

## Quick Reference

**Total Courses:** 31  
**Sequential Framework:** 13 courses  
**Interactive Micro-Learning:** 18 courses  
**Excluded:** AP Irish History  

**Key Files:**
- `31_courses_database.csv` - Database import file
- `manifests/{slug}/manifest.json` - Course content structure
- `IMPLEMENTATION_GUIDE.md` - Detailed implementation instructions

