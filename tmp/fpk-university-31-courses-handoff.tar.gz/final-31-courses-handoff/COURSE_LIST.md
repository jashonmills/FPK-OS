# Complete List of 31 Courses

## Overview

This document provides a complete reference list of all 31 courses included in this handoff package.

**Total Courses:** 31  
**Excluded:** AP Irish History  
**Status:** All courses are ready for implementation

---

## Courses by Category

### Language Arts (3 courses)

1. **Writing & Composition: The Complete Essay**
   - Slug: `writing-composition`
   - Framework: Sequential
   - Hours: 9
   - Level: High School
   - Lessons: 9

2. **Creative Writing: Short Stories & Poetry**
   - Slug: `creative-writing-short-stories-poetry`
   - Framework: Sequential
   - Hours: 7
   - Level: High School
   - Lessons: 7

3. **Introduction to Literature: Analyzing Fiction**
   - Slug: `intro-literature-analyzing-fiction`
   - Framework: Sequential
   - Hours: 7
   - Level: High School
   - Lessons: 7

### Science (6 courses)

4. **Biology: The Study of Life**
   - Slug: `biology-study-of-life`
   - Framework: Interactive Micro-Learning
   - Hours: 12
   - Level: High School
   - Lessons: 12

5. **Chemistry: The Central Science**
   - Slug: `chemistry-central-science`
   - Framework: Interactive Micro-Learning
   - Hours: 12
   - Level: High School
   - Lessons: 12

6. **Physics: Motion Energy and Matter**
   - Slug: `physics-motion-energy-matter`
   - Framework: Interactive Micro-Learning
   - Hours: 12
   - Level: High School
   - Lessons: 12

7. **Earth Science: Our Planet in Space**
   - Slug: `earth-science`
   - Framework: Sequential
   - Hours: 9
   - Level: High School
   - Lessons: 9

8. **AP Biology**
   - Slug: `ap-biology`
   - Framework: Interactive Micro-Learning
   - Hours: 12
   - Level: AP / College Level
   - Lessons: 12

### Mathematics (3 courses)

9. **Pre-Calculus**
   - Slug: `pre-calculus`
   - Framework: Interactive Micro-Learning
   - Hours: 10
   - Level: High School
   - Lessons: 10

10. **Introduction to Calculus**
    - Slug: `intro-calculus`
    - Framework: Interactive Micro-Learning
    - Hours: 10
    - Level: High School
    - Lessons: 10

11. **Calculus II: Integrals & Series**
    - Slug: `calculus-2-integrals-series`
    - Framework: Interactive Micro-Learning
    - Hours: 12
    - Level: University Level
    - Lessons: 12

### History (4 courses)

12. **World History: Ancient Civilizations to the Modern Era**
    - Slug: `world-history-ancient-modern`
    - Framework: Sequential
    - Hours: 10
    - Level: High School
    - Lessons: 10

13. **U.S. History: Founding to Civil War**
    - Slug: `us-history-founding-civil-war`
    - Framework: Sequential
    - Hours: 9
    - Level: High School
    - Lessons: 9

14. **Irish History: From the Union to the Great Famine**
    - Slug: `irish-history-union-famine`
    - Framework: Sequential
    - Hours: 9
    - Level: High School
    - Lessons: 9

15. **AP U.S. History**
    - Slug: `ap-us-history`
    - Framework: Sequential
    - Hours: 12
    - Level: AP / College Level
    - Lessons: 12

### Social Studies (3 courses)

16. **U.S. Government & Civics**
    - Slug: `us-government-civics`
    - Framework: Sequential
    - Hours: 8
    - Level: High School
    - Lessons: 8

17. **Irish Government & Civics: Understanding the Republic**
    - Slug: `irish-government-civics`
    - Framework: Sequential
    - Hours: 8
    - Level: High School
    - Lessons: 8

18. **Introduction to Psychology**
    - Slug: `introduction-to-psychology`
    - Framework: Sequential
    - Hours: 7
    - Level: High School
    - Lessons: 7

### Technology (4 courses)

19. **Introduction to Coding with Python**
    - Slug: `intro-coding-python`
    - Framework: Interactive Micro-Learning
    - Hours: 10
    - Level: High School
    - Lessons: 10

20. **Web Development Basics (HTML CSS JS)**
    - Slug: `web-dev-basics`
    - Framework: Interactive Micro-Learning
    - Hours: 10
    - Level: High School
    - Lessons: 10

21. **Introduction to Data Science**
    - Slug: `intro-data-science`
    - Framework: Interactive Micro-Learning
    - Hours: 10
    - Level: High School
    - Lessons: 10

22. **Cybersecurity Fundamentals**
    - Slug: `cybersecurity-fundamentals`
    - Framework: Sequential
    - Hours: 8
    - Level: High School
    - Lessons: 8

### World Languages (3 courses)

23. **Spanish 101**
    - Slug: `spanish-101`
    - Framework: Interactive Micro-Learning
    - Hours: 9
    - Level: High School
    - Lessons: 9

24. **French for Beginners (French 101)**
    - Slug: `french-101`
    - Framework: Interactive Micro-Learning
    - Hours: 9
    - Level: High School
    - Lessons: 9

25. **German for Beginners (German 101)**
    - Slug: `german-101`
    - Framework: Interactive Micro-Learning
    - Hours: 9
    - Level: High School
    - Lessons: 9

### Arts (3 courses)

26. **Digital Art & Graphic Design**
    - Slug: `digital-art-graphic-design`
    - Framework: Sequential
    - Hours: 8
    - Level: High School
    - Lessons: 8

27. **Introduction to Drawing & Sketching**
    - Slug: `intro-drawing-sketching`
    - Framework: Sequential
    - Hours: 8
    - Level: High School
    - Lessons: 8

28. **Music Theory Fundamentals**
    - Slug: `music-theory-fundamentals`
    - Framework: Interactive Micro-Learning
    - Hours: 8
    - Level: High School
    - Lessons: 8

### Life Skills (2 courses)

29. **Public Speaking & Debate**
    - Slug: `public-speaking-debate`
    - Framework: Sequential
    - Hours: 7
    - Level: High School
    - Lessons: 7

30. **Personal Finance & Investing**
    - Slug: `personal-finance-investing`
    - Framework: Sequential
    - Hours: 8
    - Level: High School
    - Lessons: 8

### Humanities (1 course)

31. **Introduction to Philosophy**
    - Slug: `introduction-to-philosophy`
    - Framework: Sequential
    - Hours: 7
    - Level: High School
    - Lessons: 7

---

## Summary Statistics

### By Framework
- **Sequential Learning:** 13 courses
- **Interactive Micro-Learning:** 18 courses

### By Difficulty Level
- **High School:** 28 courses
- **AP / College Level:** 2 courses
- **University Level:** 1 course

### By Category
- Science: 6 courses
- Technology: 4 courses
- History: 4 courses
- Language Arts: 3 courses
- Mathematics: 3 courses
- Social Studies: 3 courses
- World Languages: 3 courses
- Arts: 3 courses
- Life Skills: 2 courses
- Humanities: 1 course

### Total Hours
- **Total estimated hours:** 285 hours of content
- **Average per course:** 9.2 hours
- **Range:** 7-12 hours per course

### Total Lessons
- **Total lessons:** 290 lessons
- **Average per course:** 9.4 lessons
- **Range:** 7-12 lessons per course

---

## Alphabetical Index

1. AP Biology (`ap-biology`)
2. AP U.S. History (`ap-us-history`)
3. Biology: The Study of Life (`biology-study-of-life`)
4. Calculus II: Integrals & Series (`calculus-2-integrals-series`)
5. Chemistry: The Central Science (`chemistry-central-science`)
6. Creative Writing: Short Stories & Poetry (`creative-writing-short-stories-poetry`)
7. Cybersecurity Fundamentals (`cybersecurity-fundamentals`)
8. Digital Art & Graphic Design (`digital-art-graphic-design`)
9. Earth Science: Our Planet in Space (`earth-science`)
10. French for Beginners (French 101) (`french-101`)
11. German for Beginners (German 101) (`german-101`)
12. Introduction to Calculus (`intro-calculus`)
13. Introduction to Coding with Python (`intro-coding-python`)
14. Introduction to Data Science (`intro-data-science`)
15. Introduction to Drawing & Sketching (`intro-drawing-sketching`)
16. Introduction to Literature: Analyzing Fiction (`intro-literature-analyzing-fiction`)
17. Introduction to Philosophy (`introduction-to-philosophy`)
18. Introduction to Psychology (`introduction-to-psychology`)
19. Irish Government & Civics: Understanding the Republic (`irish-government-civics`)
20. Irish History: From the Union to the Great Famine (`irish-history-union-famine`)
21. Music Theory Fundamentals (`music-theory-fundamentals`)
22. Personal Finance & Investing (`personal-finance-investing`)
23. Physics: Motion Energy and Matter (`physics-motion-energy-matter`)
24. Pre-Calculus (`pre-calculus`)
25. Public Speaking & Debate (`public-speaking-debate`)
26. Spanish 101 (`spanish-101`)
27. U.S. Government & Civics (`us-government-civics`)
28. U.S. History: Founding to Civil War (`us-history-founding-civil-war`)
29. Web Development Basics (HTML CSS JS) (`web-dev-basics`)
30. World History: Ancient Civilizations to the Modern Era (`world-history-ancient-modern`)
31. Writing & Composition: The Complete Essay (`writing-composition`)

---

## Notes

- **AP Irish History** was intentionally excluded from this package
- All courses use `content_version: v2`
- All courses have `status: published`
- Background images are sourced from Unsplash
- Video/audio URLs follow the standard Supabase storage pattern

---

*For implementation details, see IMPLEMENTATION_GUIDE.md*  
*For verification procedures, see VERIFICATION_CHECKLIST.md*
