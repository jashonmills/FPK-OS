import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { CheckCircle, X, Calculator, RotateCcw } from 'lucide-react'

const IdentityExplorer = () => {
  const [selectedCategory, setSelectedCategory] = useState('pythagorean')
  const [testAngle, setTestAngle] = useState(30)
  const [verificationResults, setVerificationResults] = useState({})
  const [showSteps, setShowSteps] = useState({})
  
  const identityCategories = {
    pythagorean: {
      name: 'Pythagorean Identities',
      color: 'bg-blue-500',
      identities: [
        {
          id: 'pyth1',
          name: 'Primary Pythagorean',
          formula: 'sin²(θ) + cos²(θ) = 1',
          leftSide: 'sin²(θ) + cos²(θ)',
          rightSide: '1',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sin = Math.sin(rad)
            const cos = Math.cos(rad)
            return {
              left: sin * sin + cos * cos,
              right: 1,
              steps: [
                `sin(${angle}°) = ${sin.toFixed(4)}`,
                `cos(${angle}°) = ${cos.toFixed(4)}`,
                `sin²(${angle}°) = ${(sin * sin).toFixed(4)}`,
                `cos²(${angle}°) = ${(cos * cos).toFixed(4)}`,
                `sin²(${angle}°) + cos²(${angle}°) = ${(sin * sin + cos * cos).toFixed(4)}`
              ]
            }
          }
        },
        {
          id: 'pyth2',
          name: 'Tangent Pythagorean',
          formula: '1 + tan²(θ) = sec²(θ)',
          leftSide: '1 + tan²(θ)',
          rightSide: 'sec²(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const tan = Math.tan(rad)
            const sec = 1 / Math.cos(rad)
            return {
              left: 1 + tan * tan,
              right: sec * sec,
              steps: [
                `tan(${angle}°) = ${tan.toFixed(4)}`,
                `sec(${angle}°) = ${sec.toFixed(4)}`,
                `tan²(${angle}°) = ${(tan * tan).toFixed(4)}`,
                `1 + tan²(${angle}°) = ${(1 + tan * tan).toFixed(4)}`,
                `sec²(${angle}°) = ${(sec * sec).toFixed(4)}`
              ]
            }
          }
        }
      ]
    },
    quotient: {
      name: 'Quotient Identities',
      color: 'bg-green-500',
      identities: [
        {
          id: 'quot1',
          name: 'Tangent Quotient',
          formula: 'tan(θ) = sin(θ)/cos(θ)',
          leftSide: 'tan(θ)',
          rightSide: 'sin(θ)/cos(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sin = Math.sin(rad)
            const cos = Math.cos(rad)
            const tan = Math.tan(rad)
            return {
              left: tan,
              right: sin / cos,
              steps: [
                `sin(${angle}°) = ${sin.toFixed(4)}`,
                `cos(${angle}°) = ${cos.toFixed(4)}`,
                `tan(${angle}°) = ${tan.toFixed(4)}`,
                `sin(${angle}°)/cos(${angle}°) = ${(sin / cos).toFixed(4)}`
              ]
            }
          }
        },
        {
          id: 'quot2',
          name: 'Cotangent Quotient',
          formula: 'cot(θ) = cos(θ)/sin(θ)',
          leftSide: 'cot(θ)',
          rightSide: 'cos(θ)/sin(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sin = Math.sin(rad)
            const cos = Math.cos(rad)
            const cot = 1 / Math.tan(rad)
            return {
              left: cot,
              right: cos / sin,
              steps: [
                `sin(${angle}°) = ${sin.toFixed(4)}`,
                `cos(${angle}°) = ${cos.toFixed(4)}`,
                `cot(${angle}°) = ${cot.toFixed(4)}`,
                `cos(${angle}°)/sin(${angle}°) = ${(cos / sin).toFixed(4)}`
              ]
            }
          }
        }
      ]
    },
    reciprocal: {
      name: 'Reciprocal Identities',
      color: 'bg-purple-500',
      identities: [
        {
          id: 'recip1',
          name: 'Cosecant Reciprocal',
          formula: 'csc(θ) = 1/sin(θ)',
          leftSide: 'csc(θ)',
          rightSide: '1/sin(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sin = Math.sin(rad)
            const csc = 1 / sin
            return {
              left: csc,
              right: 1 / sin,
              steps: [
                `sin(${angle}°) = ${sin.toFixed(4)}`,
                `csc(${angle}°) = 1/sin(${angle}°) = ${csc.toFixed(4)}`
              ]
            }
          }
        },
        {
          id: 'recip2',
          name: 'Secant Reciprocal',
          formula: 'sec(θ) = 1/cos(θ)',
          leftSide: 'sec(θ)',
          rightSide: '1/cos(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const cos = Math.cos(rad)
            const sec = 1 / cos
            return {
              left: sec,
              right: 1 / cos,
              steps: [
                `cos(${angle}°) = ${cos.toFixed(4)}`,
                `sec(${angle}°) = 1/cos(${angle}°) = ${sec.toFixed(4)}`
              ]
            }
          }
        }
      ]
    },
    evenOdd: {
      name: 'Even-Odd Identities',
      color: 'bg-orange-500',
      identities: [
        {
          id: 'even1',
          name: 'Cosine Even',
          formula: 'cos(-θ) = cos(θ)',
          leftSide: 'cos(-θ)',
          rightSide: 'cos(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const cosPos = Math.cos(rad)
            const cosNeg = Math.cos(-rad)
            return {
              left: cosNeg,
              right: cosPos,
              steps: [
                `cos(${angle}°) = ${cosPos.toFixed(4)}`,
                `cos(-${angle}°) = ${cosNeg.toFixed(4)}`,
                `cos(-θ) = cos(θ) ✓`
              ]
            }
          }
        },
        {
          id: 'odd1',
          name: 'Sine Odd',
          formula: 'sin(-θ) = -sin(θ)',
          leftSide: 'sin(-θ)',
          rightSide: '-sin(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sinPos = Math.sin(rad)
            const sinNeg = Math.sin(-rad)
            return {
              left: sinNeg,
              right: -sinPos,
              steps: [
                `sin(${angle}°) = ${sinPos.toFixed(4)}`,
                `sin(-${angle}°) = ${sinNeg.toFixed(4)}`,
                `-sin(${angle}°) = ${(-sinPos).toFixed(4)}`,
                `sin(-θ) = -sin(θ) ✓`
              ]
            }
          }
        }
      ]
    },
    doubleAngle: {
      name: 'Double Angle Identities',
      color: 'bg-red-500',
      identities: [
        {
          id: 'double1',
          name: 'Sine Double Angle',
          formula: 'sin(2θ) = 2sin(θ)cos(θ)',
          leftSide: 'sin(2θ)',
          rightSide: '2sin(θ)cos(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sin = Math.sin(rad)
            const cos = Math.cos(rad)
            const sin2 = Math.sin(2 * rad)
            return {
              left: sin2,
              right: 2 * sin * cos,
              steps: [
                `sin(${angle}°) = ${sin.toFixed(4)}`,
                `cos(${angle}°) = ${cos.toFixed(4)}`,
                `sin(${2 * angle}°) = ${sin2.toFixed(4)}`,
                `2sin(${angle}°)cos(${angle}°) = ${(2 * sin * cos).toFixed(4)}`
              ]
            }
          }
        },
        {
          id: 'double2',
          name: 'Cosine Double Angle',
          formula: 'cos(2θ) = cos²(θ) - sin²(θ)',
          leftSide: 'cos(2θ)',
          rightSide: 'cos²(θ) - sin²(θ)',
          calculate: (angle) => {
            const rad = (angle * Math.PI) / 180
            const sin = Math.sin(rad)
            const cos = Math.cos(rad)
            const cos2 = Math.cos(2 * rad)
            return {
              left: cos2,
              right: cos * cos - sin * sin,
              steps: [
                `sin(${angle}°) = ${sin.toFixed(4)}`,
                `cos(${angle}°) = ${cos.toFixed(4)}`,
                `cos(${2 * angle}°) = ${cos2.toFixed(4)}`,
                `cos²(${angle}°) - sin²(${angle}°) = ${(cos * cos - sin * sin).toFixed(4)}`
              ]
            }
          }
        }
      ]
    }
  }
  
  const verifyIdentity = (identity) => {
    try {
      const result = identity.calculate(testAngle)
      const isValid = Math.abs(result.left - result.right) < 0.0001
      
      setVerificationResults(prev => ({
        ...prev,
        [identity.id]: {
          isValid,
          leftValue: result.left,
          rightValue: result.right,
          steps: result.steps
        }
      }))
    } catch (error) {
      setVerificationResults(prev => ({
        ...prev,
        [identity.id]: {
          isValid: false,
          error: 'Calculation error (possibly undefined)'
        }
      }))
    }
  }
  
  const verifyAllInCategory = () => {
    const category = identityCategories[selectedCategory]
    category.identities.forEach(identity => {
      verifyIdentity(identity)
    })
  }
  
  const resetVerification = () => {
    setVerificationResults({})
    setShowSteps({})
  }
  
  const toggleSteps = (identityId) => {
    setShowSteps(prev => ({
      ...prev,
      [identityId]: !prev[identityId]
    }))
  }
  
  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-6 w-6" />
          Interactive Identity Explorer
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Controls */}
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Label>Identity Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(identityCategories).map(([key, category]) => (
                    <SelectItem key={key} value={key}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Test Angle (degrees)</Label>
              <Input
                type="number"
                value={testAngle}
                onChange={(e) => setTestAngle(parseFloat(e.target.value) || 0)}
                className="mt-1"
              />
            </div>
            
            <div className="flex items-end gap-2">
              <Button onClick={verifyAllInCategory} className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                Verify All
              </Button>
              <Button onClick={resetVerification} variant="outline" className="flex items-center gap-2">
                <RotateCcw className="h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          
          {/* Category Header */}
          <div className="flex items-center gap-3">
            <div className={`w-4 h-4 rounded ${identityCategories[selectedCategory].color}`}></div>
            <h3 className="text-2xl font-bold">{identityCategories[selectedCategory].name}</h3>
          </div>
          
          {/* Identities */}
          <div className="space-y-4">
            {identityCategories[selectedCategory].identities.map((identity) => {
              const result = verificationResults[identity.id]
              
              return (
                <Card key={identity.id} className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{identity.name}</CardTitle>
                        <Badge variant="outline" className="mt-1 text-lg px-3 py-1 font-mono">
                          {identity.formula}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        {result && (
                          <div className={`flex items-center gap-1 ${result.isValid ? 'text-green-600' : 'text-red-600'}`}>
                            {result.isValid ? <CheckCircle className="h-5 w-5" /> : <X className="h-5 w-5" />}
                            <span className="font-semibold">
                              {result.isValid ? 'Verified' : 'Failed'}
                            </span>
                          </div>
                        )}
                        <Button
                          size="sm"
                          onClick={() => verifyIdentity(identity)}
                          variant="outline"
                        >
                          Test
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  {result && (
                    <CardContent>
                      {result.error ? (
                        <Alert>
                          <AlertDescription>{result.error}</AlertDescription>
                        </Alert>
                      ) : (
                        <div className="space-y-3">
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="p-3 bg-blue-50 rounded">
                              <p className="font-semibold text-blue-700">Left Side: {identity.leftSide}</p>
                              <p className="text-blue-600">Value: {result.leftValue.toFixed(6)}</p>
                            </div>
                            <div className="p-3 bg-green-50 rounded">
                              <p className="font-semibold text-green-700">Right Side: {identity.rightSide}</p>
                              <p className="text-green-600">Value: {result.rightValue.toFixed(6)}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleSteps(identity.id)}
                            >
                              {showSteps[identity.id] ? 'Hide' : 'Show'} Steps
                            </Button>
                            <span className="text-sm text-gray-600">
                              Difference: {Math.abs(result.leftValue - result.rightValue).toExponential(2)}
                            </span>
                          </div>
                          
                          {showSteps[identity.id] && result.steps && (
                            <div className="p-3 bg-gray-50 rounded">
                              <h4 className="font-semibold mb-2">Step-by-step calculation:</h4>
                              <div className="space-y-1 font-mono text-sm">
                                {result.steps.map((step, index) => (
                                  <div key={index}>{step}</div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>
              )
            })}
          </div>
          
          {/* Information Panel */}
          <Card className="bg-indigo-50 border-indigo-200">
            <CardHeader>
              <CardTitle className="text-indigo-700">How to Use This Explorer</CardTitle>
            </CardHeader>
            <CardContent className="text-indigo-700">
              <div className="space-y-2 text-sm">
                <p>1. <strong>Select a category</strong> to explore different types of identities</p>
                <p>2. <strong>Enter a test angle</strong> to verify the identities numerically</p>
                <p>3. <strong>Click "Test"</strong> for individual identities or "Verify All" for the entire category</p>
                <p>4. <strong>View the steps</strong> to see detailed calculations</p>
                <p>5. <strong>Try different angles</strong> to build confidence in the identities</p>
                <p className="mt-3 font-semibold">Remember: Identities are true for ALL valid angle values!</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}

export default IdentityExplorer

