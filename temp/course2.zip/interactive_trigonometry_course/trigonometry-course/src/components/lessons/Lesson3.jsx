export default function Lesson3() { return <div>Lesson 3 - Coming Soon</div> }
