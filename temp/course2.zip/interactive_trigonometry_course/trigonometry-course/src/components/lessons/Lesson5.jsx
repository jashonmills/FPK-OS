export default function Lesson5() { return <div>Lesson 5 - Coming Soon</div> }
