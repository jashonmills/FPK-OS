import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { ArrowLeft, Triangle, Calculator, CheckCircle } from 'lucide-react'
import TriangleSolver from '../interactive/TriangleSolver.jsx'

const Lesson1 = ({ onComplete, onBack }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())
  
  const sections = [
    {
      id: 'introduction',
      title: 'Introduction to Trigonometry',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-blue-600 mb-4">Welcome to the World of Trigonometry!</h3>
            <p className="text-lg leading-relaxed">
              Trigonometry is the study of relationships between angles and side lengths of triangles. 
              The name comes from Greek words meaning "triangle measurement." This powerful branch of 
              mathematics helps us solve problems in engineering, physics, astronomy, and many other fields.
            </p>
            <p className="text-lg leading-relaxed">
              In this lesson, we'll focus on right-angled triangles and learn the fundamental ratios 
              that form the foundation of all trigonometry: sine, cosine, and tangent.
            </p>
          </div>
          
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-lg text-blue-700">Real-World Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-blue-700">
                <li>• <strong>Architecture:</strong> Calculating roof slopes and building heights</li>
                <li>• <strong>Navigation:</strong> Finding distances and directions</li>
                <li>• <strong>Engineering:</strong> Designing bridges and structures</li>
                <li>• <strong>Astronomy:</strong> Measuring distances to stars</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 'sohcahtoa',
      title: 'SOHCAHTOA - The Key to Trigonometry',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-green-600 mb-4">Understanding SOHCAHTOA</h3>
            <p className="text-lg leading-relaxed">
              SOHCAHTOA is a mnemonic device that helps us remember the three fundamental trigonometric ratios. 
              Let's break it down:
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-700">SOH</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-green-700">Sine = Opposite / Hypotenuse</p>
                <p className="text-sm text-green-600 mt-2">
                  The sine of an angle is the ratio of the opposite side to the hypotenuse.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-700">CAH</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-purple-700">Cosine = Adjacent / Hypotenuse</p>
                <p className="text-sm text-purple-600 mt-2">
                  The cosine of an angle is the ratio of the adjacent side to the hypotenuse.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-700">TOA</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-blue-700">Tangent = Opposite / Adjacent</p>
                <p className="text-sm text-blue-600 mt-2">
                  The tangent of an angle is the ratio of the opposite side to the adjacent side.
                </p>
              </CardContent>
            </Card>
          </div>
          
          <Card className="bg-yellow-50 border-yellow-200">
            <CardHeader>
              <CardTitle className="text-yellow-700">Triangle Parts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-yellow-700">
                <p><strong>Hypotenuse:</strong> The longest side, opposite the right angle</p>
                <p><strong>Opposite:</strong> The side across from the angle we're considering</p>
                <p><strong>Adjacent:</strong> The side next to the angle we're considering (not the hypotenuse)</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 'interactive',
      title: 'Interactive Triangle Solver',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-purple-600 mb-4">Practice with the Triangle Solver</h3>
            <p className="text-lg leading-relaxed">
              Now let's put SOHCAHTOA into practice! Use the interactive triangle solver below to 
              explore how the trigonometric ratios work. Try entering different values and see 
              how the calculator uses SOHCAHTOA to find the missing sides.
            </p>
          </div>
          
          <TriangleSolver />
          
          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-700">Try These Examples:</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-green-700">
                <p>1. Set angle to 30° and hypotenuse to 10. What are the opposite and adjacent sides?</p>
                <p>2. Set angle to 45° and opposite to 5. What are the hypotenuse and adjacent sides?</p>
                <p>3. Set angle to 60° and adjacent to 8. What are the hypotenuse and opposite sides?</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 'applications',
      title: 'Real-World Problem Solving',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-orange-600 mb-4">Solving Real Problems</h3>
            <p className="text-lg leading-relaxed">
              Trigonometry shines when we need to find measurements that are difficult or impossible 
              to measure directly. Let's look at some practical examples.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-orange-50 border-orange-200">
              <CardHeader>
                <CardTitle className="text-orange-700">Example 1: Building Height</CardTitle>
              </CardHeader>
              <CardContent className="text-orange-700">
                <p className="mb-3">
                  You're standing 50 meters from a building and measure the angle of elevation 
                  to the top as 35°. How tall is the building?
                </p>
                <div className="bg-white p-3 rounded border">
                  <p className="font-mono text-sm">
                    tan(35°) = opposite / adjacent<br/>
                    tan(35°) = height / 50<br/>
                    height = 50 × tan(35°)<br/>
                    height ≈ 50 × 0.7002 ≈ 35 meters
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-700">Example 2: Ladder Safety</CardTitle>
              </CardHeader>
              <CardContent className="text-blue-700">
                <p className="mb-3">
                  A 12-foot ladder leans against a wall at a 70° angle. How high up the wall 
                  does it reach?
                </p>
                <div className="bg-white p-3 rounded border">
                  <p className="font-mono text-sm">
                    sin(70°) = opposite / hypotenuse<br/>
                    sin(70°) = height / 12<br/>
                    height = 12 × sin(70°)<br/>
                    height ≈ 12 × 0.9397 ≈ 11.3 feet
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    }
  ]
  
  const handleSectionComplete = (sectionIndex) => {
    setCompletedSections(prev => new Set([...prev, sectionIndex]))
    if (sectionIndex < sections.length - 1) {
      setCurrentSection(sectionIndex + 1)
    }
  }
  
  const progress = ((completedSections.size) / sections.length) * 100
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Course
          </Button>
          <Badge variant="outline" className="text-lg px-4 py-2">
            Lesson 1 of 8
          </Badge>
        </div>
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Foundation - Right Triangle Trigonometry
          </h1>
          <p className="text-xl text-gray-600">
            Master SOHCAHTOA and basic trigonometric ratios
          </p>
        </div>
        
        {/* Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Triangle className="h-5 w-5" />
              Lesson Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Sections Completed</span>
                <span>{completedSections.size} of {sections.length}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
        
        {/* Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8">
          {sections.map((section, index) => (
            <Button
              key={section.id}
              variant={currentSection === index ? "default" : "outline"}
              size="sm"
              onClick={() => setCurrentSection(index)}
              className="flex items-center gap-2"
            >
              {completedSections.has(index) && <CheckCircle className="h-4 w-4" />}
              {section.title}
            </Button>
          ))}
        </div>
        
        {/* Current Section Content */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">
              {sections[currentSection].title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sections[currentSection].content}
            
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                disabled={currentSection === 0}
              >
                Previous
              </Button>
              
              <div className="flex gap-2">
                {!completedSections.has(currentSection) && (
                  <Button
                    onClick={() => handleSectionComplete(currentSection)}
                    className="flex items-center gap-2"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Mark Complete
                  </Button>
                )}
                
                {currentSection < sections.length - 1 ? (
                  <Button
                    onClick={() => setCurrentSection(currentSection + 1)}
                  >
                    Next
                  </Button>
                ) : completedSections.size === sections.length && (
                  <Button
                    onClick={onComplete}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Complete Lesson
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Lesson1

