export default function Lesson7() { return <div>Lesson 7 - Coming Soon</div> }
