import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { ArrowLeft, Circle, Calculator, CheckCircle } from 'lucide-react'
import UnitCircle from '../interactive/UnitCircle.jsx'

const Lesson2 = ({ onComplete, onBack }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())
  
  const sections = [
    {
      id: 'introduction',
      title: 'Beyond Right Triangles',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-blue-600 mb-4">The Unit Circle Revolution</h3>
            <p className="text-lg leading-relaxed">
              In Lesson 1, we learned about trigonometry using right triangles, but this approach 
              has a limitation: it only works for angles between 0° and 90°. What if we need to 
              work with larger angles, like 120° or 270°?
            </p>
            <p className="text-lg leading-relaxed">
              The unit circle is our solution! It's a circle with radius 1, centered at the origin 
              of the coordinate plane. This elegant tool allows us to define trigonometric functions 
              for ANY angle, opening up a whole new world of possibilities.
            </p>
          </div>
          
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-lg text-blue-700">Why the Unit Circle?</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-blue-700">
                <li>• <strong>Universal:</strong> Works for any angle, positive or negative</li>
                <li>• <strong>Visual:</strong> Provides a clear geometric interpretation</li>
                <li>• <strong>Coordinate-based:</strong> Links trigonometry to coordinate geometry</li>
                <li>• <strong>Foundational:</strong> Essential for advanced trigonometry</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 'degrees-radians',
      title: 'Degrees and Radians',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-green-600 mb-4">Two Ways to Measure Angles</h3>
            <p className="text-lg leading-relaxed">
              Before we dive into the unit circle, we need to understand two systems for measuring angles:
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-700">Degrees (°)</CardTitle>
              </CardHeader>
              <CardContent className="text-green-700">
                <p className="mb-3">The familiar system where a full circle = 360°</p>
                <ul className="space-y-1 text-sm">
                  <li>• Quarter circle: 90°</li>
                  <li>• Half circle: 180°</li>
                  <li>• Three-quarters: 270°</li>
                  <li>• Full circle: 360°</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-700">Radians (rad)</CardTitle>
              </CardHeader>
              <CardContent className="text-purple-700">
                <p className="mb-3">The mathematical system where a full circle = 2π radians</p>
                <ul className="space-y-1 text-sm">
                  <li>• Quarter circle: π/2 rad</li>
                  <li>• Half circle: π rad</li>
                  <li>• Three-quarters: 3π/2 rad</li>
                  <li>• Full circle: 2π rad</li>
                </ul>
              </CardContent>
            </Card>
          </div>
          
          <Card className="bg-yellow-50 border-yellow-200">
            <CardHeader>
              <CardTitle className="text-yellow-700">Conversion Formulas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4 text-yellow-700">
                <div>
                  <p className="font-semibold">Degrees to Radians:</p>
                  <p className="font-mono bg-white p-2 rounded">radians = degrees × (π/180)</p>
                </div>
                <div>
                  <p className="font-semibold">Radians to Degrees:</p>
                  <p className="font-mono bg-white p-2 rounded">degrees = radians × (180/π)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 'unit-circle-definition',
      title: 'Unit Circle Definition',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-purple-600 mb-4">Trigonometric Functions on the Unit Circle</h3>
            <p className="text-lg leading-relaxed">
              On the unit circle, we define trigonometric functions using coordinates. If we have 
              an angle θ in standard position (vertex at origin, initial side on positive x-axis), 
              and the terminal side intersects the unit circle at point (x, y), then:
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-700">Cosine</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-purple-700 text-xl">cos(θ) = x</p>
                <p className="text-sm text-purple-600 mt-2">
                  The x-coordinate of the point on the unit circle
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-700">Sine</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-green-700 text-xl">sin(θ) = y</p>
                <p className="text-sm text-green-600 mt-2">
                  The y-coordinate of the point on the unit circle
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-700">Tangent</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-blue-700 text-xl">tan(θ) = y/x</p>
                <p className="text-sm text-blue-600 mt-2">
                  The ratio of y-coordinate to x-coordinate
                </p>
              </CardContent>
            </Card>
          </div>
          
          <Card className="bg-orange-50 border-orange-200">
            <CardHeader>
              <CardTitle className="text-orange-700">Key Insight</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-orange-700">
                This coordinate-based definition naturally extends trigonometry to all angles! 
                As the angle rotates around the circle, the x and y coordinates change, 
                giving us the values of cosine and sine for any angle.
              </p>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 'interactive-exploration',
      title: 'Interactive Unit Circle',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-red-600 mb-4">Explore the Unit Circle</h3>
            <p className="text-lg leading-relaxed">
              Use the interactive unit circle below to explore how the trigonometric functions 
              behave as angles change. Drag the red point around the circle or use the slider 
              to see how the coordinates (and thus sine and cosine) change.
            </p>
          </div>
          
          <UnitCircle />
          
          <Card className="bg-red-50 border-red-200">
            <CardHeader>
              <CardTitle className="text-red-700">Exploration Activities:</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-red-700">
                <p>1. Set the angle to 0°. What are the values of sin(0°) and cos(0°)?</p>
                <p>2. Move to 90°. How do the values change?</p>
                <p>3. Try 180° and 270°. Notice the pattern of signs in each quadrant.</p>
                <p>4. Experiment with angles greater than 360°. What do you observe?</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    }
  ]
  
  const handleSectionComplete = (sectionIndex) => {
    setCompletedSections(prev => new Set([...prev, sectionIndex]))
    if (sectionIndex < sections.length - 1) {
      setCurrentSection(sectionIndex + 1)
    }
  }
  
  const progress = ((completedSections.size) / sections.length) * 100
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Course
          </Button>
          <Badge variant="outline" className="text-lg px-4 py-2">
            Lesson 2 of 8
          </Badge>
        </div>
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            The Unit Circle Revolution
          </h1>
          <p className="text-xl text-gray-600">
            Explore angles beyond 90° and coordinate-based trigonometry
          </p>
        </div>
        
        {/* Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Circle className="h-5 w-5" />
              Lesson Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Sections Completed</span>
                <span>{completedSections.size} of {sections.length}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
        
        {/* Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8">
          {sections.map((section, index) => (
            <Button
              key={section.id}
              variant={currentSection === index ? "default" : "outline"}
              size="sm"
              onClick={() => setCurrentSection(index)}
              className="flex items-center gap-2"
            >
              {completedSections.has(index) && <CheckCircle className="h-4 w-4" />}
              {section.title}
            </Button>
          ))}
        </div>
        
        {/* Current Section Content */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">
              {sections[currentSection].title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sections[currentSection].content}
            
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                disabled={currentSection === 0}
              >
                Previous
              </Button>
              
              <div className="flex gap-2">
                {!completedSections.has(currentSection) && (
                  <Button
                    onClick={() => handleSectionComplete(currentSection)}
                    className="flex items-center gap-2"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Mark Complete
                  </Button>
                )}
                
                {currentSection < sections.length - 1 ? (
                  <Button
                    onClick={() => setCurrentSection(currentSection + 1)}
                  >
                    Next
                  </Button>
                ) : completedSections.size === sections.length && (
                  <Button
                    onClick={onComplete}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Complete Lesson
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Lesson2

