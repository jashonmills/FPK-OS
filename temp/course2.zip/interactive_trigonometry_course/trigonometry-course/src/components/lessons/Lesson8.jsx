export default function Lesson8() { return <div>Lesson 8 - Coming Soon</div> }
