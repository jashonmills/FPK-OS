export default function Lesson4() { return <div>Lesson 4 - Coming Soon</div> }
