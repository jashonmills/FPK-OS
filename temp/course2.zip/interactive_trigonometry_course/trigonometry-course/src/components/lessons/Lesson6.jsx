export default function Lesson6() { return <div>Lesson 6 - Coming Soon</div> }
