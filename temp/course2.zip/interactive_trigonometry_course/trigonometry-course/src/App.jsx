import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { BookOpen, Calculator, Target, Trophy, Circle, Triangle, Zap, TrendingUp, Award } from 'lucide-react'
import Lesson1 from './components/lessons/Lesson1.jsx'
import Lesson2 from './components/lessons/Lesson2.jsx'
import Lesson3 from './components/lessons/Lesson3.jsx'
import Lesson4 from './components/lessons/Lesson4.jsx'
import Lesson5 from './components/lessons/Lesson5.jsx'
import Lesson6 from './components/lessons/Lesson6.jsx'
import Lesson7 from './components/lessons/Lesson7.jsx'
import Lesson8 from './components/lessons/Lesson8.jsx'
import './App.css'

function App() {
  const [currentLesson, setCurrentLesson] = useState(null)
  const [completedLessons, setCompletedLessons] = useState(new Set())
  
  const lessons = [
    {
      id: 1,
      title: "Foundation - Right Triangle Trigonometry",
      description: "Master SOHCAHTOA and basic trigonometric ratios",
      icon: Triangle,
      color: "bg-green-500",
      difficulty: "Beginner",
      duration: "45 min"
    },
    {
      id: 2,
      title: "The Unit Circle Revolution",
      description: "Explore angles beyond 90° and coordinate-based trigonometry",
      icon: Circle,
      color: "bg-blue-500",
      difficulty: "Beginner",
      duration: "50 min"
    },
    {
      id: 3,
      title: "Quadrants and Signs (ASTC Mastery)",
      description: "Navigate the four quadrants and master function signs",
      icon: Target,
      color: "bg-purple-500",
      difficulty: "Intermediate",
      duration: "40 min"
    },
    {
      id: 4,
      title: "Reference Angles and Exact Values",
      description: "Calculate exact trigonometric values using reference angles",
      icon: Calculator,
      color: "bg-orange-500",
      difficulty: "Intermediate",
      duration: "55 min"
    },
    {
      id: 5,
      title: "Graphing Trigonometric Functions",
      description: "Visualize sine, cosine, and tangent functions",
      icon: TrendingUp,
      color: "bg-red-500",
      difficulty: "Intermediate",
      duration: "60 min"
    },
    {
      id: 6,
      title: "Fundamental Identities",
      description: "Master Pythagorean, quotient, and reciprocal identities",
      icon: BookOpen,
      color: "bg-indigo-500",
      difficulty: "Advanced",
      duration: "50 min"
    },
    {
      id: 7,
      title: "Solving Trigonometric Equations",
      description: "Systematic approach to solving trig equations",
      icon: Zap,
      color: "bg-purple-600",
      difficulty: "Advanced",
      duration: "65 min"
    },
    {
      id: 8,
      title: "Advanced Applications and Assessment",
      description: "Complex problems and comprehensive evaluation",
      icon: Award,
      color: "bg-gold-500",
      difficulty: "Expert",
      duration: "70 min"
    }
  ]

  const handleLessonComplete = (lessonId) => {
    setCompletedLessons(prev => new Set([...prev, lessonId]))
    setCurrentLesson(null) // Return to course overview
  }

  const handleBackToCourse = () => {
    setCurrentLesson(null)
  }

  const progress = (completedLessons.size / lessons.length) * 100

  // Render specific lesson
  if (currentLesson) {
    const LessonComponents = {
      1: Lesson1,
      2: Lesson2,
      3: Lesson3,
      4: Lesson4,
      5: Lesson5,
      6: Lesson6,
      7: Lesson7,
      8: Lesson8
    }
    
    const LessonComponent = LessonComponents[currentLesson]
    
    if (LessonComponent) {
      return (
        <LessonComponent 
          onComplete={() => handleLessonComplete(currentLesson)}
          onBack={handleBackToCourse}
        />
      )
    }
  }

  // Main course overview
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-4">
            Interactive Trigonometry Course
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Master trigonometry from basic ratios to advanced equations through interactive lessons and visual learning
          </p>
          
          <div className="mt-6 flex items-center justify-center gap-4">
            <Badge variant="outline" className="text-lg px-4 py-2">
              Complete Trigonometry Mastery
            </Badge>
            <Badge variant="outline" className="text-lg px-4 py-2">
              8 Interactive Lessons
            </Badge>
            <Badge variant="outline" className="text-lg px-4 py-2">
              Production Ready
            </Badge>
          </div>
        </div>

        {/* Progress Section */}
        <Card className="mb-8 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-6 w-6 text-yellow-500" />
              Course Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Lessons Completed</span>
                <span>{completedLessons.size} of {lessons.length}</span>
              </div>
              <Progress value={progress} className="h-3" />
              <p className="text-sm text-gray-500">
                {progress === 100 ? "🎉 Course Complete! You've mastered trigonometry!" : `${Math.round(progress)}% Complete`}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Lessons Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {lessons.map((lesson) => {
            const IconComponent = lesson.icon
            const isCompleted = completedLessons.has(lesson.id)
            
            return (
              <Card 
                key={lesson.id} 
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg cursor-pointer ${
                  isCompleted ? 'ring-2 ring-green-500' : ''
                } hover:scale-105`}
                onClick={() => setCurrentLesson(lesson.id)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className={`p-3 rounded-lg ${lesson.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className="flex items-center gap-2">
                      {isCompleted && (
                        <Badge variant="default" className="bg-green-500">
                          ✓ Complete
                        </Badge>
                      )}
                      <Badge variant="outline">
                        {lesson.difficulty}
                      </Badge>
                    </div>
                  </div>
                  <CardTitle className="text-lg">
                    Lesson {lesson.id}
                  </CardTitle>
                  <CardTitle className="text-base font-medium text-gray-700">
                    {lesson.title}
                  </CardTitle>
                  <CardDescription>
                    {lesson.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-gray-500">Duration: {lesson.duration}</span>
                  </div>
                  <Button 
                    className="w-full" 
                    variant={isCompleted ? "outline" : "default"}
                  >
                    {isCompleted ? "Review Lesson" : "Start Lesson"}
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Learning Objectives */}
        <Card className="border-2 border-purple-200 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-6 w-6 text-purple-600" />
              Learning Objectives
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-green-700">✓ Master Core Concepts</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• SOHCAHTOA and right triangle trigonometry</li>
                  <li>• Unit circle and coordinate-based definitions</li>
                  <li>• Quadrant signs and ASTC rule</li>
                  <li>• Reference angles and exact values</li>
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="font-semibold text-blue-700">✓ Develop Advanced Skills</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Graph trigonometric functions with transformations</li>
                  <li>• Apply fundamental identities systematically</li>
                  <li>• Solve trigonometric equations step-by-step</li>
                  <li>• Model real-world periodic phenomena</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Course Features */}
        <Card className="border-2 border-indigo-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-6 w-6 text-indigo-600" />
              Course Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center space-y-2">
                <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto">
                  <Calculator className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold">Interactive Tools</h4>
                <p className="text-sm text-gray-600">Unit circle explorer, equation solver, function grapher, and identity verifier</p>
              </div>
              <div className="text-center space-y-2">
                <div className="bg-green-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <h4 className="font-semibold">Progressive Learning</h4>
                <p className="text-sm text-gray-600">Carefully sequenced lessons with immediate feedback and step-by-step guidance</p>
              </div>
              <div className="text-center space-y-2">
                <div className="bg-purple-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mx-auto">
                  <Trophy className="h-6 w-6 text-purple-600" />
                </div>
                <h4 className="font-semibold">Real Applications</h4>
                <p className="text-sm text-gray-600">Engineering problems, physics applications, and real-world modeling scenarios</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default App

