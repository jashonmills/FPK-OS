


# Lesson 2: The Unit Circle Revolution

## Introduction: Expanding Our Trigonometric Horizons

In our first lesson, we explored the fundamentals of trigonometry through the lens of the right-angled triangle. This approach, while powerful, has a natural limitation: it is confined to angles between 0 and 90 degrees. To unlock the full potential of trigonometry and apply it to a much broader range of problems, we must expand our perspective. This is where the unit circle comes in—a concept so fundamental and transformative that we call it a "revolution" in our understanding of trigonometry.

The unit circle is a circle with a radius of exactly one unit, centered at the origin of the Cartesian coordinate plane. By placing angles within this circle, we can define the trigonometric functions for *any* angle, including those greater than 90 degrees and even negative angles. This elegant geometric construction provides a visual and intuitive framework for understanding the cyclical nature of trigonometric functions and their relationships to one another.

In this lesson, we will embark on a journey to master the unit circle. We will learn how to measure angles in both degrees and a new, more natural unit called radians. We will discover how the coordinates of points on the unit circle correspond directly to the sine and cosine of the angle, providing a dynamic and visual representation of these functions. We will also explore the special angles on the unit circle and learn techniques for memorizing their corresponding trigonometric values. By the end of this lesson, you will have a powerful new tool in your mathematical arsenal, one that will serve as the foundation for understanding trigonometric graphs, identities, and equations in the lessons to come.




## Degrees and Radians: Two Ways to Measure Angles

Before we can fully explore the unit circle, we need to be comfortable with the two primary units for measuring angles: degrees and radians. While you are likely familiar with degrees, radians are the standard unit of angular measure in higher mathematics and science due to their more direct and natural relationship with the properties of a circle.

*   **Degrees (°):** A full circle is divided into 360 degrees. This system dates back to the ancient Babylonians and is convenient for many practical applications due to the high number of factors of 360.

*   **Radians (rad):** A radian is defined by the arc length of a circle. Specifically, one radian is the angle subtended at the center of a circle by an arc that is equal in length to the radius of the circle. A full circle contains 2π radians, which is approximately 6.28 radians. This direct relationship between angle and arc length is what makes radians so powerful in calculus and other advanced mathematical fields.

To convert between degrees and radians, we use the following conversion factors:

*   To convert from degrees to radians, multiply by π/180.
*   To convert from radians to degrees, multiply by 180/π.

For example, to convert 90 degrees to radians, we calculate: 90 * (π/180) = π/2 radians. To convert π/4 radians to degrees, we calculate: (π/4) * (180/π) = 45 degrees.

Understanding both systems of measurement is crucial for mastering the unit circle, as different contexts may favor one over the other. In our interactive explorations, you will have the opportunity to switch between degrees and radians to build your fluency in both systems.




## The Unit Circle and Trigonometric Functions

The unit circle provides a powerful and intuitive way to define the trigonometric functions for any angle. By placing an angle in standard position (with its vertex at the origin and its initial side along the positive x-axis) on the unit circle, we can define the sine and cosine of the angle in terms of the coordinates of the point where the terminal side of the angle intersects the circle.

Let θ be an angle in standard position, and let (x, y) be the coordinates of the point where the terminal side of θ intersects the unit circle. Then, the trigonometric functions are defined as follows:

*   **cosine(θ) = x**
*   **sine(θ) = y**
*   **tangent(θ) = y/x**

This simple yet profound relationship is the key to understanding the behavior of trigonometric functions. It allows us to visualize how the sine and cosine of an angle change as it rotates around the circle. For example, as the angle increases from 0 to 90 degrees, the y-coordinate (sine) increases from 0 to 1, while the x-coordinate (cosine) decreases from 1 to 0.

Furthermore, this definition naturally extends to angles greater than 90 degrees. In the second quadrant, for example, the x-coordinate is negative, so the cosine of any angle in this quadrant will be negative. This coordinate-based definition also makes it easy to understand the signs of the trigonometric functions in each quadrant, a topic we will explore in detail in the next lesson.

Our interactive unit circle tool will allow you to drag the terminal side of an angle around the circle and see in real-time how the x and y coordinates—and thus the cosine and sine of the angle—change. This hands-on experience will be invaluable in building a deep and lasting understanding of these fundamental relationships between angles and trigonometric functions.

