


# Lesson 1: Foundation - Right Triangle Trigonometry

## Introduction: The Geometry of Measurement

Welcome to the fascinating world of trigonometry! This branch of mathematics is, at its core, the study of relationships between the angles and side lengths of triangles. The name itself, derived from the Greek words *trigōnon* (triangle) and *metron* (measure), literally means "triangle measurement." While its origins are ancient, with roots in astronomy and navigation, trigonometry remains a cornerstone of modern science, engineering, and technology. From designing video games and creating computer-generated imagery to building bridges and analyzing sound waves, the principles you will learn here are fundamental to understanding and shaping the world around us.

In this introductory lesson, we will focus on the most fundamental aspect of trigonometry: the right-angled triangle. This simple geometric shape holds the key to understanding the three primary trigonometric functions: sine, cosine, and tangent. We will explore how these functions are defined as ratios of the side lengths of a right triangle and how they allow us to calculate unknown sides and angles with remarkable precision. Our journey will begin with the classic mnemonic SOHCAHTOA, a powerful tool for remembering these crucial ratios. We will then move beyond memorization to build a deep, conceptual understanding of what these ratios represent and how they can be applied to solve practical, real-world problems. By the end of this lesson, you will not only be able to calculate the height of a tree without climbing it but also appreciate the elegant power of trigonometry as a tool for indirect measurement.







## The SOHCAHTOA Mnemonic: Your Key to Trigonometric Ratios

At the heart of right-triangle trigonometry are three fundamental ratios: sine, cosine, and tangent. These ratios relate the angles of a right triangle to the lengths of its sides. To easily remember these relationships, we use the mnemonic SOHCAHTOA (pronounced "so-ka-toe-a"). This simple yet powerful tool is the foundation upon which we will build your understanding of trigonometry.

Let's first define the sides of a right-angled triangle in relation to a specific acute angle, which we'll call theta (θ):

*   **Hypotenuse:** This is always the longest side of the right triangle and is located directly opposite the right angle.
*   **Opposite:** This side is directly across from the angle θ.
*   **Adjacent:** This side is next to the angle θ, but it is not the hypotenuse.

Now, let's break down SOHCAHTOA:

*   **SOH**: **S**ine = **O**pposite / **H**ypotenuse
*   **CAH**: **C**osine = **A**djacent / **H**ypotenuse
*   **TOA**: **T**angent = **O**pposite / **A**djacent

These three ratios are the building blocks of trigonometry. They allow us to find unknown side lengths or angles in a right triangle, given enough information. For example, if we know an angle and the length of one side, we can use these ratios to calculate the lengths of the other two sides. Conversely, if we know the lengths of any two sides, we can calculate the angles of the triangle. This ability to find unknown measurements is what makes trigonometry such a powerful tool in fields like engineering, physics, and architecture.




## Real-World Applications: Trigonometry in Action

Trigonometry is not just an abstract mathematical concept; it is a practical tool used to solve real-world problems across a vast range of fields. The principles of right-triangle trigonometry, in particular, are applied in situations where direct measurement is impossible or impractical. Here are a few examples of how SOHCAHTOA is used in the real world:

*   **Architecture and Construction:** Architects and engineers use trigonometry to calculate building heights, roof slopes, and structural angles. For instance, to ensure the stability of a bridge, engineers must calculate the forces acting on its various components, a task that relies heavily on trigonometric principles. When designing a wheelchair ramp, the angle of inclination must meet accessibility standards, and trigonometry is used to determine the required length of the ramp for a given height.

*   **Navigation and Astronomy:** For centuries, sailors have used trigonometry to navigate the seas, calculating their position based on the angles of the sun and stars. Astronomers use it to calculate the distance to nearby stars and other celestial bodies through a method called parallax, where the apparent shift in an object's position is measured from two different vantage points.

*   **Video Game Development and Computer Graphics:** The virtual worlds of video games are built on a foundation of trigonometry. Developers use trigonometric functions to control the movement of characters, simulate the physics of objects, and create realistic lighting and shadow effects. When a character in a game throws an object, its trajectory is calculated using trigonometric principles.

*   **Surveying and Cartography:** Land surveyors use trigonometry to measure distances and angles between points to create accurate maps. By measuring the angle of elevation to the top of a mountain from a known distance, a surveyor can calculate its height without ever having to climb it.

These examples illustrate just a fraction of the applications of right-triangle trigonometry. As you progress through this course, you will develop the skills to solve similar problems and gain a deeper appreciation for the power and versatility of this mathematical tool.

