


# Lesson 3: Quadrants and Signs (ASTC Mastery)

## Introduction: Navigating the Trigonometric Landscape

Now that we have embraced the unit circle as our new framework for understanding trigonometry, we can begin to explore the rich landscape it reveals. The Cartesian coordinate plane, upon which the unit circle is centered, is divided into four quadrants, and the location of an angle's terminal side within these quadrants has a profound impact on the signs of its trigonometric functions. Understanding this relationship is not just a matter of memorization; it is a crucial step towards developing the intuition needed to solve trigonometric equations and analyze trigonometric graphs.

In this lesson, we will embark on a systematic exploration of the four quadrants and the signs of the sine, cosine, and tangent functions within each. We will introduce the ASTC mnemonic, a powerful tool for remembering which functions are positive in each quadrant. However, our goal is to move beyond rote memorization to a deep, conceptual understanding of *why* the signs behave as they do. By connecting the signs of the trigonometric functions to the x and y coordinates of points on the unit circle, you will develop a visual and intuitive grasp of this fundamental concept.

Our interactive quadrant explorer will allow you to see in real-time how the signs of sine, cosine, and tangent change as an angle moves from one quadrant to another. This hands-on experience will solidify your understanding and help you master the ASTC rule not as a set of arbitrary facts, but as a logical consequence of the geometry of the unit circle. By the end of this lesson, you will be able to determine the sign of any trigonometric function for any angle, a skill that is absolutely essential for solving trigonometric equations and understanding the behavior of trigonometric functions.




## The Four Quadrants of the Coordinate Plane

The Cartesian coordinate plane is divided into four quadrants by the x and y axes. These quadrants are numbered counter-clockwise, starting from the top right:

*   **Quadrant I:** Angles between 0° and 90° (0 and π/2 radians). In this quadrant, both the x and y coordinates are positive.
*   **Quadrant II:** Angles between 90° and 180° (π/2 and π radians). In this quadrant, the x-coordinate is negative, and the y-coordinate is positive.
*   **Quadrant III:** Angles between 180° and 270° (π and 3π/2 radians). In this quadrant, both the x and y coordinates are negative.
*   **Quadrant IV:** Angles between 270° and 360° (3π/2 and 2π radians). In this quadrant, the x-coordinate is positive, and the y-coordinate is negative.

Since we have defined cosine(θ) = x and sine(θ) = y on the unit circle, the signs of the sine and cosine functions in each quadrant are determined by the signs of the x and y coordinates. For example, in Quadrant II, since x is negative and y is positive, cosine(θ) will be negative, and sine(θ) will be positive.

The sign of the tangent function, defined as tan(θ) = y/x, depends on the signs of both the x and y coordinates. If x and y have the same sign (as in Quadrants I and III), the tangent will be positive. If they have different signs (as in Quadrants II and IV), the tangent will be negative.




## The ASTC Rule: A Mnemonic for Mastering Signs

To easily remember which trigonometric functions are positive in each quadrant, we use the mnemonic ASTC, which stands for "All Students Take Calculus." Starting in Quadrant I and moving counter-clockwise, the letters of this mnemonic tell us which functions are positive in each quadrant:

*   **A** (Quadrant I): **A**ll trigonometric functions (sine, cosine, and tangent) are positive.
*   **S** (Quadrant II): **S**ine is positive (and its reciprocal, cosecant).
*   **T** (Quadrant III): **T**angent is positive (and its reciprocal, cotangent).
*   **C** (Quadrant IV): **C**osine is positive (and its reciprocal, secant).

While this mnemonic is a useful tool for quick recall, it is essential to understand the underlying reasons for these sign patterns. The ASTC rule is a direct consequence of the definitions of the trigonometric functions on the unit circle. For example, in Quadrant II, the y-coordinate is positive, so sine is positive. The x-coordinate is negative, so cosine is negative. And since tangent is the ratio of sine to cosine (y/x), it will be negative as well.

Our interactive quadrant explorer will allow you to visualize these relationships. As you move an angle through the four quadrants, you will see the signs of the x and y coordinates change, and in turn, the signs of the sine, cosine, and tangent functions. This dynamic and interactive experience will help you internalize the ASTC rule not as a set of facts to be memorized, but as a logical and intuitive system based on the geometry of the unit circle.

