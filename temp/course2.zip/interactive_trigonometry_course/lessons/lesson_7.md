# Lesson 7: Solving Trigonometric Equations

## Introduction: From Identities to Equations

Solving trigonometric equations is where all your knowledge of the unit circle, reference angles, and identities comes together. Unlike identities, which are true for all values, trigonometric equations are true only for specific values of the variable. This lesson will teach you systematic approaches to find all solutions.

### What Are Trigonometric Equations?

Trigonometric equations are equations that contain trigonometric functions and are satisfied by specific values of the variable. For example:
- **sin(x) = 1/2** has solutions x = 30°, 150°, 390°, 510°, ...
- **cos(2x) = 0** has solutions x = 45°, 135°, 225°, 315°, ...
- **tan(x) = 1** has solutions x = 45°, 225°, 405°, 585°, ...

### Why Learn to Solve Trigonometric Equations?

- **Real-World Problem Solving**: Find when phenomena reach specific values
- **Engineering Applications**: Determine optimal timing and positioning
- **Physics**: Calculate when objects reach certain positions or velocities
- **Mathematical Foundation**: Essential for calculus and advanced mathematics

## Types of Trigonometric Equations

### 1. Basic Trigonometric Equations

These involve a single trigonometric function equal to a constant.

#### Form: sin(x) = k
**Strategy:**
1. Find the reference angle: α = arcsin(|k|)
2. Determine which quadrants have the correct sign
3. Find all solutions in [0°, 360°)
4. Add multiples of 360° for general solution

**Example: sin(x) = 1/2**
- Reference angle: α = 30°
- Sine is positive in Quadrants I and II
- Solutions in [0°, 360°): x = 30°, 150°
- General solution: x = 30° + 360°n or x = 150° + 360°n

#### Form: cos(x) = k
**Strategy:**
1. Find the reference angle: α = arccos(|k|)
2. Determine which quadrants have the correct sign
3. Find all solutions in [0°, 360°)
4. Add multiples of 360° for general solution

**Example: cos(x) = -√2/2**
- Reference angle: α = 45°
- Cosine is negative in Quadrants II and III
- Solutions in [0°, 360°): x = 135°, 225°
- General solution: x = 135° + 360°n or x = 225° + 360°n

#### Form: tan(x) = k
**Strategy:**
1. Find the reference angle: α = arctan(|k|)
2. Determine which quadrants have the correct sign
3. Find all solutions in [0°, 180°) (tangent has period 180°)
4. Add multiples of 180° for general solution

**Example: tan(x) = √3**
- Reference angle: α = 60°
- Tangent is positive in Quadrants I and III
- Solutions in [0°, 180°): x = 60°
- General solution: x = 60° + 180°n

### 2. Equations with Multiple Angles

These involve trigonometric functions of expressions like 2x, 3x, or x/2.

#### Form: sin(nx) = k
**Strategy:**
1. Solve for nx: find all values where sin(nx) = k
2. Divide by n to find x
3. Consider the period change

**Example: sin(2x) = √3/2**
- Let u = 2x, so sin(u) = √3/2
- u = 60°, 120° (in [0°, 360°))
- Since sin has period 360°: u = 60° + 360°n, 120° + 360°n
- Therefore: 2x = 60° + 360°n, 120° + 360°n
- Solutions: x = 30° + 180°n, 60° + 180°n

### 3. Equations Requiring Identities

These equations need algebraic manipulation using trigonometric identities.

#### Quadratic in Trigonometric Functions
**Example: 2sin²(x) - sin(x) - 1 = 0**
- Let u = sin(x): 2u² - u - 1 = 0
- Factor: (2u + 1)(u - 1) = 0
- Solutions: u = -1/2 or u = 1
- Therefore: sin(x) = -1/2 or sin(x) = 1
- Final solutions: x = 210°, 330°, 90° (in [0°, 360°))

#### Using Pythagorean Identities
**Example: sin²(x) + cos(x) = 1**
- Use sin²(x) = 1 - cos²(x): 1 - cos²(x) + cos(x) = 1
- Simplify: -cos²(x) + cos(x) = 0
- Factor: cos(x)(-cos(x) + 1) = 0
- Solutions: cos(x) = 0 or cos(x) = 1
- Final solutions: x = 90°, 270°, 0° (in [0°, 360°))

## Advanced Solution Techniques

### 1. Factoring Methods

When equations can be factored, solve each factor separately.

**Example: sin(x)cos(x) = 0**
- Either sin(x) = 0 or cos(x) = 0
- sin(x) = 0: x = 0°, 180°, 360°
- cos(x) = 0: x = 90°, 270°
- Combined solutions: x = 0°, 90°, 180°, 270°, 360°

### 2. Sum-to-Product Identities

These identities can simplify equations with sums or differences.

**Example: sin(x) + sin(3x) = 0**
- Use sum-to-product: 2sin((x+3x)/2)cos((3x-x)/2) = 0
- Simplify: 2sin(2x)cos(x) = 0
- Solutions: sin(2x) = 0 or cos(x) = 0

### 3. Substitution Methods

Sometimes substituting a new variable simplifies the equation.

**Example: cos(2x) + cos(x) = 0**
- Use cos(2x) = 2cos²(x) - 1: 2cos²(x) - 1 + cos(x) = 0
- Let u = cos(x): 2u² + u - 1 = 0
- Factor: (2u - 1)(u + 1) = 0
- Solutions: u = 1/2 or u = -1

## Systematic Solution Process

### Step 1: Analyze the Equation
- Identify the type of equation
- Note any domain restrictions
- Determine the appropriate interval for solutions

### Step 2: Simplify Using Identities
- Apply relevant trigonometric identities
- Factor when possible
- Reduce to basic trigonometric equations

### Step 3: Solve Basic Equations
- Use reference angles and the unit circle
- Consider all quadrants where the function has the required sign
- Find all solutions in the fundamental period

### Step 4: Apply Period Properties
- Add appropriate multiples of the period
- Consider any restrictions on the domain
- Express the general solution

### Step 5: Verify Solutions
- Substitute back into the original equation
- Check for extraneous solutions
- Ensure all solutions are within the specified domain

## Special Cases and Considerations

### 1. Domain Restrictions
Some equations have natural domain restrictions:
- **tan(x) = k**: x ≠ 90° + 180°n
- **sec(x) = k**: x ≠ 90° + 180°n
- **csc(x) = k**: x ≠ 180°n

### 2. No Solution Cases
Some equations have no solutions:
- **sin(x) = 2**: Impossible since -1 ≤ sin(x) ≤ 1
- **cos(x) = -1.5**: Impossible since -1 ≤ cos(x) ≤ 1

### 3. Infinite Solutions
Some equations have infinitely many solutions:
- **sin(x) = sin(x)**: True for all x (this is an identity)
- **tan(x) = tan(x)**: True for all x in the domain of tangent

## Real-World Applications

### 1. Oscillatory Motion
**Problem**: A pendulum's angle θ(t) = 15cos(2πt) degrees. When is the pendulum at 7.5°?
**Solution**: 
- 15cos(2πt) = 7.5
- cos(2πt) = 0.5
- 2πt = 60°, 300° (in [0°, 360°))
- t = 1/6, 5/6 seconds

### 2. AC Circuit Analysis
**Problem**: The voltage V(t) = 120sin(60πt) volts. When does V = 60V in the first second?
**Solution**:
- 120sin(60πt) = 60
- sin(60πt) = 0.5
- 60πt = 30°, 150° (converting to radians: π/6, 5π/6)
- t = 1/360, 5/360 seconds

### 3. Seasonal Modeling
**Problem**: Temperature T(d) = 20cos(2π(d-200)/365) + 15°C. On which days is T = 25°C?
**Solution**:
- 20cos(2π(d-200)/365) + 15 = 25
- cos(2π(d-200)/365) = 0.5
- Solve for d to find the days

## Common Mistakes and How to Avoid Them

### 1. Missing Solutions
- **Mistake**: Only finding solutions in one quadrant
- **Solution**: Always check all quadrants where the function has the correct sign

### 2. Incorrect Period Application
- **Mistake**: Using wrong period for general solutions
- **Solution**: Remember sin and cos have period 360°, tan has period 180°

### 3. Domain Errors
- **Mistake**: Including values where functions are undefined
- **Solution**: Always check domain restrictions

### 4. Algebraic Errors
- **Mistake**: Incorrect factoring or identity application
- **Solution**: Verify each step and check solutions

## Assessment and Mastery

To master solving trigonometric equations, students should be able to:

1. **Solve basic equations** using reference angles and the unit circle
2. **Apply identities** to simplify complex equations
3. **Handle multiple angle equations** systematically
4. **Find general solutions** using period properties
5. **Verify solutions** and check for extraneous answers
6. **Apply to real-world problems** involving periodic phenomena

### Progressive Skill Development

#### Level 1: Basic Equations
- Solve sin(x) = k, cos(x) = k, tan(x) = k
- Use reference angles and quadrant analysis
- Find solutions in [0°, 360°)

#### Level 2: Multiple Angles and Identities
- Solve equations with 2x, 3x, etc.
- Apply Pythagorean and other identities
- Handle quadratic forms

#### Level 3: Complex Equations and Applications
- Combine multiple techniques
- Solve real-world problems
- Analyze solution sets and special cases

This comprehensive approach to solving trigonometric equations provides the tools needed for advanced mathematics and real-world applications in engineering, physics, and other technical fields.

