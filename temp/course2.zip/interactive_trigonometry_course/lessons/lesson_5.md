# Lesson 5: Graphing Trigonometric Functions

## Introduction: Visualizing Trigonometry

Graphing trigonometric functions transforms abstract mathematical concepts into visual patterns that reveal the beauty and power of trigonometry. In this lesson, we'll explore how sine, cosine, and tangent functions behave as continuous waves, and learn to analyze their key characteristics.

### Why Graph Trigonometric Functions?

- **Pattern Recognition**: See the periodic nature of trigonometric functions
- **Real-World Modeling**: Understand how trig functions model waves, oscillations, and cycles
- **Function Analysis**: Identify amplitude, period, phase shifts, and vertical shifts
- **Problem Solving**: Use graphs to solve equations and analyze function behavior

## The Parent Functions

### Sine Function: y = sin(x)

The sine function produces a smooth, continuous wave that oscillates between -1 and 1.

#### Key Characteristics:
- **Domain**: All real numbers (-∞, ∞)
- **Range**: [-1, 1]
- **Period**: 2π (or 360°)
- **Amplitude**: 1
- **Zeros**: x = nπ where n is any integer
- **Maximum points**: x = π/2 + 2nπ
- **Minimum points**: x = 3π/2 + 2nπ

#### Important Points:
- (0, 0) - starts at origin
- (π/2, 1) - first maximum
- (π, 0) - returns to x-axis
- (3π/2, -1) - first minimum
- (2π, 0) - completes one cycle

### Cosine Function: y = cos(x)

The cosine function is identical to the sine function but shifted π/2 units to the left.

#### Key Characteristics:
- **Domain**: All real numbers (-∞, ∞)
- **Range**: [-1, 1]
- **Period**: 2π (or 360°)
- **Amplitude**: 1
- **Zeros**: x = π/2 + nπ where n is any integer
- **Maximum points**: x = 2nπ
- **Minimum points**: x = π + 2nπ

#### Important Points:
- (0, 1) - starts at maximum
- (π/2, 0) - first zero
- (π, -1) - first minimum
- (3π/2, 0) - second zero
- (2π, 1) - completes one cycle

### Tangent Function: y = tan(x)

The tangent function has a completely different behavior, with vertical asymptotes and a period of π.

#### Key Characteristics:
- **Domain**: All real numbers except x = π/2 + nπ
- **Range**: All real numbers (-∞, ∞)
- **Period**: π (or 180°)
- **Vertical Asymptotes**: x = π/2 + nπ
- **Zeros**: x = nπ where n is any integer

#### Important Points:
- (0, 0) - passes through origin
- (π/4, 1) - equals 1
- (π/2, undefined) - vertical asymptote
- (3π/4, -1) - equals -1
- (π, 0) - completes one cycle

## Transformations of Trigonometric Functions

### General Form: y = A sin(B(x - C)) + D

Each parameter creates a specific transformation:

#### Amplitude (A)
- **Effect**: Vertical stretch or compression
- **A > 1**: Stretches the graph vertically
- **0 < A < 1**: Compresses the graph vertically
- **A < 0**: Reflects the graph over the x-axis

#### Period (B)
- **Formula**: Period = 2π/|B|
- **B > 1**: Compresses the graph horizontally (shorter period)
- **0 < B < 1**: Stretches the graph horizontally (longer period)
- **B < 0**: Reflects the graph over the y-axis

#### Phase Shift (C)
- **Effect**: Horizontal translation
- **C > 0**: Shifts the graph C units to the right
- **C < 0**: Shifts the graph |C| units to the left

#### Vertical Shift (D)
- **Effect**: Vertical translation
- **D > 0**: Shifts the graph D units up
- **D < 0**: Shifts the graph |D| units down

## Real-World Applications

### Sound Waves and Music
Sound waves are sinusoidal functions where:
- **Amplitude** determines volume (loudness)
- **Frequency** determines pitch (how high or low the note sounds)
- **Phase** can create harmony or interference between multiple sounds

### Tides and Ocean Behavior
Ocean tides follow predictable sinusoidal patterns:
- **Period**: Approximately 12.5 hours between high tides
- **Amplitude**: Varies by location and moon phase
- **Vertical Shift**: Represents average sea level

### Seasonal Temperature Variations
Annual temperature cycles can be modeled with cosine functions:
- **Period**: 365 days (one year)
- **Amplitude**: Difference between average summer and winter temperatures
- **Phase Shift**: Accounts for when the warmest day occurs
- **Vertical Shift**: Represents the average annual temperature

### Electrical Circuits
Alternating current (AC) electricity follows sinusoidal patterns:
- **Amplitude**: Maximum voltage or current
- **Frequency**: 60 Hz in North America, 50 Hz in Europe
- **Phase**: Relationship between voltage and current

## Graphing Techniques

### Method 1: Point Plotting
1. Create a table of values for key points
2. Plot the points on a coordinate plane
3. Connect the points with a smooth curve
4. Extend the pattern to show multiple periods

### Method 2: Transformation Method
1. Start with the parent function
2. Apply transformations in order:
   - Vertical stretch/compression (amplitude)
   - Horizontal stretch/compression (period)
   - Horizontal shift (phase shift)
   - Vertical shift
3. Identify key points and asymptotes

### Method 3: Five-Point Method (for sine and cosine)
For one complete period, identify five key points:
1. Starting point
2. First maximum/minimum
3. Middle zero
4. Second minimum/maximum
5. Ending point

## Advanced Concepts

### Inverse Trigonometric Functions
The inverse functions (arcsin, arccos, arctan) have restricted domains to ensure they are functions:
- **arcsin(x)**: Domain [-1, 1], Range [-π/2, π/2]
- **arccos(x)**: Domain [-1, 1], Range [0, π]
- **arctan(x)**: Domain (-∞, ∞), Range (-π/2, π/2)

### Combinations of Functions
Real-world phenomena often involve combinations of trigonometric functions:
- **Sum of sines**: y = sin(x) + sin(2x) creates complex wave patterns
- **Product of functions**: y = x·sin(x) creates damped oscillations
- **Composite functions**: y = sin(cos(x)) creates intricate patterns

## Technology and Graphing

### Graphing Calculators
Modern graphing calculators can:
- Plot multiple functions simultaneously
- Zoom in on specific regions
- Calculate intersections and extrema
- Animate parameter changes

### Computer Software
Programs like Desmos, GeoGebra, and Mathematica offer:
- Interactive parameter sliders
- 3D visualizations
- Animation capabilities
- Data fitting to real-world data

## Common Mistakes and Misconceptions

### Degree vs. Radian Mode
Always check your calculator's angle mode:
- **Radian mode**: For most mathematical applications
- **Degree mode**: For some applied problems

### Period Confusion
Remember that:
- Sine and cosine have period 2π
- Tangent has period π
- The period changes with horizontal transformations

### Amplitude vs. Range
- **Amplitude**: Distance from midline to maximum
- **Range**: Set of all possible y-values

## Assessment and Mastery

To master graphing trigonometric functions, students should be able to:

1. **Sketch parent functions** from memory
2. **Identify transformations** from equations
3. **Write equations** from given graphs
4. **Solve graphically** using intersections
5. **Model real-world situations** with appropriate functions
6. **Use technology effectively** for complex problems

### Practice Problems

#### Basic Graphing
1. Sketch y = 2sin(x) and identify the amplitude
2. Graph y = cos(x - π/4) and describe the phase shift
3. Plot y = tan(2x) and find the period

#### Transformations
1. Write the equation for a sine function with amplitude 3, period π, and phase shift π/6 to the right
2. Describe all transformations in y = -2cos(3x + π) - 1
3. Find the equation of a cosine function that passes through (0, 4) and has period 4π

#### Applications
1. Model the height of a Ferris wheel over time
2. Create a function for seasonal temperature variation
3. Analyze the motion of a pendulum

This comprehensive understanding of graphing trigonometric functions provides the foundation for solving trigonometric equations and understanding more advanced mathematical concepts in calculus and beyond.

