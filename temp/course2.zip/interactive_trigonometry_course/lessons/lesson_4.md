# Lesson 4: Reference Angles and Exact Values

## Introduction: The Power of Reference Angles

Reference angles are one of the most powerful tools in trigonometry. They allow us to find exact values for trigonometric functions at any angle by relating them back to familiar angles in the first quadrant. This lesson will teach you how to master this essential skill.

### What is a Reference Angle?

A reference angle is the acute angle (between 0° and 90°) that an angle makes with the x-axis. No matter which quadrant your angle is in, its reference angle is always positive and always less than 90°.

### Why Reference Angles Matter

- **Simplification**: Convert complex angles to simple first-quadrant angles
- **Exact Values**: Find precise trigonometric values without a calculator
- **Pattern Recognition**: Understand the symmetry of trigonometric functions
- **Problem Solving**: Essential for advanced trigonometry and calculus

## Finding Reference Angles

The method for finding reference angles depends on which quadrant the terminal side of the angle lies in:

### Quadrant I (0° to 90°)
- Reference angle = the angle itself
- Example: Reference angle for 30° is 30°

### Quadrant II (90° to 180°)
- Reference angle = 180° - angle
- Example: Reference angle for 150° is 180° - 150° = 30°

### Quadrant III (180° to 270°)
- Reference angle = angle - 180°
- Example: Reference angle for 210° is 210° - 180° = 30°

### Quadrant IV (270° to 360°)
- Reference angle = 360° - angle
- Example: Reference angle for 330° is 360° - 330° = 30°

## Special Angles and Exact Values

Certain angles have exact trigonometric values that you should memorize. These are the foundation for finding exact values at any angle.

### The Special Right Triangles

#### 45-45-90 Triangle
- Angles: 45°, 45°, 90°
- Side ratios: 1 : 1 : √2
- sin(45°) = cos(45°) = √2/2
- tan(45°) = 1

#### 30-60-90 Triangle
- Angles: 30°, 60°, 90°
- Side ratios: 1 : √3 : 2
- sin(30°) = 1/2, cos(30°) = √3/2, tan(30°) = √3/3
- sin(60°) = √3/2, cos(60°) = 1/2, tan(60°) = √3

### Complete Table of Exact Values

| Angle | sin | cos | tan |
|-------|-----|-----|-----|
| 0° | 0 | 1 | 0 |
| 30° | 1/2 | √3/2 | √3/3 |
| 45° | √2/2 | √2/2 | 1 |
| 60° | √3/2 | 1/2 | √3 |
| 90° | 1 | 0 | undefined |

## Using Reference Angles to Find Exact Values

### Step-by-Step Process

1. **Identify the quadrant** of the given angle
2. **Find the reference angle** using the appropriate formula
3. **Determine the signs** using the ASTC rule
4. **Apply the signs** to the exact values of the reference angle

### Example 1: Find sin(150°)

1. 150° is in Quadrant II
2. Reference angle = 180° - 150° = 30°
3. In Quadrant II, sine is positive
4. sin(150°) = +sin(30°) = +1/2 = 1/2

### Example 2: Find cos(225°)

1. 225° is in Quadrant III
2. Reference angle = 225° - 180° = 45°
3. In Quadrant III, cosine is negative
4. cos(225°) = -cos(45°) = -√2/2

### Example 3: Find tan(300°)

1. 300° is in Quadrant IV
2. Reference angle = 360° - 300° = 60°
3. In Quadrant IV, tangent is negative
4. tan(300°) = -tan(60°) = -√3

## Real-World Applications

### Navigation and GPS Systems
Reference angles are used in navigation to calculate shortest paths and bearings. When a ship needs to travel from one point to another, the navigation system uses reference angles to determine the most efficient route.

### Engineering and Architecture
In structural engineering, reference angles help calculate forces and stresses in buildings and bridges. The exact values ensure precise calculations for safety and stability.

### Physics and Wave Motion
Reference angles are essential in analyzing wave motion, oscillations, and periodic phenomena. From sound waves to electromagnetic radiation, these concepts are fundamental.

## Practice Problems

### Basic Reference Angle Problems

1. Find the reference angle for 120°
2. Find the reference angle for 240°
3. Find the reference angle for 315°

### Exact Value Problems

1. Find the exact value of sin(135°)
2. Find the exact value of cos(210°)
3. Find the exact value of tan(315°)

### Challenge Problems

1. If sin(θ) = 1/2 and θ is in Quadrant II, find θ
2. Find all angles between 0° and 360° where cos(θ) = -√2/2
3. Solve: 2sin(θ) - √3 = 0 for 0° ≤ θ ≤ 360°

## Teaching Moments and Key Insights

### The Beauty of Symmetry
Trigonometric functions exhibit beautiful symmetry around the unit circle. Reference angles reveal this symmetry and show how all trigonometric values can be derived from just a few special angles.

### Memory Techniques
- **Visual Memory**: Draw the unit circle with special angles marked
- **Pattern Recognition**: Notice how values repeat with different signs
- **Triangle Method**: Always think back to the special right triangles

### Common Mistakes to Avoid
- Forgetting to apply the correct sign based on the quadrant
- Confusing the reference angle formulas for different quadrants
- Not reducing angles to their coterminal angle between 0° and 360°

### Building Mathematical Intuition
Understanding reference angles develops spatial reasoning and helps students see the connections between geometry and algebra. This foundation is crucial for success in calculus and advanced mathematics.

## Assessment and Mastery

To master reference angles and exact values, students should be able to:

1. **Quickly identify** the quadrant of any angle
2. **Calculate reference angles** without hesitation
3. **Apply the ASTC rule** automatically
4. **Recall exact values** for special angles
5. **Solve problems** involving multiple steps
6. **Recognize patterns** in trigonometric functions

This lesson provides the foundation for understanding the periodic nature of trigonometric functions and prepares students for graphing and solving trigonometric equations in subsequent lessons.

