# Lesson 6: Fundamental Identities

## Introduction: The Building Blocks of Trigonometry

Trigonometric identities are equations that are true for all values of the variable where both sides are defined. These powerful tools are the foundation for simplifying expressions, solving equations, and proving mathematical relationships. Mastering identities is essential for success in advanced mathematics and applications.

### What Are Trigonometric Identities?

Trigonometric identities are like mathematical "shortcuts" that reveal deep relationships between trigonometric functions. They allow us to:
- **Simplify complex expressions** into manageable forms
- **Solve trigonometric equations** systematically
- **Prove mathematical relationships** rigorously
- **Transform functions** for easier analysis

### Why Identities Matter

- **Problem Solving**: Essential tools for calculus and advanced mathematics
- **Engineering Applications**: Used in signal processing and wave analysis
- **Physics**: Fundamental in describing oscillations and wave phenomena
- **Mathematical Beauty**: Reveal elegant relationships in mathematics

## The Fundamental Identity Categories

### 1. Pythagorean Identities

These identities come directly from the Pythagorean theorem applied to the unit circle.

#### Primary Pythagorean Identity
**sin²(θ) + cos²(θ) = 1**

This is the most fundamental identity in trigonometry. On the unit circle, if a point has coordinates (cos θ, sin θ), then by the Pythagorean theorem: (cos θ)² + (sin θ)² = 1²

#### Derived Pythagorean Identities

**1 + tan²(θ) = sec²(θ)**
- Derived by dividing the primary identity by cos²(θ)
- Valid when cos(θ) ≠ 0

**1 + cot²(θ) = csc²(θ)**
- Derived by dividing the primary identity by sin²(θ)
- Valid when sin(θ) ≠ 0

### 2. Quotient Identities

These identities define tangent and cotangent in terms of sine and cosine.

**tan(θ) = sin(θ)/cos(θ)** (when cos(θ) ≠ 0)

**cot(θ) = cos(θ)/sin(θ)** (when sin(θ) ≠ 0)

### 3. Reciprocal Identities

These identities relate the six trigonometric functions through reciprocal relationships.

**csc(θ) = 1/sin(θ)** (when sin(θ) ≠ 0)

**sec(θ) = 1/cos(θ)** (when cos(θ) ≠ 0)

**cot(θ) = 1/tan(θ)** (when tan(θ) ≠ 0)

### 4. Co-function Identities

These identities relate trigonometric functions of complementary angles.

**sin(90° - θ) = cos(θ)**
**cos(90° - θ) = sin(θ)**
**tan(90° - θ) = cot(θ)**

In radians:
**sin(π/2 - θ) = cos(θ)**
**cos(π/2 - θ) = sin(θ)**
**tan(π/2 - θ) = cot(θ)**

### 5. Even-Odd Identities

These identities describe the symmetry properties of trigonometric functions.

#### Even Functions (symmetric about y-axis)
**cos(-θ) = cos(θ)**
**sec(-θ) = sec(θ)**

#### Odd Functions (symmetric about origin)
**sin(-θ) = -sin(θ)**
**tan(-θ) = -tan(θ)**
**csc(-θ) = -csc(θ)**
**cot(-θ) = -cot(θ)**

## Advanced Identity Categories

### 6. Sum and Difference Identities

These identities allow us to find exact values for sums and differences of angles.

#### Sine Sum and Difference
**sin(A + B) = sin(A)cos(B) + cos(A)sin(B)**
**sin(A - B) = sin(A)cos(B) - cos(A)sin(B)**

#### Cosine Sum and Difference
**cos(A + B) = cos(A)cos(B) - sin(A)sin(B)**
**cos(A - B) = cos(A)cos(B) + sin(A)sin(B)**

#### Tangent Sum and Difference
**tan(A + B) = [tan(A) + tan(B)] / [1 - tan(A)tan(B)]**
**tan(A - B) = [tan(A) - tan(B)] / [1 + tan(A)tan(B)]**

### 7. Double Angle Identities

These are special cases of sum identities where A = B.

#### Sine Double Angle
**sin(2θ) = 2sin(θ)cos(θ)**

#### Cosine Double Angle (Three Forms)
**cos(2θ) = cos²(θ) - sin²(θ)**
**cos(2θ) = 2cos²(θ) - 1**
**cos(2θ) = 1 - 2sin²(θ)**

#### Tangent Double Angle
**tan(2θ) = 2tan(θ) / [1 - tan²(θ)]**

### 8. Half Angle Identities

These identities help find trigonometric values for half angles.

**sin²(θ/2) = (1 - cos(θ))/2**
**cos²(θ/2) = (1 + cos(θ))/2**
**tan²(θ/2) = (1 - cos(θ))/(1 + cos(θ))**

## Strategies for Using Identities

### 1. Recognition Patterns
Learn to recognize when identities can be applied:
- Look for expressions that match identity forms
- Identify opportunities to substitute equivalent expressions
- Recognize when to use reciprocal relationships

### 2. Simplification Techniques
- **Start with the more complex side** of an equation
- **Work toward the simpler side** step by step
- **Use fundamental identities first** before advanced ones
- **Factor when possible** to reveal common terms

### 3. Verification Methods
To verify an identity:
1. Transform one side to match the other
2. Transform both sides to a common form
3. Use known identities systematically
4. Check your work with specific angle values

## Real-World Applications

### Signal Processing
In electrical engineering, identities are used to:
- **Analyze AC circuits** with multiple frequencies
- **Process digital signals** in communications
- **Design filters** for audio and radio systems

### Physics and Engineering
Identities help in:
- **Wave interference** calculations
- **Oscillation analysis** in mechanical systems
- **Electromagnetic field** calculations

### Computer Graphics
Identities are essential for:
- **3D rotations** and transformations
- **Animation** calculations
- **Lighting models** in rendering

## Common Mistakes and How to Avoid Them

### 1. Domain Restrictions
Always check that identities are valid for the given values:
- **tan(θ)** is undefined when cos(θ) = 0
- **sec(θ)** is undefined when cos(θ) = 0
- **csc(θ)** is undefined when sin(θ) = 0

### 2. Sign Errors
Be careful with signs, especially in:
- **Even-odd identities**
- **Quadrant-dependent signs**
- **Sum and difference formulas**

### 3. Algebraic Manipulation
Remember basic algebra rules:
- **Factor before canceling**
- **Find common denominators** for fractions
- **Use substitution** strategically

## Practice Strategies

### 1. Start Simple
Begin with basic identities and gradually work up to complex ones:
- Master Pythagorean identities first
- Practice quotient and reciprocal identities
- Move to sum/difference and double angle identities

### 2. Verify Numerically
Check your work by substituting specific angle values:
- Use special angles (30°, 45°, 60°)
- Verify both sides give the same result
- Build confidence in your algebraic work

### 3. Pattern Recognition
Look for common patterns in problems:
- **Sum of squares** suggests Pythagorean identities
- **Products of sines and cosines** suggest double angle formulas
- **Fractions** often use quotient or reciprocal identities

## Assessment and Mastery

To master trigonometric identities, students should be able to:

1. **Recall fundamental identities** from memory
2. **Verify identities** using algebraic manipulation
3. **Simplify expressions** using appropriate identities
4. **Choose the right identity** for each situation
5. **Apply identities** to solve real-world problems
6. **Prove new identities** using known ones

### Progressive Skill Development

#### Level 1: Recognition and Recall
- Memorize fundamental identities
- Recognize identity patterns
- Apply basic substitutions

#### Level 2: Verification and Simplification
- Verify given identities
- Simplify complex expressions
- Use multiple identities in sequence

#### Level 3: Problem Solving and Applications
- Solve equations using identities
- Apply identities to real-world problems
- Derive new identities from known ones

This comprehensive understanding of trigonometric identities provides the foundation for solving complex trigonometric equations and understanding advanced mathematical concepts in calculus, physics, and engineering.

