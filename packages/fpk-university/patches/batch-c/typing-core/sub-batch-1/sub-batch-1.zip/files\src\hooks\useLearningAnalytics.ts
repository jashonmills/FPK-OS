// (file contents omitted for brevity - bundled patch contains the modified file already present in repo)
