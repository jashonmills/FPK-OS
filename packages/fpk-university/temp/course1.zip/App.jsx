import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { BookOpen, Calculator, CheckCircle, PlayCircle, Trophy } from 'lucide-react'
import './App.css'

// Import lesson components
import Lesson1 from './components/lessons/Lesson1.jsx'
import Lesson2 from './components/lessons/Lesson2.jsx'
import Lesson3 from './components/lessons/Lesson3.jsx'
import Lesson4 from './components/lessons/Lesson4.jsx'
import Lesson5 from './components/lessons/Lesson5.jsx'
import Lesson6 from './components/lessons/Lesson6.jsx'
import Lesson7 from './components/lessons/Lesson7.jsx'

function App() {
  const [currentLesson, setCurrentLesson] = useState(0)
  const [completedLessons, setCompletedLessons] = useState(new Set())
  const [overallProgress, setOverallProgress] = useState(0)

  const lessons = [
    {
      id: 1,
      title: "Introduction to Linear Equations",
      description: "Learn what linear equations are and how they're used in real life",
      component: Lesson1,
      icon: BookOpen
    },
    {
      id: 2,
      title: "Basic Solving Techniques",
      description: "Master the balance method and one-step equations",
      component: Lesson2,
      icon: Calculator
    },
    {
      id: 3,
      title: "Inverse Operations Mastery",
      description: "Understand the power of undoing operations",
      component: Lesson3,
      icon: PlayCircle
    },
    {
      id: 4,
      title: "Multi-Step Equations",
      description: "Tackle complex equations with multiple steps",
      component: Lesson4,
      icon: Calculator
    },
    {
      id: 5,
      title: "Special Cases and Applications",
      description: "Handle fractions, decimals, and real-world problems",
      component: Lesson5,
      icon: BookOpen
    },
    {
      id: 6,
      title: "Verification and Error Analysis",
      description: "Learn to check solutions and avoid common mistakes",
      component: Lesson6,
      icon: CheckCircle
    },
    {
      id: 7,
      title: "Comprehensive Assessment",
      description: "Demonstrate your mastery of linear equations",
      component: Lesson7,
      icon: Trophy
    }
  ]

  const markLessonComplete = (lessonId) => {
    const newCompleted = new Set(completedLessons)
    newCompleted.add(lessonId)
    setCompletedLessons(newCompleted)
    setOverallProgress((newCompleted.size / lessons.length) * 100)
  }

  const CurrentLessonComponent = lessons[currentLesson]?.component

  if (currentLesson === -1) {
    // Course overview
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-6xl mx-auto">
          <header className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Interactive Linear Equations Course
            </h1>
            <p className="text-xl text-gray-600 mb-6">
              Master solving linear equations with one variable through interactive lessons and practice
            </p>
            <div className="flex items-center justify-center gap-4 mb-6">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                Module 3 - Algebra
              </Badge>
              <Badge variant="outline" className="text-lg px-4 py-2">
                7 Lessons
              </Badge>
            </div>
            <div className="max-w-md mx-auto">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Course Progress</span>
                <span>{Math.round(overallProgress)}%</span>
              </div>
              <Progress value={overallProgress} className="h-3" />
            </div>
          </header>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lessons.map((lesson, index) => {
              const Icon = lesson.icon
              const isCompleted = completedLessons.has(lesson.id)
              const isAccessible = index === 0 || completedLessons.has(lessons[index - 1].id)
              
              return (
                <Card 
                  key={lesson.id} 
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    isCompleted ? 'border-green-500 bg-green-50' : 
                    isAccessible ? 'hover:border-blue-500' : 'opacity-50 cursor-not-allowed'
                  }`}
                  onClick={() => isAccessible && setCurrentLesson(index)}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Icon className={`h-8 w-8 ${isCompleted ? 'text-green-600' : 'text-blue-600'}`} />
                      {isCompleted && <CheckCircle className="h-6 w-6 text-green-600" />}
                    </div>
                    <CardTitle className="text-lg">{lesson.title}</CardTitle>
                    <CardDescription>{lesson.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full" 
                      disabled={!isAccessible}
                      variant={isCompleted ? "secondary" : "default"}
                    >
                      {isCompleted ? "Review Lesson" : "Start Lesson"}
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-12 text-center">
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Learning Objectives</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-left space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    Solve one-step and multi-step linear equations
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    Use inverse operations to isolate variables
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    Check solutions by substitution
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    Apply equation solving to real-world problems
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <nav className="bg-white shadow-sm border-b p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Button 
            variant="ghost" 
            onClick={() => setCurrentLesson(-1)}
            className="text-blue-600 hover:text-blue-800"
          >
            ← Back to Course Overview
          </Button>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">
              Lesson {currentLesson + 1} of {lessons.length}
            </span>
            <div className="w-32">
              <Progress value={((currentLesson + 1) / lessons.length) * 100} className="h-2" />
            </div>
          </div>
        </div>
      </nav>

      <main className="p-4">
        {CurrentLessonComponent && (
          <CurrentLessonComponent 
            onComplete={() => markLessonComplete(lessons[currentLesson].id)}
            onNext={() => {
              if (currentLesson < lessons.length - 1) {
                setCurrentLesson(currentLesson + 1)
              } else {
                setCurrentLesson(-1)
              }
            }}
          />
        )}
      </main>
    </div>
  )
}

export default App

