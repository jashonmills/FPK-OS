import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { CheckCircle, Calculator, Lightbulb, ArrowRight } from 'lucide-react'
import BalanceScale from '../interactive/BalanceScale.jsx'
import StepByStepper from '../interactive/StepByStepper.jsx'
import balanceScaleImage from '../../assets/balance-scale-visual.png'
import equationStepsImage from '../../assets/equation-steps-visual.png'

const Lesson2 = ({ onComplete, onNext }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())
  const [practiceAnswers, setPracticeAnswers] = useState({})
  const [showFeedback, setShowFeedback] = useState({})

  const practiceProblems = [
    { equation: 'x + 7 = 15', answer: 8, type: 'addition' },
    { equation: 'y - 5 = 12', answer: 17, type: 'subtraction' },
    { equation: '3x = 21', answer: 7, type: 'multiplication' },
    { equation: 'a / 4 = 6', answer: 24, type: 'division' }
  ]

  const checkAnswer = (problemIndex, userAnswer) => {
    const correct = practiceProblems[problemIndex].answer
    const isCorrect = parseInt(userAnswer) === correct
    setShowFeedback({
      ...showFeedback,
      [problemIndex]: {
        isCorrect,
        message: isCorrect ? 'Correct! Well done!' : `Not quite. The correct answer is ${correct}.`
      }
    })
  }

  const sections = [
    {
      title: "The Balance Method",
      content: (
        <div className="space-y-6">
          <p className="text-lg">
            An equation is like a balanced scale. To keep the scale balanced, whatever you do to one side, 
            you must also do to the other. This is the fundamental principle of solving equations.
          </p>
          
          <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-500">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="h-5 w-5 text-blue-600" />
              <span className="font-semibold text-blue-800">The Golden Rule</span>
            </div>
            <p className="text-blue-800">
              Whatever operation you perform on one side of an equation, you must perform the same operation on the other side.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Visual Analogy</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Imagine a scale with a mystery box (our variable x) and some weights on one side, 
                and a pile of weights on the other. Your goal is to figure out the weight of the mystery box.</p>
                <div className="mt-4 text-center">
                  <div className="inline-block p-4 bg-yellow-100 rounded-lg">
                    <div className="text-lg font-mono">📦 + 3kg = 8kg</div>
                    <div className="text-sm text-gray-600 mt-1">What does the box weigh?</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Mathematical Translation</CardTitle>
              </CardHeader>
              <CardContent>
                <p>In algebra, we represent this same concept with variables and numbers:</p>
                <div className="mt-4 text-center">
                  <div className="inline-block p-4 bg-green-100 rounded-lg">
                    <div className="text-lg font-mono">x + 3 = 8</div>
                    <div className="text-sm text-gray-600 mt-1">What is the value of x?</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mb-6">
            <img 
              src={balanceScaleImage} 
              alt="Balance scale showing equation concept" 
              className="mx-auto rounded-lg shadow-md max-w-md"
            />
          </div>

          <BalanceScale 
            leftSide={[{ type: 'variable', coefficient: 1 }, { type: 'number', value: 3 }]}
            rightSide={[{ type: 'number', value: 8 }]}
          />
        </div>
      )
    },
    {
      title: "One-Step Equations: Addition and Subtraction",
      content: (
        <div className="space-y-6">
          <p className="text-lg">
            Let's start with the simplest type of linear equations: one-step equations involving addition and subtraction.
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-green-500">
              <CardHeader>
                <CardTitle className="text-green-700">Addition Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-xl font-mono text-center">x + 5 = 12</div>
                  <div className="text-sm text-gray-600">
                    <strong>Goal:</strong> Get x by itself on one side
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 1:</span>
                      <span>Subtract 5 from both sides</span>
                    </div>
                    <div className="font-mono text-center bg-gray-50 p-2 rounded">
                      x + 5 - 5 = 12 - 5
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 2:</span>
                      <span>Simplify</span>
                    </div>
                    <div className="font-mono text-center bg-green-50 p-2 rounded border border-green-300">
                      x = 7
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-500">
              <CardHeader>
                <CardTitle className="text-blue-700">Subtraction Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-xl font-mono text-center">y - 8 = 3</div>
                  <div className="text-sm text-gray-600">
                    <strong>Goal:</strong> Get y by itself on one side
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 1:</span>
                      <span>Add 8 to both sides</span>
                    </div>
                    <div className="font-mono text-center bg-gray-50 p-2 rounded">
                      y - 8 + 8 = 3 + 8
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 2:</span>
                      <span>Simplify</span>
                    </div>
                    <div className="font-mono text-center bg-blue-50 p-2 rounded border border-blue-300">
                      y = 11
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-5 w-5 text-yellow-600" />
              <span className="font-semibold text-yellow-800">Remember</span>
            </div>
            <p className="text-yellow-800">
              Addition and subtraction are inverse operations. To undo addition, we subtract. To undo subtraction, we add.
            </p>
          </div>
        </div>
      )
    },
    {
      title: "One-Step Equations: Multiplication and Division",
      content: (
        <div className="space-y-6">
          <p className="text-lg">
            Now let's look at equations involving multiplication and division.
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-purple-500">
              <CardHeader>
                <CardTitle className="text-purple-700">Multiplication Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-xl font-mono text-center">4x = 20</div>
                  <div className="text-sm text-gray-600">
                    <strong>Note:</strong> 4x means 4 × x
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 1:</span>
                      <span>Divide both sides by 4</span>
                    </div>
                    <div className="font-mono text-center bg-gray-50 p-2 rounded">
                      4x ÷ 4 = 20 ÷ 4
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 2:</span>
                      <span>Simplify</span>
                    </div>
                    <div className="font-mono text-center bg-purple-50 p-2 rounded border border-purple-300">
                      x = 5
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-orange-500">
              <CardHeader>
                <CardTitle className="text-orange-700">Division Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-xl font-mono text-center">a ÷ 3 = 6</div>
                  <div className="text-sm text-gray-600">
                    <strong>Note:</strong> This can also be written as a/3 = 6
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 1:</span>
                      <span>Multiply both sides by 3</span>
                    </div>
                    <div className="font-mono text-center bg-gray-50 p-2 rounded">
                      (a ÷ 3) × 3 = 6 × 3
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Step 2:</span>
                      <span>Simplify</span>
                    </div>
                    <div className="font-mono text-center bg-orange-50 p-2 rounded border border-orange-300">
                      a = 18
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="font-semibold text-green-800">Key Insight</span>
            </div>
            <p className="text-green-800">
              Multiplication and division are inverse operations. To undo multiplication, we divide. To undo division, we multiply.
            </p>
          </div>
        </div>
      )
    },
    {
      title: "Guided Practice",
      content: (
        <div className="space-y-6">
          <p className="text-lg">
            Now it's your turn! Try solving these one-step equations. Enter your answer and click "Check" to see if you're correct.
          </p>

          <div className="grid gap-4">
            {practiceProblems.map((problem, index) => (
              <Card key={index} className="border-2">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calculator className="h-5 w-5" />
                    Problem {index + 1}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-2xl font-mono bg-gray-50 p-4 rounded-lg inline-block">
                        {problem.equation}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 justify-center">
                      <span className="font-semibold">Answer:</span>
                      <Input
                        type="number"
                        placeholder="Enter your answer"
                        className="w-32"
                        value={practiceAnswers[index] || ''}
                        onChange={(e) => setPracticeAnswers({
                          ...practiceAnswers,
                          [index]: e.target.value
                        })}
                      />
                      <Button
                        onClick={() => checkAnswer(index, practiceAnswers[index])}
                        disabled={!practiceAnswers[index]}
                      >
                        Check
                      </Button>
                    </div>

                    {showFeedback[index] && (
                      <div className={`p-3 rounded-lg text-center ${
                        showFeedback[index].isCorrect 
                          ? 'bg-green-50 text-green-800 border border-green-300' 
                          : 'bg-red-50 text-red-800 border border-red-300'
                      }`}>
                        {showFeedback[index].message}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <StepByStepper equation="2x + 5 = 15" solution={5} />

          <div className="text-center">
            <Card className="max-w-md mx-auto">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-blue-600" />
                  <span className="font-semibold">Practice Complete!</span>
                </div>
                <p className="text-sm text-gray-600">
                  Great job practicing one-step equations. You're ready to move on to more complex problems!
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    }
  ]

  const markSectionComplete = (index) => {
    const newCompleted = new Set(completedSections)
    newCompleted.add(index)
    setCompletedSections(newCompleted)
  }

  const isLessonComplete = completedSections.size === sections.length

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Calculator className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 2: Basic Solving Techniques</h1>
        </div>
        <p className="text-gray-600">Master the balance method and one-step equations</p>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Navigation sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Lesson Sections</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {sections.map((section, index) => (
                  <Button
                    key={index}
                    variant={currentSection === index ? "default" : "ghost"}
                    className="w-full justify-start text-left h-auto p-3"
                    onClick={() => setCurrentSection(index)}
                  >
                    <div className="flex items-center gap-2">
                      {completedSections.has(index) && (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      )}
                      <span className="text-sm">{section.title}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main content */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{sections[currentSection].title}</CardTitle>
                <Badge variant="outline">
                  Section {currentSection + 1} of {sections.length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              {sections[currentSection].content}
              
              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                  disabled={currentSection === 0}
                >
                  Previous
                </Button>
                
                <div className="flex gap-2">
                  {!completedSections.has(currentSection) && (
                    <Button
                      variant="secondary"
                      onClick={() => markSectionComplete(currentSection)}
                    >
                      Mark Complete
                    </Button>
                  )}
                  
                  {currentSection < sections.length - 1 ? (
                    <Button
                      onClick={() => {
                        markSectionComplete(currentSection)
                        setCurrentSection(currentSection + 1)
                      }}
                    >
                      Next Section
                    </Button>
                  ) : (
                    <Button
                      onClick={() => {
                        markSectionComplete(currentSection)
                        onComplete()
                        onNext()
                      }}
                      disabled={!isLessonComplete && !completedSections.has(currentSection)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Complete Lesson
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Lesson2

