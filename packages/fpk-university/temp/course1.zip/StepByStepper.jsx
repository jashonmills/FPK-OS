import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowRight, CheckCircle, Lightbulb, RotateCcw } from 'lucide-react'

const StepByStepper = ({ equation = "2x + 5 = 15", solution = 5 }) => {
  const [currentStep, setCurrentStep] = useState(0)
  const [userInput, setUserInput] = useState('')
  const [showHint, setShowHint] = useState(false)

  // Parse the equation and generate steps
  const generateSteps = (eq) => {
    // This is a simplified example for 2x + 5 = 15
    return [
      {
        equation: "2x + 5 = 15",
        description: "Original equation",
        operation: "Start here",
        explanation: "We need to isolate x by undoing the operations in reverse order."
      },
      {
        equation: "2x + 5 - 5 = 15 - 5",
        description: "Subtract 5 from both sides",
        operation: "Subtract 5",
        explanation: "To undo the +5, we subtract 5 from both sides to keep the equation balanced."
      },
      {
        equation: "2x = 10",
        description: "Simplify both sides",
        operation: "Simplify",
        explanation: "The +5 and -5 cancel out on the left, and 15 - 5 = 10 on the right."
      },
      {
        equation: "2x ÷ 2 = 10 ÷ 2",
        description: "Divide both sides by 2",
        operation: "Divide by 2",
        explanation: "To undo the multiplication by 2, we divide both sides by 2."
      },
      {
        equation: "x = 5",
        description: "Solution found!",
        operation: "Complete",
        explanation: "We have successfully isolated x. The solution is x = 5."
      }
    ]
  }

  const steps = generateSteps(equation)
  const currentStepData = steps[currentStep]

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
      setUserInput('')
      setShowHint(false)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      setUserInput('')
      setShowHint(false)
    }
  }

  const reset = () => {
    setCurrentStep(0)
    setUserInput('')
    setShowHint(false)
  }

  const getStepColor = (stepIndex) => {
    if (stepIndex < currentStep) return 'bg-green-100 border-green-500 text-green-800'
    if (stepIndex === currentStep) return 'bg-blue-100 border-blue-500 text-blue-800'
    return 'bg-gray-100 border-gray-300 text-gray-600'
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-6 w-6 text-blue-600" />
            Interactive Step-by-Step Solver
          </CardTitle>
          <Button variant="outline" size="sm" onClick={reset}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Progress indicator */}
          <div className="flex items-center justify-between mb-6">
            {steps.map((_, index) => (
              <div key={index} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  index <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                }`}>
                  {index + 1}
                </div>
                {index < steps.length - 1 && (
                  <ArrowRight className={`h-4 w-4 mx-2 ${
                    index < currentStep ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                )}
              </div>
            ))}
          </div>

          {/* Current step display */}
          <Card className={`border-2 ${getStepColor(currentStep)}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  Step {currentStep + 1}: {currentStepData.description}
                </CardTitle>
                <Badge variant="outline">
                  {currentStepData.operation}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-mono bg-white p-4 rounded-lg border inline-block">
                    {currentStepData.equation}
                  </div>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-blue-800 mb-1">Explanation:</p>
                      <p className="text-blue-700">{currentStepData.explanation}</p>
                    </div>
                  </div>
                </div>

                {/* Interactive element for practice */}
                {currentStep > 0 && currentStep < steps.length - 1 && (
                  <div className="bg-yellow-50 p-4 rounded-lg border">
                    <p className="font-semibold mb-2">Try it yourself:</p>
                    <p className="text-sm text-gray-600 mb-3">
                      What operation should we perform on both sides?
                    </p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter your answer..."
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        className="flex-1"
                      />
                      <Button
                        variant="outline"
                        onClick={() => setShowHint(!showHint)}
                      >
                        Hint
                      </Button>
                    </div>
                    {showHint && (
                      <div className="mt-2 p-2 bg-yellow-100 rounded text-sm">
                        💡 Look at what operation is being performed on the variable and use its inverse!
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Navigation buttons */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={prevStep}
              disabled={currentStep === 0}
            >
              Previous Step
            </Button>
            
            <div className="text-sm text-gray-600 flex items-center">
              Step {currentStep + 1} of {steps.length}
            </div>
            
            <Button
              onClick={nextStep}
              disabled={currentStep === steps.length - 1}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Next Step
            </Button>
          </div>

          {/* Completion message */}
          {currentStep === steps.length - 1 && (
            <Card className="bg-green-50 border-green-500">
              <CardContent className="pt-6">
                <div className="text-center">
                  <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-3" />
                  <h3 className="text-lg font-bold text-green-800 mb-2">
                    Congratulations! 🎉
                  </h3>
                  <p className="text-green-700">
                    You've successfully solved the equation step by step. 
                    The solution is <strong>x = {solution}</strong>.
                  </p>
                  <div className="mt-4">
                    <Button onClick={reset} className="bg-green-600 hover:bg-green-700">
                      Try Another Problem
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default StepByStepper

