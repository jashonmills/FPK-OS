import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { CheckCircle, BookOpen, Lightbulb, Calculator } from 'lucide-react'

const Lesson1 = ({ onComplete, onNext }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())

  const sections = [
    {
      title: "What is an Equation?",
      content: (
        <div className="space-y-4">
          <p className="text-lg">
            In mathematics, an <strong>equation</strong> is a statement that asserts the equality of two expressions. 
            Think of it like a balanced scale. Whatever is on one side of the scale must be equal in value to what 
            is on the other side for the scale to remain balanced.
          </p>
          <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="h-5 w-5 text-blue-600" />
              <span className="font-semibold text-blue-800">Key Insight</span>
            </div>
            <p>The equal sign (=) is the pivot point of this balance. For example: 2 + 3 = 5</p>
          </div>
          <div className="text-center">
            <div className="inline-block bg-white p-6 rounded-lg shadow-md border">
              <div className="text-2xl font-mono">2 + 3 = 5</div>
              <div className="text-sm text-gray-600 mt-2">A simple arithmetic equation</div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Introducing Variables",
      content: (
        <div className="space-y-4">
          <p className="text-lg">
            A <strong>variable</strong> is a symbol (usually a letter, like x, y, or t) that represents a number 
            we do not know yet. It's a placeholder for a value that can change or vary.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Example Equation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-mono mb-2">x + 3 = 8</div>
                  <p className="text-sm text-gray-600">What number plus 3 equals 8?</p>
                  <div className="mt-4 p-3 bg-green-50 rounded">
                    <p className="text-green-800 font-semibold">Answer: x = 5</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">The Solution</CardTitle>
              </CardHeader>
              <CardContent>
                <p>The value of the variable that makes the equation true is called the <strong>solution</strong>.</p>
                <p className="mt-2">In our example, when x = 5:</p>
                <div className="text-center mt-2 font-mono">5 + 3 = 8 ✓</div>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    },
    {
      title: "What Makes an Equation Linear?",
      content: (
        <div className="space-y-4">
          <p className="text-lg">
            A <strong>linear equation</strong> is an equation where the highest power of the variable is 1. 
            This means no variables with exponents, no variables in denominators, and no variables under square roots.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-green-500">
              <CardHeader>
                <CardTitle className="text-green-700 flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Linear Equations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 font-mono">
                  <div>2x + 5 = 15</div>
                  <div>y - 7 = 3</div>
                  <div>a/4 = 9</div>
                </div>
                <p className="text-sm text-green-600 mt-2">All variables have power of 1</p>
              </CardContent>
            </Card>
            <Card className="border-red-500">
              <CardHeader>
                <CardTitle className="text-red-700">Non-Linear Equations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 font-mono">
                  <div>x² + 2x - 3 = 0</div>
                  <div>√y = 4</div>
                  <div>1/z = 6</div>
                </div>
                <p className="text-sm text-red-600 mt-2">Variables have powers ≠ 1</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    },
    {
      title: "Real-World Examples",
      content: (
        <div className="space-y-4">
          <p className="text-lg">
            Linear equations are not just abstract math problems; they are all around us! 
            Here are some examples of how they model real-world situations:
          </p>
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-blue-600" />
                  Shopping Example
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>You have a $20 gift card and want to buy a book that costs $12. How much money will be left?</p>
                <div className="mt-2 p-3 bg-gray-50 rounded font-mono">
                  12 + m = 20
                </div>
                <p className="text-sm text-gray-600 mt-1">Where m = money left on the card</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-green-600" />
                  Phone Bill Example
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Your phone plan costs $30/month plus $0.10 per text. If your bill was $35, how many texts did you send?</p>
                <div className="mt-2 p-3 bg-gray-50 rounded font-mono">
                  30 + 0.10t = 35
                </div>
                <p className="text-sm text-gray-600 mt-1">Where t = number of texts sent</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-purple-600" />
                  Temperature Conversion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Convert temperatures from Celsius to Fahrenheit:</p>
                <div className="mt-2 p-3 bg-gray-50 rounded font-mono">
                  F = 1.8C + 32
                </div>
                <p className="text-sm text-gray-600 mt-1">Where C = Celsius, F = Fahrenheit</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    }
  ]

  const markSectionComplete = (index) => {
    const newCompleted = new Set(completedSections)
    newCompleted.add(index)
    setCompletedSections(newCompleted)
  }

  const isLessonComplete = completedSections.size === sections.length

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <BookOpen className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 1: Introduction to Linear Equations</h1>
        </div>
        <p className="text-gray-600">Learn what linear equations are and how they're used in real life</p>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Navigation sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Lesson Sections</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {sections.map((section, index) => (
                  <Button
                    key={index}
                    variant={currentSection === index ? "default" : "ghost"}
                    className="w-full justify-start text-left h-auto p-3"
                    onClick={() => setCurrentSection(index)}
                  >
                    <div className="flex items-center gap-2">
                      {completedSections.has(index) && (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      )}
                      <span className="text-sm">{section.title}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main content */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{sections[currentSection].title}</CardTitle>
                <Badge variant="outline">
                  Section {currentSection + 1} of {sections.length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              {sections[currentSection].content}
              
              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                  disabled={currentSection === 0}
                >
                  Previous
                </Button>
                
                <div className="flex gap-2">
                  {!completedSections.has(currentSection) && (
                    <Button
                      variant="secondary"
                      onClick={() => markSectionComplete(currentSection)}
                    >
                      Mark Complete
                    </Button>
                  )}
                  
                  {currentSection < sections.length - 1 ? (
                    <Button
                      onClick={() => {
                        markSectionComplete(currentSection)
                        setCurrentSection(currentSection + 1)
                      }}
                    >
                      Next Section
                    </Button>
                  ) : (
                    <Button
                      onClick={() => {
                        markSectionComplete(currentSection)
                        onComplete()
                        onNext()
                      }}
                      disabled={!isLessonComplete && !completedSections.has(currentSection)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Complete Lesson
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Lesson1

