import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { ArrowLeft, Award, CheckCircle, Star, Trophy } from 'lucide-react'

const Lesson8 = ({ onComplete, onBack }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())
  const [assessmentScore, setAssessmentScore] = useState(null)
  const [showCertificate, setShowCertificate] = useState(false)
  
  const sections = [
    {
      id: 'introduction',
      title: 'Trigonometry in the Real World',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-gold-600 mb-4">Your Trigonometry Journey</h3>
            <p className="text-lg leading-relaxed">
              Congratulations on reaching the final lesson! This capstone brings together everything 
              you've learned about trigonometry and applies it to sophisticated real-world scenarios. 
              From engineering marvels to natural phenomena, trigonometry is the mathematical language 
              that describes our world's patterns, cycles, and relationships.
            </p>
          </div>
          
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-700">Your Course Journey Recap</CardTitle>
            </CardHeader>
            <CardContent className="text-blue-700">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Foundations Mastered:</h4>
                  <ul className="text-sm space-y-1">
                    <li>✓ Right Triangle Trigonometry (SOHCAHTOA)</li>
                    <li>✓ The Unit Circle and coordinate relationships</li>
                    <li>✓ Quadrants and Signs (ASTC rule)</li>
                    <li>✓ Reference Angles and exact values</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Advanced Skills Developed:</h4>
                  <ul className="text-sm space-y-1">
                    <li>✓ Graphing and function transformations</li>
                    <li>✓ Fundamental identities and relationships</li>
                    <li>✓ Solving trigonometric equations</li>
                    <li>✓ Real-world applications and modeling</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="bg-green-50 border-green-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-green-700 text-lg">Engineering</CardTitle>
              </CardHeader>
              <CardContent className="text-green-700 text-sm">
                <p>Structural analysis, signal processing, AC circuits, and mechanical systems</p>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-blue-700 text-lg">Physics</CardTitle>
              </CardHeader>
              <CardContent className="text-blue-700 text-sm">
                <p>Wave motion, oscillations, electromagnetic fields, and quantum mechanics</p>
              </CardContent>
            </Card>
            
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-purple-700 text-lg">Technology</CardTitle>
              </CardHeader>
              <CardContent className="text-purple-700 text-sm">
                <p>Computer graphics, GPS navigation, digital signal processing, and robotics</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    },
    {
      id: 'advanced-modeling',
      title: 'Advanced Modeling Applications',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-red-600 mb-4">Harmonic Motion and Wave Analysis</h3>
            <p className="text-lg leading-relaxed">
              Real-world systems often exhibit harmonic motion and wave behavior that can be precisely 
              modeled using trigonometric functions. Let's explore some sophisticated applications.
            </p>
          </div>
          
          <div className="space-y-6">
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-700">Simple Harmonic Motion</CardTitle>
              </CardHeader>
              <CardContent className="text-red-700">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">General Form: x(t) = A cos(ωt + φ) + D</p>
                    <ul className="text-sm space-y-1">
                      <li>• <strong>A:</strong> Amplitude (maximum displacement)</li>
                      <li>• <strong>ω:</strong> Angular frequency (ω = 2π/T)</li>
                      <li>• <strong>φ:</strong> Phase shift (initial phase)</li>
                      <li>• <strong>D:</strong> Vertical shift (equilibrium position)</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">Example: Grandfather Clock Pendulum</p>
                    <ul className="text-sm space-y-1">
                      <li>• Amplitude: 15 cm, Period: 2 seconds</li>
                      <li>• Position: x(t) = 15 cos(πt) cm</li>
                      <li>• Velocity: v(t) = -15π sin(πt) cm/s</li>
                      <li>• Maximum speed: 15π ≈ 47.1 cm/s</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-700">Wave Interference and Superposition</CardTitle>
              </CardHeader>
              <CardContent className="text-blue-700">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">Two Wave Combination</p>
                    <p className="text-sm mb-2">y₁ = A sin(ωt), y₂ = A sin(ωt + φ)</p>
                    <p className="text-sm mb-2">Combined: y = 2A cos(φ/2) sin(ωt + φ/2)</p>
                    <ul className="text-sm space-y-1">
                      <li>• Constructive (φ = 0°): Amplitude doubles</li>
                      <li>• Destructive (φ = 180°): Waves cancel</li>
                      <li>• Partial interference: Amplitude = 2A cos(φ/2)</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-700">Seasonal and Cyclical Phenomena</CardTitle>
              </CardHeader>
              <CardContent className="text-green-700">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">Temperature Modeling</p>
                    <p className="text-sm mb-2">T(d) = A cos(2π(d - d₀)/365) + T_avg</p>
                    <ul className="text-sm space-y-1">
                      <li>• A: Half the annual temperature range</li>
                      <li>• d₀: Day of minimum temperature</li>
                      <li>• T_avg: Average annual temperature</li>
                      <li>• Period: 365 days (one year)</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    },
    {
      id: 'engineering-applications',
      title: 'Engineering and Technology',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-purple-600 mb-4">Professional Applications</h3>
            <p className="text-lg leading-relaxed">
              Engineers and technologists use trigonometry daily to solve complex problems in 
              structural design, electrical systems, navigation, and computer graphics.
            </p>
          </div>
          
          <div className="space-y-6">
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-700">Structural Engineering</CardTitle>
              </CardHeader>
              <CardContent className="text-purple-700">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">Bridge Cable Analysis</p>
                    <p className="text-sm mb-2">Tension in cable at angle θ: T = T₀ / cos(θ)</p>
                    <ul className="text-sm space-y-1">
                      <li>• Small angles minimize tension</li>
                      <li>• At θ = 60°, tension doubles</li>
                      <li>• Critical for safety calculations</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">Force Resolution</p>
                    <ul className="text-sm space-y-1">
                      <li>• Horizontal: F_x = F cos(θ)</li>
                      <li>• Vertical: F_y = F sin(θ)</li>
                      <li>• Essential for equilibrium analysis</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-orange-50 border-orange-200">
              <CardHeader>
                <CardTitle className="text-orange-700">Electrical Engineering</CardTitle>
              </CardHeader>
              <CardContent className="text-orange-700">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">AC Circuit Analysis</p>
                    <ul className="text-sm space-y-1">
                      <li>• Voltage: V(t) = V₀ cos(ωt)</li>
                      <li>• Current: I(t) = I₀ cos(ωt - φ)</li>
                      <li>• Power: P_avg = (V₀I₀/2) cos(φ)</li>
                      <li>• Phase relationships critical for efficiency</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-teal-50 border-teal-200">
              <CardHeader>
                <CardTitle className="text-teal-700">Navigation and GPS</CardTitle>
              </CardHeader>
              <CardContent className="text-teal-700">
                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="font-semibold mb-2">Great Circle Distance</p>
                    <p className="text-sm mb-2">d = R × arccos[sin(lat₁)sin(lat₂) + cos(lat₁)cos(lat₂)cos(Δlon)]</p>
                    <ul className="text-sm space-y-1">
                      <li>• Shortest path between two points on Earth</li>
                      <li>• Essential for aviation and maritime navigation</li>
                      <li>• GPS systems use trilateration with trigonometry</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    },
    {
      id: 'comprehensive-assessment',
      title: 'Comprehensive Assessment',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-indigo-600 mb-4">Final Mastery Assessment</h3>
            <p className="text-lg leading-relaxed">
              This comprehensive assessment tests your mastery across all course topics. It includes 
              fundamental concepts, applied problem solving, and advanced applications.
            </p>
          </div>
          
          <FinalAssessment onComplete={(score) => {
            setAssessmentScore(score)
            if (score >= 80) {
              setShowCertificate(true)
            }
          }} />
        </div>
      )
    },
    {
      id: 'course-completion',
      title: 'Course Completion',
      content: (
        <div className="space-y-6">
          <div className="prose max-w-none">
            <h3 className="text-2xl font-bold text-gold-600 mb-4">Congratulations!</h3>
            <p className="text-lg leading-relaxed">
              You have successfully completed the comprehensive Interactive Trigonometry Course. 
              Your journey through the fundamental concepts, advanced applications, and real-world 
              problem solving has equipped you with powerful mathematical tools.
            </p>
          </div>
          
          {showCertificate && <CourseCertificate score={assessmentScore} />}
          
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-700">Pathways Forward</CardTitle>
            </CardHeader>
            <CardContent className="text-blue-700">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Academic Pathways:</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Pre-Calculus and Calculus</li>
                    <li>• Physics and Engineering</li>
                    <li>• Computer Science and Graphics</li>
                    <li>• Advanced Mathematics</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Career Applications:</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Architecture and Construction</li>
                    <li>• Aviation and Aerospace</li>
                    <li>• Music and Audio Engineering</li>
                    <li>• Medical Imaging and Biomechanics</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-yellow-50 border-yellow-200">
            <CardHeader>
              <CardTitle className="text-yellow-700">Final Reflection</CardTitle>
            </CardHeader>
            <CardContent className="text-yellow-700">
              <div className="space-y-3">
                <p className="text-sm">
                  <strong>Remember:</strong> Trigonometry is more than formulas and techniques—it's a way 
                  of understanding the world's patterns and relationships. The skills you've developed 
                  will serve you well in academic pursuits, professional endeavors, and personal 
                  exploration of the mathematical universe.
                </p>
                <p className="text-sm">
                  Continue to seek out new applications, challenge yourself with complex problems, 
                  and appreciate the elegant beauty of trigonometric relationships.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    }
  ]
  
  const handleSectionComplete = (sectionIndex) => {
    setCompletedSections(prev => new Set([...prev, sectionIndex]))
    if (sectionIndex < sections.length - 1) {
      setCurrentSection(sectionIndex + 1)
    }
  }
  
  const progress = ((completedSections.size) / sections.length) * 100
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gold-50 via-yellow-50 to-orange-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Course
          </Button>
          <Badge variant="outline" className="text-lg px-4 py-2">
            Lesson 8 of 8
          </Badge>
        </div>
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Advanced Applications and Assessment
          </h1>
          <p className="text-xl text-gray-600">
            Capstone lesson bringing everything together
          </p>
        </div>
        
        {/* Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Final Lesson Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Sections Completed</span>
                <span>{completedSections.size} of {sections.length}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
        
        {/* Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-2 mb-8">
          {sections.map((section, index) => (
            <Button
              key={section.id}
              variant={currentSection === index ? "default" : "outline"}
              size="sm"
              onClick={() => setCurrentSection(index)}
              className="flex items-center gap-2"
            >
              {completedSections.has(index) && <CheckCircle className="h-4 w-4" />}
              {section.title}
            </Button>
          ))}
        </div>
        
        {/* Current Section Content */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">
              {sections[currentSection].title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sections[currentSection].content}
            
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                disabled={currentSection === 0}
              >
                Previous
              </Button>
              
              <div className="flex gap-2">
                {!completedSections.has(currentSection) && (
                  <Button
                    onClick={() => handleSectionComplete(currentSection)}
                    className="flex items-center gap-2"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Mark Complete
                  </Button>
                )}
                
                {currentSection < sections.length - 1 ? (
                  <Button
                    onClick={() => setCurrentSection(currentSection + 1)}
                  >
                    Next
                  </Button>
                ) : completedSections.size === sections.length && (
                  <Button
                    onClick={onComplete}
                    className="bg-gold-600 hover:bg-gold-700 flex items-center gap-2"
                  >
                    <Award className="h-4 w-4" />
                    Complete Course
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Final Assessment Component
const FinalAssessment = ({ onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  
  const questions = [
    {
      id: 1,
      question: "What is the exact value of sin(150°)?",
      options: ["1/2", "-1/2", "√3/2", "-√3/2"],
      correct: 0,
      explanation: "sin(150°) = sin(180° - 30°) = sin(30°) = 1/2"
    },
    {
      id: 2,
      question: "Which identity is equivalent to 1 + tan²(θ)?",
      options: ["sin²(θ)", "cos²(θ)", "sec²(θ)", "csc²(θ)"],
      correct: 2,
      explanation: "The Pythagorean identity: 1 + tan²(θ) = sec²(θ)"
    },
    {
      id: 3,
      question: "What is the period of y = sin(3x)?",
      options: ["π/3", "2π/3", "π", "2π"],
      correct: 1,
      explanation: "Period = 2π/3 since the coefficient of x is 3"
    },
    {
      id: 4,
      question: "Solve: 2sin(x) - √3 = 0 for x ∈ [0°, 360°)",
      options: ["30°, 150°", "60°, 120°", "45°, 135°", "30°, 330°"],
      correct: 1,
      explanation: "sin(x) = √3/2, so x = 60° and 120°"
    },
    {
      id: 5,
      question: "A Ferris wheel with radius 20m completes one rotation in 8 minutes. What's the height function if the center is 25m above ground?",
      options: ["h(t) = 20cos(πt/4) + 25", "h(t) = 20sin(πt/4) + 25", "h(t) = 25cos(πt/4) + 20", "h(t) = 20cos(2πt/8) + 25"],
      correct: 0,
      explanation: "h(t) = 20cos(πt/4) + 25, where ω = 2π/8 = π/4"
    }
  ]
  
  const handleAnswer = (questionIndex, answerIndex) => {
    setAnswers(prev => ({
      ...prev,
      [questionIndex]: answerIndex
    }))
  }
  
  const calculateScore = () => {
    let correct = 0
    questions.forEach((q, index) => {
      if (answers[index] === q.correct) {
        correct++
      }
    })
    return Math.round((correct / questions.length) * 100)
  }
  
  const submitAssessment = () => {
    setShowResults(true)
    const score = calculateScore()
    onComplete(score)
  }
  
  if (showResults) {
    const score = calculateScore()
    return (
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Trophy className="h-6 w-6" />
            Assessment Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center space-y-4">
            <div className="text-4xl font-bold text-green-600">{score}%</div>
            <div className="text-lg">
              {score >= 90 ? "Excellent! Outstanding mastery!" :
               score >= 80 ? "Great job! Strong understanding!" :
               score >= 70 ? "Good work! Solid foundation!" :
               "Keep practicing! You're on the right track!"}
            </div>
            {score >= 80 && (
              <Badge className="bg-gold-500 text-white">
                <Star className="h-4 w-4 mr-1" />
                Course Completed with Distinction
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }
  
  return (
    <Card className="bg-indigo-50 border-indigo-200">
      <CardHeader>
        <CardTitle className="text-indigo-700">
          Question {currentQuestion + 1} of {questions.length}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-lg font-semibold">{questions[currentQuestion].question}</p>
          
          <div className="space-y-2">
            {questions[currentQuestion].options.map((option, index) => (
              <Button
                key={index}
                variant={answers[currentQuestion] === index ? "default" : "outline"}
                className="w-full text-left justify-start"
                onClick={() => handleAnswer(currentQuestion, index)}
              >
                {String.fromCharCode(65 + index)}. {option}
              </Button>
            ))}
          </div>
          
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
              disabled={currentQuestion === 0}
            >
              Previous
            </Button>
            
            {currentQuestion < questions.length - 1 ? (
              <Button
                onClick={() => setCurrentQuestion(currentQuestion + 1)}
                disabled={answers[currentQuestion] === undefined}
              >
                Next
              </Button>
            ) : (
              <Button
                onClick={submitAssessment}
                disabled={Object.keys(answers).length < questions.length}
                className="bg-green-600 hover:bg-green-700"
              >
                Submit Assessment
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Course Certificate Component
const CourseCertificate = ({ score }) => {
  return (
    <Card className="bg-gradient-to-r from-gold-50 to-yellow-50 border-gold-300 border-2">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <Award className="h-16 w-16 text-gold-500" />
        </div>
        <CardTitle className="text-2xl text-gold-700">Certificate of Completion</CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <div className="text-lg">
          This certifies that you have successfully completed the
        </div>
        <div className="text-2xl font-bold text-gold-600">
          Interactive Trigonometry Course
        </div>
        <div className="text-lg">
          with a final score of <span className="font-bold text-gold-600">{score}%</span>
        </div>
        <div className="text-sm text-gray-600">
          Demonstrating mastery of trigonometric concepts, problem-solving skills, and real-world applications
        </div>
        <div className="pt-4 border-t border-gold-200">
          <div className="text-sm text-gray-500">
            Completed on {new Date().toLocaleDateString()}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default Lesson8

