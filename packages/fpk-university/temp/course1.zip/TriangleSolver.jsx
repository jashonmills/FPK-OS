import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Calculator, RotateCcw, Triangle } from 'lucide-react'

const TriangleSolver = () => {
  const [triangle, setTriangle] = useState({
    angle: 30, // angle in degrees
    opposite: '',
    adjacent: '',
    hypotenuse: ''
  })
  
  const [solving, setSolving] = useState(null) // which side we're solving for
  const [solution, setSolution] = useState(null)
  const [showSteps, setShowSteps] = useState(false)
  
  // Calculate missing sides based on known values
  const calculateSides = () => {
    const angleRad = (triangle.angle * Math.PI) / 180
    const sin = Math.sin(angleRad)
    const cos = Math.cos(angleRad)
    const tan = Math.tan(angleRad)
    
    let steps = []
    let result = {}
    
    if (triangle.hypotenuse && !triangle.opposite && !triangle.adjacent) {
      // Given hypotenuse, find opposite and adjacent
      const opp = parseFloat(triangle.hypotenuse) * sin
      const adj = parseFloat(triangle.hypotenuse) * cos
      
      steps = [
        `Given: Hypotenuse = ${triangle.hypotenuse}, Angle = ${triangle.angle}°`,
        `Using SOHCAHTOA:`,
        `sin(${triangle.angle}°) = Opposite / Hypotenuse`,
        `${sin.toFixed(4)} = Opposite / ${triangle.hypotenuse}`,
        `Opposite = ${triangle.hypotenuse} × ${sin.toFixed(4)} = ${opp.toFixed(2)}`,
        ``,
        `cos(${triangle.angle}°) = Adjacent / Hypotenuse`,
        `${cos.toFixed(4)} = Adjacent / ${triangle.hypotenuse}`,
        `Adjacent = ${triangle.hypotenuse} × ${cos.toFixed(4)} = ${adj.toFixed(2)}`
      ]
      
      result = { opposite: opp.toFixed(2), adjacent: adj.toFixed(2) }
      setSolving('both')
    }
    else if (triangle.opposite && !triangle.hypotenuse && !triangle.adjacent) {
      // Given opposite, find hypotenuse and adjacent
      const hyp = parseFloat(triangle.opposite) / sin
      const adj = parseFloat(triangle.opposite) / tan
      
      steps = [
        `Given: Opposite = ${triangle.opposite}, Angle = ${triangle.angle}°`,
        `Using SOHCAHTOA:`,
        `sin(${triangle.angle}°) = Opposite / Hypotenuse`,
        `${sin.toFixed(4)} = ${triangle.opposite} / Hypotenuse`,
        `Hypotenuse = ${triangle.opposite} / ${sin.toFixed(4)} = ${hyp.toFixed(2)}`,
        ``,
        `tan(${triangle.angle}°) = Opposite / Adjacent`,
        `${tan.toFixed(4)} = ${triangle.opposite} / Adjacent`,
        `Adjacent = ${triangle.opposite} / ${tan.toFixed(4)} = ${adj.toFixed(2)}`
      ]
      
      result = { hypotenuse: hyp.toFixed(2), adjacent: adj.toFixed(2) }
      setSolving('both')
    }
    else if (triangle.adjacent && !triangle.hypotenuse && !triangle.opposite) {
      // Given adjacent, find hypotenuse and opposite
      const hyp = parseFloat(triangle.adjacent) / cos
      const opp = parseFloat(triangle.adjacent) * tan
      
      steps = [
        `Given: Adjacent = ${triangle.adjacent}, Angle = ${triangle.angle}°`,
        `Using SOHCAHTOA:`,
        `cos(${triangle.angle}°) = Adjacent / Hypotenuse`,
        `${cos.toFixed(4)} = ${triangle.adjacent} / Hypotenuse`,
        `Hypotenuse = ${triangle.adjacent} / ${cos.toFixed(4)} = ${hyp.toFixed(2)}`,
        ``,
        `tan(${triangle.angle}°) = Opposite / Adjacent`,
        `${tan.toFixed(4)} = Opposite / ${triangle.adjacent}`,
        `Opposite = ${triangle.adjacent} × ${tan.toFixed(4)} = ${opp.toFixed(2)}`
      ]
      
      result = { hypotenuse: hyp.toFixed(2), opposite: opp.toFixed(2) }
      setSolving('both')
    }
    
    setSolution({ steps, result })
    setShowSteps(true)
  }
  
  const reset = () => {
    setTriangle({
      angle: 30,
      opposite: '',
      adjacent: '',
      hypotenuse: ''
    })
    setSolution(null)
    setSolving(null)
    setShowSteps(false)
  }
  
  const handleInputChange = (field, value) => {
    setTriangle(prev => ({ ...prev, [field]: value }))
    setSolution(null)
    setShowSteps(false)
  }
  
  // Check if we have enough information to solve
  const canSolve = () => {
    const filledFields = [triangle.opposite, triangle.adjacent, triangle.hypotenuse].filter(val => val !== '').length
    return filledFields === 1 && triangle.angle > 0 && triangle.angle < 90
  }
  
  // SVG Triangle visualization
  const renderTriangle = () => {
    const width = 300
    const height = 200
    const angleRad = (triangle.angle * Math.PI) / 180
    
    // Triangle vertices
    const A = { x: 50, y: height - 30 } // bottom left (right angle)
    const B = { x: width - 50, y: height - 30 } // bottom right
    const C = { x: 50, y: 50 } // top left
    
    // Adjust C based on angle
    const adjacent = B.x - A.x
    const opposite = adjacent * Math.tan(angleRad)
    C.y = A.y - opposite
    
    return (
      <svg width={width} height={height} className="border border-gray-200 rounded-lg bg-white">
        {/* Triangle */}
        <polygon
          points={`${A.x},${A.y} ${B.x},${B.y} ${C.x},${C.y}`}
          fill="rgba(59, 130, 246, 0.1)"
          stroke="#3b82f6"
          strokeWidth="2"
        />
        
        {/* Right angle indicator */}
        <path
          d={`M ${A.x + 15} ${A.y} L ${A.x + 15} ${A.y - 15} L ${A.x} ${A.y - 15}`}
          fill="none"
          stroke="#3b82f6"
          strokeWidth="2"
        />
        
        {/* Angle arc */}
        <path
          d={`M ${B.x - 30} ${B.y} A 30 30 0 0 0 ${B.x - 30 * Math.cos(angleRad)} ${B.y - 30 * Math.sin(angleRad)}`}
          fill="none"
          stroke="#dc2626"
          strokeWidth="2"
        />
        
        {/* Labels */}
        <text x={B.x - 20} y={B.y + 20} textAnchor="middle" className="text-sm font-semibold fill-red-600">
          {triangle.angle}°
        </text>
        
        <text x={(A.x + B.x) / 2} y={B.y + 20} textAnchor="middle" className="text-sm font-semibold fill-purple-600">
          Adjacent {triangle.adjacent && `(${triangle.adjacent})`}
        </text>
        
        <text x={A.x - 30} y={(A.y + C.y) / 2} textAnchor="middle" className="text-sm font-semibold fill-green-600">
          Opposite {triangle.opposite && `(${triangle.opposite})`}
        </text>
        
        <text x={(B.x + C.x) / 2 + 20} y={(B.y + C.y) / 2} textAnchor="middle" className="text-sm font-semibold fill-blue-600">
          Hypotenuse {triangle.hypotenuse && `(${triangle.hypotenuse})`}
        </text>
      </svg>
    )
  }
  
  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Triangle className="h-6 w-6" />
          Interactive Triangle Solver
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Input Panel */}
          <div className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="angle">Angle (degrees)</Label>
                <Input
                  id="angle"
                  type="number"
                  value={triangle.angle}
                  onChange={(e) => handleInputChange('angle', parseFloat(e.target.value) || 0)}
                  min="1"
                  max="89"
                  className="mt-1"
                />
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="opposite">Opposite</Label>
                  <Input
                    id="opposite"
                    type="number"
                    value={triangle.opposite}
                    onChange={(e) => handleInputChange('opposite', e.target.value)}
                    placeholder="?"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="adjacent">Adjacent</Label>
                  <Input
                    id="adjacent"
                    type="number"
                    value={triangle.adjacent}
                    onChange={(e) => handleInputChange('adjacent', e.target.value)}
                    placeholder="?"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="hypotenuse">Hypotenuse</Label>
                  <Input
                    id="hypotenuse"
                    type="number"
                    value={triangle.hypotenuse}
                    onChange={(e) => handleInputChange('hypotenuse', e.target.value)}
                    placeholder="?"
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button 
                onClick={calculateSides} 
                disabled={!canSolve()}
                className="flex items-center gap-2"
              >
                <Calculator className="h-4 w-4" />
                Solve Triangle
              </Button>
              <Button variant="outline" onClick={reset} className="flex items-center gap-2">
                <RotateCcw className="h-4 w-4" />
                Reset
              </Button>
            </div>
            
            {!canSolve() && (
              <Alert>
                <AlertDescription>
                  Enter exactly one side length and an angle (1-89°) to solve the triangle.
                </AlertDescription>
              </Alert>
            )}
            
            {/* SOHCAHTOA Reference */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">SOHCAHTOA Reference</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-green-50">SOH</Badge>
                    <span><strong>S</strong>ine = <strong>O</strong>pposite / <strong>H</strong>ypotenuse</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-purple-50">CAH</Badge>
                    <span><strong>C</strong>osine = <strong>A</strong>djacent / <strong>H</strong>ypotenuse</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-blue-50">TOA</Badge>
                    <span><strong>T</strong>angent = <strong>O</strong>pposite / <strong>A</strong>djacent</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Visualization Panel */}
          <div className="space-y-6">
            <div className="flex justify-center">
              {renderTriangle()}
            </div>
            
            {solution && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Solution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(solution.result).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="capitalize font-medium">{key}:</span>
                        <span className="font-mono">{value}</span>
                      </div>
                    ))}
                  </div>
                  
                  {showSteps && (
                    <div className="mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                      >
                        {showSteps ? 'Hide' : 'Show'} Steps
                      </Button>
                      
                      <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                        <h4 className="font-semibold mb-2">Step-by-step solution:</h4>
                        <div className="space-y-1 text-sm font-mono">
                          {solution.steps.map((step, index) => (
                            <div key={index} className={step === '' ? 'h-2' : ''}>
                              {step}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default TriangleSolver

