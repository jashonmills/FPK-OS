import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Trophy, Target, BookOpen } from 'lucide-react'
import QuizAssessment from '../interactive/QuizAssessment.jsx'

const Lesson7 = ({ onComplete, onNext }) => {
  const [showAssessment, setShowAssessment] = useState(false)
  const [assessmentComplete, setAssessmentComplete] = useState(false)

  const assessmentQuestions = [
    {
      id: 1,
      question: "Solve: x + 12 = 25",
      type: "input",
      answer: 13,
      explanation: "Subtract 12 from both sides: x = 25 - 12 = 13"
    },
    {
      id: 2,
      question: "Solve: 5x = 35",
      type: "input",
      answer: 7,
      explanation: "Divide both sides by 5: x = 35 ÷ 5 = 7"
    },
    {
      id: 3,
      question: "Solve: 3x + 8 = 23",
      type: "input",
      answer: 5,
      explanation: "First subtract 8: 3x = 15, then divide by 3: x = 5"
    },
    {
      id: 4,
      question: "Solve: 2x - 7 = 11",
      type: "input",
      answer: 9,
      explanation: "First add 7: 2x = 18, then divide by 2: x = 9"
    },
    {
      id: 5,
      question: "What is the inverse operation of multiplication?",
      type: "multiple",
      options: ["Addition", "Subtraction", "Division", "Exponentiation"],
      answer: 2,
      explanation: "Division is the inverse operation of multiplication"
    },
    {
      id: 6,
      question: "Solve: x/4 = 8",
      type: "input",
      answer: 32,
      explanation: "Multiply both sides by 4: x = 8 × 4 = 32"
    },
    {
      id: 7,
      question: "Solve: 4x + 3 = 2x + 15",
      type: "input",
      answer: 6,
      explanation: "Subtract 2x from both sides: 2x + 3 = 15, then subtract 3: 2x = 12, finally divide by 2: x = 6"
    },
    {
      id: 8,
      question: "A phone plan costs $25 per month plus $0.05 per text. If the bill is $30, how many texts were sent?",
      type: "input",
      answer: 100,
      explanation: "Set up equation: 25 + 0.05t = 30. Subtract 25: 0.05t = 5. Divide by 0.05: t = 100"
    }
  ]

  const handleAssessmentComplete = (score, passed) => {
    setAssessmentComplete(true)
    if (passed) {
      onComplete()
    }
  }

  if (showAssessment) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="h-6 w-6 text-blue-600" />
            <h1 className="text-3xl font-bold">Lesson 7: Comprehensive Assessment</h1>
          </div>
          <p className="text-gray-600">Demonstrate your mastery of linear equations</p>
        </div>

        <QuizAssessment 
          questions={assessmentQuestions}
          masteryScore={70}
          onComplete={handleAssessmentComplete}
        />

        {assessmentComplete && (
          <div className="mt-6 text-center">
            <Button onClick={onNext} className="bg-green-600 hover:bg-green-700">
              Complete Course
            </Button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Trophy className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 7: Comprehensive Assessment</h1>
        </div>
        <p className="text-gray-600">Demonstrate your mastery of linear equations</p>
      </div>

      <div className="space-y-6">
        <Card className="border-2 border-blue-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-6 w-6 text-blue-600" />
              Assessment Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-lg">
                Welcome to the final assessment! This comprehensive quiz will test your understanding 
                of all the concepts covered in this module.
              </p>
              
              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">What You'll Be Tested On</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li>• One-step equations</li>
                      <li>• Multi-step equations</li>
                      <li>• Equations with variables on both sides</li>
                      <li>• Real-world applications</li>
                      <li>• Inverse operations</li>
                      <li>• Solution verification</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Assessment Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li>• 8 questions total</li>
                      <li>• Mixed question types</li>
                      <li>• 70% required to pass</li>
                      <li>• Immediate feedback provided</li>
                      <li>• Can retake if needed</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
                <div className="flex items-start gap-2">
                  <BookOpen className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-yellow-800 mb-1">Tips for Success:</p>
                    <ul className="text-yellow-700 text-sm space-y-1">
                      <li>• Read each question carefully</li>
                      <li>• Show your work step by step</li>
                      <li>• Check your answers by substitution</li>
                      <li>• Take your time - there's no rush</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button 
            onClick={() => setShowAssessment(true)}
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3"
          >
            Start Assessment
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Lesson7

