import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Calculator } from 'lucide-react'

const Lesson4 = ({ onComplete, onNext }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Calculator className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 4: Multi-Step Equations</h1>
        </div>
        <p className="text-gray-600">Tackle complex equations with multiple steps</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Multi-Step Equation Solving</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Content for multi-step equations will be implemented here.</p>
          <div className="flex justify-between mt-8">
            <Button variant="outline" disabled>Previous</Button>
            <Button onClick={() => { onComplete(); onNext(); }} className="bg-green-600 hover:bg-green-700">
              Complete Lesson
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Lesson4

