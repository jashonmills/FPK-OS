import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { CheckCircle, PlayCircle } from 'lucide-react'

const Lesson3 = ({ onComplete, onNext }) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [completedSections, setCompletedSections] = useState(new Set())

  const sections = [
    {
      title: "Understanding Inverse Operations",
      content: (
        <div className="space-y-4">
          <p className="text-lg">
            Every mathematical operation has an inverse – an operation that "undoes" it. 
            Mastering inverse operations is the key to solving any linear equation.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Inverse Operations Table</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span>Addition (+)</span>
                    <span>Subtraction (-)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span>Subtraction (-)</span>
                    <span>Addition (+)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span>Multiplication (×)</span>
                    <span>Division (÷)</span>
                  </div>
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span>Division (÷)</span>
                    <span>Multiplication (×)</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Example: 2x + 3 = 11</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div>1. Subtract 3 from both sides: 2x = 8</div>
                  <div>2. Divide by 2: x = 4</div>
                  <div className="mt-3 p-2 bg-green-50 rounded">
                    <strong>Solution: x = 4</strong>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    }
  ]

  const markSectionComplete = (index) => {
    const newCompleted = new Set(completedSections)
    newCompleted.add(index)
    setCompletedSections(newCompleted)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <PlayCircle className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 3: Inverse Operations Mastery</h1>
        </div>
        <p className="text-gray-600">Understand the power of undoing operations</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{sections[currentSection].title}</CardTitle>
        </CardHeader>
        <CardContent>
          {sections[currentSection].content}
          
          <div className="flex justify-between mt-8">
            <Button variant="outline" disabled>Previous</Button>
            <Button
              onClick={() => {
                markSectionComplete(currentSection)
                onComplete()
                onNext()
              }}
              className="bg-green-600 hover:bg-green-700"
            >
              Complete Lesson
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Lesson3

