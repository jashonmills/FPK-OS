import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { RotateCcw, Play, Pause } from 'lucide-react'

const FunctionGrapher = () => {
  const canvasRef = useRef(null)
  const [functionType, setFunctionType] = useState('sin')
  const [amplitude, setAmplitude] = useState([1])
  const [period, setPeriod] = useState([1])
  const [phaseShift, setPhaseShift] = useState([0])
  const [verticalShift, setVerticalShift] = useState([0])
  const [isAnimating, setIsAnimating] = useState(false)
  const [animationTime, setAnimationTime] = useState(0)
  
  const width = 600
  const height = 400
  const centerX = width / 2
  const centerY = height / 2
  const scale = 50 // pixels per unit
  
  useEffect(() => {
    drawGraph()
  }, [functionType, amplitude, period, phaseShift, verticalShift, animationTime])
  
  useEffect(() => {
    let animationFrame
    if (isAnimating) {
      const animate = () => {
        setAnimationTime(prev => prev + 0.05)
        animationFrame = requestAnimationFrame(animate)
      }
      animationFrame = requestAnimationFrame(animate)
    }
    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame)
      }
    }
  }, [isAnimating])
  
  const drawGraph = () => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    ctx.clearRect(0, 0, width, height)
    
    // Draw grid
    drawGrid(ctx)
    
    // Draw axes
    drawAxes(ctx)
    
    // Draw function
    drawFunction(ctx)
    
    // Draw labels
    drawLabels(ctx)
  }
  
  const drawGrid = (ctx) => {
    ctx.strokeStyle = '#e5e7eb'
    ctx.lineWidth = 1
    
    // Vertical grid lines
    for (let x = 0; x <= width; x += scale) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }
    
    // Horizontal grid lines
    for (let y = 0; y <= height; y += scale) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(width, y)
      ctx.stroke()
    }
  }
  
  const drawAxes = (ctx) => {
    ctx.strokeStyle = '#374151'
    ctx.lineWidth = 2
    
    // X-axis
    ctx.beginPath()
    ctx.moveTo(0, centerY)
    ctx.lineTo(width, centerY)
    ctx.stroke()
    
    // Y-axis
    ctx.beginPath()
    ctx.moveTo(centerX, 0)
    ctx.lineTo(centerX, height)
    ctx.stroke()
    
    // Axis labels
    ctx.fillStyle = '#374151'
    ctx.font = '12px Arial'
    ctx.textAlign = 'center'
    
    // X-axis labels
    for (let i = -6; i <= 6; i++) {
      if (i !== 0) {
        const x = centerX + i * scale
        ctx.fillText(i.toString(), x, centerY + 15)
      }
    }
    
    // Y-axis labels
    ctx.textAlign = 'right'
    for (let i = -4; i <= 4; i++) {
      if (i !== 0) {
        const y = centerY - i * scale
        ctx.fillText(i.toString(), centerX - 5, y + 4)
      }
    }
  }
  
  const drawFunction = (ctx) => {
    const A = amplitude[0]
    const B = 2 * Math.PI / (period[0] * 2 * Math.PI) // Convert period to frequency
    const C = phaseShift[0]
    const D = verticalShift[0]
    
    ctx.strokeStyle = getFunctionColor()
    ctx.lineWidth = 3
    ctx.beginPath()
    
    let firstPoint = true
    
    for (let pixelX = 0; pixelX <= width; pixelX += 2) {
      const mathX = (pixelX - centerX) / scale
      let mathY
      
      switch (functionType) {
        case 'sin':
          mathY = A * Math.sin(B * (mathX - C) + animationTime) + D
          break
        case 'cos':
          mathY = A * Math.cos(B * (mathX - C) + animationTime) + D
          break
        case 'tan':
          mathY = A * Math.tan(B * (mathX - C) + animationTime) + D
          // Limit tangent values to prevent extreme spikes
          if (Math.abs(mathY) > 10) continue
          break
        default:
          mathY = 0
      }
      
      const pixelY = centerY - mathY * scale
      
      // Only draw if the point is within reasonable bounds
      if (pixelY >= -100 && pixelY <= height + 100) {
        if (firstPoint) {
          ctx.moveTo(pixelX, pixelY)
          firstPoint = false
        } else {
          ctx.lineTo(pixelX, pixelY)
        }
      } else {
        firstPoint = true
      }
    }
    
    ctx.stroke()
  }
  
  const drawLabels = (ctx) => {
    ctx.fillStyle = '#1f2937'
    ctx.font = 'bold 14px Arial'
    ctx.textAlign = 'left'
    
    const equation = getEquationString()
    ctx.fillText(equation, 10, 25)
    
    // Draw key characteristics
    ctx.font = '12px Arial'
    ctx.fillText(`Amplitude: ${amplitude[0]}`, 10, 45)
    ctx.fillText(`Period: ${(2 * Math.PI / (2 * Math.PI / (period[0] * 2 * Math.PI))).toFixed(2)}`, 10, 60)
    ctx.fillText(`Phase Shift: ${phaseShift[0]}`, 10, 75)
    ctx.fillText(`Vertical Shift: ${verticalShift[0]}`, 10, 90)
  }
  
  const getFunctionColor = () => {
    switch (functionType) {
      case 'sin': return '#ef4444' // red
      case 'cos': return '#3b82f6' // blue
      case 'tan': return '#10b981' // green
      default: return '#6b7280' // gray
    }
  }
  
  const getEquationString = () => {
    const A = amplitude[0] === 1 ? '' : amplitude[0] === -1 ? '-' : amplitude[0]
    const B = period[0] === 1 ? '' : period[0]
    const C = phaseShift[0] === 0 ? '' : phaseShift[0] > 0 ? ` - ${phaseShift[0]}` : ` + ${Math.abs(phaseShift[0])}`
    const D = verticalShift[0] === 0 ? '' : verticalShift[0] > 0 ? ` + ${verticalShift[0]}` : ` - ${Math.abs(verticalShift[0])}`
    
    return `y = ${A}${functionType}(${B}x${C})${D}`
  }
  
  const resetParameters = () => {
    setAmplitude([1])
    setPeriod([1])
    setPhaseShift([0])
    setVerticalShift([0])
    setAnimationTime(0)
    setIsAnimating(false)
  }
  
  const presetFunctions = [
    { name: 'Standard Sine', type: 'sin', a: 1, b: 1, c: 0, d: 0 },
    { name: 'Standard Cosine', type: 'cos', a: 1, b: 1, c: 0, d: 0 },
    { name: 'Standard Tangent', type: 'tan', a: 1, b: 1, c: 0, d: 0 },
    { name: 'High Amplitude', type: 'sin', a: 3, b: 1, c: 0, d: 0 },
    { name: 'High Frequency', type: 'sin', a: 1, b: 2, c: 0, d: 0 },
    { name: 'Phase Shifted', type: 'cos', a: 1, b: 1, c: 1, d: 0 },
    { name: 'Vertically Shifted', type: 'sin', a: 1, b: 1, c: 0, d: 2 }
  ]
  
  const loadPreset = (preset) => {
    setFunctionType(preset.type)
    setAmplitude([preset.a])
    setPeriod([preset.b])
    setPhaseShift([preset.c])
    setVerticalShift([preset.d])
    setAnimationTime(0)
    setIsAnimating(false)
  }
  
  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Interactive Function Grapher
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Controls */}
          <div className="space-y-6">
            <div>
              <Label>Function Type</Label>
              <Select value={functionType} onValueChange={setFunctionType}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sin">Sine</SelectItem>
                  <SelectItem value="cos">Cosine</SelectItem>
                  <SelectItem value="tan">Tangent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Amplitude: {amplitude[0]}</Label>
              <Slider
                value={amplitude}
                onValueChange={setAmplitude}
                min={-5}
                max={5}
                step={0.1}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label>Period Multiplier: {period[0]}</Label>
              <Slider
                value={period}
                onValueChange={setPeriod}
                min={0.1}
                max={3}
                step={0.1}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label>Phase Shift: {phaseShift[0]}</Label>
              <Slider
                value={phaseShift}
                onValueChange={setPhaseShift}
                min={-3}
                max={3}
                step={0.1}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label>Vertical Shift: {verticalShift[0]}</Label>
              <Slider
                value={verticalShift}
                onValueChange={setVerticalShift}
                min={-3}
                max={3}
                step={0.1}
                className="mt-2"
              />
            </div>
            
            <div className="flex gap-2">
              <Button
                onClick={() => setIsAnimating(!isAnimating)}
                variant={isAnimating ? "destructive" : "default"}
                className="flex items-center gap-2"
              >
                {isAnimating ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                {isAnimating ? 'Pause' : 'Animate'}
              </Button>
              <Button onClick={resetParameters} variant="outline" className="flex items-center gap-2">
                <RotateCcw className="h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          
          {/* Graph */}
          <div className="lg:col-span-2">
            <div className="border border-gray-200 rounded-lg p-4 bg-white">
              <canvas
                ref={canvasRef}
                width={width}
                height={height}
                className="border border-gray-300 rounded"
              />
            </div>
            
            <div className="mt-4">
              <h4 className="font-semibold mb-2">Current Equation:</h4>
              <Badge variant="outline" className="text-lg px-3 py-1">
                {getEquationString()}
              </Badge>
            </div>
          </div>
        </div>
        
        {/* Presets */}
        <div className="mt-6">
          <h4 className="font-semibold mb-3">Quick Presets:</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
            {presetFunctions.map((preset, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => loadPreset(preset)}
                className="text-xs"
              >
                {preset.name}
              </Button>
            ))}
          </div>
        </div>
        
        {/* Information Panel */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-blue-700">Function Properties</CardTitle>
          </CardHeader>
          <CardContent className="text-blue-700">
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <p><strong>Domain:</strong> {functionType === 'tan' ? 'All real numbers except x = π/2 + nπ' : 'All real numbers'}</p>
                <p><strong>Range:</strong> {functionType === 'tan' ? 'All real numbers' : `[${verticalShift[0] - Math.abs(amplitude[0])}, ${verticalShift[0] + Math.abs(amplitude[0])}]`}</p>
              </div>
              <div>
                <p><strong>Period:</strong> {functionType === 'tan' ? (Math.PI / period[0]).toFixed(2) : (2 * Math.PI / period[0]).toFixed(2)}</p>
                <p><strong>Amplitude:</strong> {functionType === 'tan' ? 'N/A' : Math.abs(amplitude[0])}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  )
}

export default FunctionGrapher

