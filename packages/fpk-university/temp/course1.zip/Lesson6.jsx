import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { CheckCircle } from 'lucide-react'

const Lesson6 = ({ onComplete, onNext }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 6: Verification and Error Analysis</h1>
        </div>
        <p className="text-gray-600">Learn to check solutions and avoid common mistakes</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Solution Verification</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Content for verification and error analysis will be implemented here.</p>
          <div className="flex justify-between mt-8">
            <Button variant="outline" disabled>Previous</Button>
            <Button onClick={() => { onComplete(); onNext(); }} className="bg-green-600 hover:bg-green-700">
              Complete Lesson
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Lesson6

