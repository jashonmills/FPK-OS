import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Calculator, RotateCcw, CheckCircle, AlertTriangle } from 'lucide-react'

const EquationSolver = () => {
  const [equationType, setEquationType] = useState('basic')
  const [selectedEquation, setSelectedEquation] = useState('')
  const [customValue, setCustomValue] = useState(0.5)
  const [solutions, setSolutions] = useState(null)
  const [showSteps, setShowSteps] = useState(false)
  
  const equationTypes = {
    basic: {
      name: 'Basic Equations',
      equations: [
        {
          id: 'sin_half',
          display: 'sin(x) = 1/2',
          func: 'sin',
          value: 0.5,
          solve: () => solveBasicSin(0.5)
        },
        {
          id: 'cos_neg_half',
          display: 'cos(x) = -1/2',
          func: 'cos',
          value: -0.5,
          solve: () => solveBasicCos(-0.5)
        },
        {
          id: 'tan_one',
          display: 'tan(x) = 1',
          func: 'tan',
          value: 1,
          solve: () => solveBasicTan(1)
        },
        {
          id: 'sin_sqrt3_2',
          display: 'sin(x) = √3/2',
          func: 'sin',
          value: Math.sqrt(3)/2,
          solve: () => solveBasicSin(Math.sqrt(3)/2)
        }
      ]
    },
    multiple: {
      name: 'Multiple Angle Equations',
      equations: [
        {
          id: 'sin_2x',
          display: 'sin(2x) = √3/2',
          func: 'sin',
          multiplier: 2,
          value: Math.sqrt(3)/2,
          solve: () => solveMultipleAngle('sin', 2, Math.sqrt(3)/2)
        },
        {
          id: 'cos_3x',
          display: 'cos(3x) = 1/2',
          func: 'cos',
          multiplier: 3,
          value: 0.5,
          solve: () => solveMultipleAngle('cos', 3, 0.5)
        },
        {
          id: 'tan_half_x',
          display: 'tan(x/2) = 1',
          func: 'tan',
          multiplier: 0.5,
          value: 1,
          solve: () => solveMultipleAngle('tan', 0.5, 1)
        }
      ]
    },
    quadratic: {
      name: 'Quadratic Forms',
      equations: [
        {
          id: 'sin_quad',
          display: '2sin²(x) - sin(x) - 1 = 0',
          solve: () => solveQuadraticSin()
        },
        {
          id: 'cos_quad',
          display: 'cos²(x) + cos(x) - 2 = 0',
          solve: () => solveQuadraticCos()
        },
        {
          id: 'mixed_quad',
          display: 'sin²(x) + cos(x) = 1',
          solve: () => solveMixedQuadratic()
        }
      ]
    }
  }
  
  const solveBasicSin = (value) => {
    if (Math.abs(value) > 1) {
      return {
        solutions: [],
        steps: [`sin(x) = ${value}`, 'No solution: sine values must be between -1 and 1'],
        error: 'No solution exists'
      }
    }
    
    const refAngle = Math.asin(Math.abs(value)) * 180 / Math.PI
    const solutions = []
    const steps = [
      `sin(x) = ${value.toFixed(4)}`,
      `Reference angle = arcsin(${Math.abs(value).toFixed(4)}) = ${refAngle.toFixed(1)}°`
    ]
    
    if (value >= 0) {
      // Positive sine: Quadrants I and II
      solutions.push(refAngle, 180 - refAngle)
      steps.push(`Sine is positive in Quadrants I and II`)
      steps.push(`Solutions: x = ${refAngle.toFixed(1)}°, ${(180 - refAngle).toFixed(1)}°`)
    } else {
      // Negative sine: Quadrants III and IV
      solutions.push(180 + refAngle, 360 - refAngle)
      steps.push(`Sine is negative in Quadrants III and IV`)
      steps.push(`Solutions: x = ${(180 + refAngle).toFixed(1)}°, ${(360 - refAngle).toFixed(1)}°`)
    }
    
    steps.push(`General solution: x = ${solutions[0].toFixed(1)}° + 360°n, x = ${solutions[1].toFixed(1)}° + 360°n`)
    
    return { solutions, steps, period: 360 }
  }
  
  const solveBasicCos = (value) => {
    if (Math.abs(value) > 1) {
      return {
        solutions: [],
        steps: [`cos(x) = ${value}`, 'No solution: cosine values must be between -1 and 1'],
        error: 'No solution exists'
      }
    }
    
    const refAngle = Math.acos(Math.abs(value)) * 180 / Math.PI
    const solutions = []
    const steps = [
      `cos(x) = ${value.toFixed(4)}`,
      `Reference angle = arccos(${Math.abs(value).toFixed(4)}) = ${refAngle.toFixed(1)}°`
    ]
    
    if (value >= 0) {
      // Positive cosine: Quadrants I and IV
      solutions.push(refAngle, 360 - refAngle)
      steps.push(`Cosine is positive in Quadrants I and IV`)
      steps.push(`Solutions: x = ${refAngle.toFixed(1)}°, ${(360 - refAngle).toFixed(1)}°`)
    } else {
      // Negative cosine: Quadrants II and III
      solutions.push(180 - refAngle, 180 + refAngle)
      steps.push(`Cosine is negative in Quadrants II and III`)
      steps.push(`Solutions: x = ${(180 - refAngle).toFixed(1)}°, ${(180 + refAngle).toFixed(1)}°`)
    }
    
    steps.push(`General solution: x = ${solutions[0].toFixed(1)}° + 360°n, x = ${solutions[1].toFixed(1)}° + 360°n`)
    
    return { solutions, steps, period: 360 }
  }
  
  const solveBasicTan = (value) => {
    const refAngle = Math.atan(Math.abs(value)) * 180 / Math.PI
    const solutions = []
    const steps = [
      `tan(x) = ${value.toFixed(4)}`,
      `Reference angle = arctan(${Math.abs(value).toFixed(4)}) = ${refAngle.toFixed(1)}°`
    ]
    
    if (value >= 0) {
      // Positive tangent: Quadrants I and III
      solutions.push(refAngle, 180 + refAngle)
      steps.push(`Tangent is positive in Quadrants I and III`)
      steps.push(`Solutions in [0°, 360°): x = ${refAngle.toFixed(1)}°, ${(180 + refAngle).toFixed(1)}°`)
    } else {
      // Negative tangent: Quadrants II and IV
      solutions.push(180 - refAngle, 360 - refAngle)
      steps.push(`Tangent is negative in Quadrants II and IV`)
      steps.push(`Solutions in [0°, 360°): x = ${(180 - refAngle).toFixed(1)}°, ${(360 - refAngle).toFixed(1)}°`)
    }
    
    steps.push(`General solution: x = ${solutions[0].toFixed(1)}° + 180°n (tangent has period 180°)`)
    
    return { solutions, steps, period: 180 }
  }
  
  const solveMultipleAngle = (func, multiplier, value) => {
    let basicSolution
    if (func === 'sin') {
      basicSolution = solveBasicSin(value)
    } else if (func === 'cos') {
      basicSolution = solveBasicCos(value)
    } else if (func === 'tan') {
      basicSolution = solveBasicTan(value)
    }
    
    if (basicSolution.error) {
      return basicSolution
    }
    
    const steps = [
      `${func}(${multiplier}x) = ${value.toFixed(4)}`,
      `Let u = ${multiplier}x, so ${func}(u) = ${value.toFixed(4)}`,
      ...basicSolution.steps.slice(1),
      `Therefore: ${multiplier}x = ${basicSolution.solutions.map(s => s.toFixed(1) + '°').join(', ')}`
    ]
    
    const solutions = basicSolution.solutions.map(s => s / multiplier)
    steps.push(`Dividing by ${multiplier}: x = ${solutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    
    const newPeriod = basicSolution.period / multiplier
    steps.push(`Period is now ${newPeriod}° (divided by ${multiplier})`)
    
    return { solutions, steps, period: newPeriod }
  }
  
  const solveQuadraticSin = () => {
    const steps = [
      '2sin²(x) - sin(x) - 1 = 0',
      'Let u = sin(x): 2u² - u - 1 = 0',
      'Factor: (2u + 1)(u - 1) = 0',
      'Solutions: u = -1/2 or u = 1',
      'Therefore: sin(x) = -1/2 or sin(x) = 1'
    ]
    
    const sol1 = solveBasicSin(-0.5)
    const sol2 = solveBasicSin(1)
    
    const allSolutions = [...sol1.solutions, ...sol2.solutions]
    steps.push(`From sin(x) = -1/2: x = ${sol1.solutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    steps.push(`From sin(x) = 1: x = ${sol2.solutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    steps.push(`All solutions: x = ${allSolutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    
    return { solutions: allSolutions, steps, period: 360 }
  }
  
  const solveQuadraticCos = () => {
    const steps = [
      'cos²(x) + cos(x) - 2 = 0',
      'Let u = cos(x): u² + u - 2 = 0',
      'Factor: (u + 2)(u - 1) = 0',
      'Solutions: u = -2 or u = 1',
      'cos(x) = -2 (impossible) or cos(x) = 1'
    ]
    
    const sol = solveBasicCos(1)
    steps.push(`From cos(x) = 1: x = ${sol.solutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    steps.push('Note: cos(x) = -2 has no solution since -1 ≤ cos(x) ≤ 1')
    
    return { solutions: sol.solutions, steps, period: 360 }
  }
  
  const solveMixedQuadratic = () => {
    const steps = [
      'sin²(x) + cos(x) = 1',
      'Use identity sin²(x) = 1 - cos²(x):',
      '1 - cos²(x) + cos(x) = 1',
      'Simplify: -cos²(x) + cos(x) = 0',
      'Factor: cos(x)(-cos(x) + 1) = 0',
      'Solutions: cos(x) = 0 or cos(x) = 1'
    ]
    
    const sol1 = solveBasicCos(0)
    const sol2 = solveBasicCos(1)
    
    const allSolutions = [...sol1.solutions, ...sol2.solutions]
    steps.push(`From cos(x) = 0: x = ${sol1.solutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    steps.push(`From cos(x) = 1: x = ${sol2.solutions.map(s => s.toFixed(1) + '°').join(', ')}`)
    
    return { solutions: allSolutions, steps, period: 360 }
  }
  
  const solveCustomEquation = () => {
    if (selectedEquation) {
      const equation = equationTypes[equationType].equations.find(eq => eq.id === selectedEquation)
      if (equation) {
        const result = equation.solve()
        setSolutions(result)
        setShowSteps(true)
      }
    }
  }
  
  const reset = () => {
    setSolutions(null)
    setShowSteps(false)
    setSelectedEquation('')
  }
  
  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-6 w-6" />
          Interactive Equation Solver
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Controls */}
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Label>Equation Type</Label>
              <Select value={equationType} onValueChange={setEquationType}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(equationTypes).map(([key, type]) => (
                    <SelectItem key={key} value={key}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Select Equation</Label>
              <Select value={selectedEquation} onValueChange={setSelectedEquation}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Choose an equation" />
                </SelectTrigger>
                <SelectContent>
                  {equationTypes[equationType].equations.map((eq) => (
                    <SelectItem key={eq.id} value={eq.id}>
                      {eq.display}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end gap-2">
              <Button 
                onClick={solveCustomEquation} 
                disabled={!selectedEquation}
                className="flex items-center gap-2"
              >
                <Calculator className="h-4 w-4" />
                Solve
              </Button>
              <Button onClick={reset} variant="outline" className="flex items-center gap-2">
                <RotateCcw className="h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          
          {/* Current Equation Display */}
          {selectedEquation && (
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-blue-700">Current Equation</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge variant="outline" className="text-xl px-4 py-2 font-mono">
                  {equationTypes[equationType].equations.find(eq => eq.id === selectedEquation)?.display}
                </Badge>
              </CardContent>
            </Card>
          )}
          
          {/* Solutions */}
          {solutions && (
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {solutions.error ? (
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                  ) : (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  )}
                  Solution Results
                </CardTitle>
              </CardHeader>
              <CardContent>
                {solutions.error ? (
                  <Alert>
                    <AlertDescription>{solutions.error}</AlertDescription>
                  </Alert>
                ) : (
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 bg-green-50 rounded">
                        <h4 className="font-semibold text-green-700 mb-2">Solutions in [0°, 360°):</h4>
                        <div className="space-y-1">
                          {solutions.solutions.map((sol, index) => (
                            <Badge key={index} variant="outline" className="mr-2">
                              x = {sol.toFixed(1)}°
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="p-4 bg-blue-50 rounded">
                        <h4 className="font-semibold text-blue-700 mb-2">General Solution:</h4>
                        <p className="text-sm">
                          Add multiples of {solutions.period}° to each solution for the complete solution set.
                        </p>
                      </div>
                    </div>
                    
                    {showSteps && (
                      <div className="p-4 bg-gray-50 rounded">
                        <h4 className="font-semibold mb-3">Step-by-step Solution:</h4>
                        <div className="space-y-2">
                          {solutions.steps.map((step, index) => (
                            <div key={index} className="flex items-start gap-2">
                              <span className="text-sm text-gray-500 mt-1">{index + 1}.</span>
                              <span className="text-sm font-mono">{step}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <Button
                      variant="outline"
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full"
                    >
                      {showSteps ? 'Hide' : 'Show'} Solution Steps
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          
          {/* Quick Reference */}
          <Card className="bg-indigo-50 border-indigo-200">
            <CardHeader>
              <CardTitle className="text-indigo-700">Solution Strategy Reference</CardTitle>
            </CardHeader>
            <CardContent className="text-indigo-700">
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <h4 className="font-semibold mb-2">Basic Equations:</h4>
                  <ul className="space-y-1">
                    <li>1. Find reference angle</li>
                    <li>2. Determine correct quadrants</li>
                    <li>3. Apply period properties</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Multiple Angles:</h4>
                  <ul className="space-y-1">
                    <li>1. Substitute u = nx</li>
                    <li>2. Solve basic equation</li>
                    <li>3. Divide by n</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Quadratic Forms:</h4>
                  <ul className="space-y-1">
                    <li>1. Use identities to simplify</li>
                    <li>2. Factor or use quadratic formula</li>
                    <li>3. Solve resulting basic equations</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Practice Problems */}
          <Card className="bg-yellow-50 border-yellow-200">
            <CardHeader>
              <CardTitle className="text-yellow-700">Practice Problems</CardTitle>
            </CardHeader>
            <CardContent className="text-yellow-700">
              <div className="space-y-2 text-sm">
                <p>1. <strong>Try solving:</strong> cos(x) = √2/2</p>
                <p>2. <strong>Challenge:</strong> sin(3x) = -1/2</p>
                <p>3. <strong>Advanced:</strong> 2cos²(x) + 3cos(x) + 1 = 0</p>
                <p>4. <strong>Mixed:</strong> sin²(x) - cos²(x) = 1/2</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}

export default EquationSolver

