import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { BookOpen } from 'lucide-react'

const Lesson5 = ({ onComplete, onNext }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <BookOpen className="h-6 w-6 text-blue-600" />
          <h1 className="text-3xl font-bold">Lesson 5: Special Cases and Applications</h1>
        </div>
        <p className="text-gray-600">Handle fractions, decimals, and real-world problems</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Special Cases in Linear Equations</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Content for special cases and applications will be implemented here.</p>
          <div className="flex justify-between mt-8">
            <Button variant="outline" disabled>Previous</Button>
            <Button onClick={() => { onComplete(); onNext(); }} className="bg-green-600 hover:bg-green-700">
              Complete Lesson
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Lesson5

