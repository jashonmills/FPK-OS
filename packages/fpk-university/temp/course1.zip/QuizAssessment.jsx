import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { CheckCircle, XCircle, Trophy, RotateCcw, Clock } from 'lucide-react'

const QuizAssessment = ({ questions, masteryScore = 70, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  const [timeElapsed, setTimeElapsed] = useState(0)
  const [startTime] = useState(Date.now())

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeElapsed(Math.floor((Date.now() - startTime) / 1000))
    }, 1000)
    return () => clearInterval(timer)
  }, [startTime])

  const defaultQuestions = [
    {
      id: 1,
      question: "Solve: x + 7 = 15",
      type: "input",
      answer: 8,
      explanation: "Subtract 7 from both sides: x + 7 - 7 = 15 - 7, so x = 8"
    },
    {
      id: 2,
      question: "Solve: 3x = 21",
      type: "input",
      answer: 7,
      explanation: "Divide both sides by 3: 3x ÷ 3 = 21 ÷ 3, so x = 7"
    },
    {
      id: 3,
      question: "Solve: 2x + 5 = 17",
      type: "input",
      answer: 6,
      explanation: "First subtract 5: 2x = 12, then divide by 2: x = 6"
    },
    {
      id: 4,
      question: "What is the first step to solve: 4x - 8 = 12?",
      type: "multiple",
      options: [
        "Divide both sides by 4",
        "Add 8 to both sides",
        "Subtract 8 from both sides",
        "Multiply both sides by 4"
      ],
      answer: 1,
      explanation: "Add 8 to both sides to undo the subtraction of 8"
    },
    {
      id: 5,
      question: "Solve: x/3 = 9",
      type: "input",
      answer: 27,
      explanation: "Multiply both sides by 3: (x/3) × 3 = 9 × 3, so x = 27"
    }
  ]

  const quizQuestions = questions || defaultQuestions

  const handleAnswer = (value) => {
    setAnswers({
      ...answers,
      [currentQuestion]: value
    })
  }

  const nextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const submitQuiz = () => {
    setShowResults(true)
    if (onComplete) {
      const score = calculateScore()
      onComplete(score, score >= masteryScore)
    }
  }

  const calculateScore = () => {
    let correct = 0
    quizQuestions.forEach((question, index) => {
      const userAnswer = answers[index]
      if (question.type === 'input') {
        if (parseInt(userAnswer) === question.answer) correct++
      } else if (question.type === 'multiple') {
        if (parseInt(userAnswer) === question.answer) correct++
      }
    })
    return Math.round((correct / quizQuestions.length) * 100)
  }

  const getQuestionResult = (questionIndex) => {
    const question = quizQuestions[questionIndex]
    const userAnswer = answers[questionIndex]
    
    if (question.type === 'input') {
      return parseInt(userAnswer) === question.answer
    } else if (question.type === 'multiple') {
      return parseInt(userAnswer) === question.answer
    }
    return false
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const reset = () => {
    setCurrentQuestion(0)
    setAnswers({})
    setShowResults(false)
  }

  if (showResults) {
    const score = calculateScore()
    const passed = score >= masteryScore
    
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className={`h-6 w-6 ${passed ? 'text-yellow-500' : 'text-gray-400'}`} />
            Quiz Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Score summary */}
            <Card className={`border-2 ${passed ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className={`text-4xl font-bold mb-2 ${passed ? 'text-green-600' : 'text-red-600'}`}>
                    {score}%
                  </div>
                  <div className={`text-lg font-semibold mb-2 ${passed ? 'text-green-800' : 'text-red-800'}`}>
                    {passed ? 'Congratulations! You passed!' : 'Keep practicing!'}
                  </div>
                  <div className="text-sm text-gray-600">
                    Mastery score: {masteryScore}% | Time: {formatTime(timeElapsed)}
                  </div>
                  <Badge variant={passed ? 'default' : 'destructive'} className="mt-2">
                    {passed ? 'PASSED' : 'NEEDS IMPROVEMENT'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Question breakdown */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Question Breakdown</h3>
              {quizQuestions.map((question, index) => {
                const isCorrect = getQuestionResult(index)
                const userAnswer = answers[index]
                
                return (
                  <Card key={question.id} className={`border-l-4 ${isCorrect ? 'border-l-green-500' : 'border-l-red-500'}`}>
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-3">
                        {isCorrect ? (
                          <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-600 mt-0.5" />
                        )}
                        <div className="flex-1">
                          <p className="font-semibold mb-2">{question.question}</p>
                          <div className="text-sm space-y-1">
                            <p>Your answer: <span className={isCorrect ? 'text-green-600' : 'text-red-600'}>
                              {question.type === 'multiple' ? question.options[userAnswer] : userAnswer || 'No answer'}
                            </span></p>
                            {!isCorrect && (
                              <p>Correct answer: <span className="text-green-600">
                                {question.type === 'multiple' ? question.options[question.answer] : question.answer}
                              </span></p>
                            )}
                            <p className="text-gray-600 italic">{question.explanation}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="flex justify-center">
              <Button onClick={reset} className="bg-blue-600 hover:bg-blue-700">
                <RotateCcw className="h-4 w-4 mr-2" />
                Retake Quiz
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const currentQ = quizQuestions[currentQuestion]
  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-6 w-6 text-blue-600" />
            Assessment Quiz
          </CardTitle>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {formatTime(timeElapsed)}
            </div>
            <Badge variant="outline">
              Question {currentQuestion + 1} of {quizQuestions.length}
            </Badge>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Progress</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <Card className="border-2 border-blue-200">
            <CardHeader>
              <CardTitle className="text-lg">{currentQ.question}</CardTitle>
            </CardHeader>
            <CardContent>
              {currentQ.type === 'input' ? (
                <div className="space-y-4">
                  <Input
                    type="number"
                    placeholder="Enter your answer"
                    value={answers[currentQuestion] || ''}
                    onChange={(e) => handleAnswer(e.target.value)}
                    className="text-lg text-center"
                  />
                </div>
              ) : (
                <div className="space-y-3">
                  {currentQ.options.map((option, index) => (
                    <Button
                      key={index}
                      variant={answers[currentQuestion] === index ? "default" : "outline"}
                      className="w-full justify-start text-left h-auto p-4"
                      onClick={() => handleAnswer(index)}
                    >
                      <span className="font-semibold mr-3">{String.fromCharCode(65 + index)}.</span>
                      {option}
                    </Button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={prevQuestion}
              disabled={currentQuestion === 0}
            >
              Previous
            </Button>
            
            <div className="flex gap-2">
              {currentQuestion === quizQuestions.length - 1 ? (
                <Button
                  onClick={submitQuiz}
                  disabled={Object.keys(answers).length !== quizQuestions.length}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Submit Quiz
                </Button>
              ) : (
                <Button
                  onClick={nextQuestion}
                  disabled={answers[currentQuestion] === undefined}
                >
                  Next Question
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default QuizAssessment

