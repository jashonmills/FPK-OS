                  {[0, 30, 45, 60, 90, 180, 270].map(presetAngle => (
                    <Button
                      key={presetAngle}
                      variant="outline"
                      size="sm"
                      onClick={() => setAngle(presetAngle)}
                    >
                      {presetAngle}°
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Information Panel */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
