import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { RotateCcw } from 'lucide-react'

const BalanceScale = ({ leftSide = [], rightSide = [], onUpdate }) => {
  const [draggedItem, setDraggedItem] = useState(null)

  const calculateWeight = (side) => {
    return side.reduce((total, item) => {
      if (item.type === 'variable') return total + (item.value || 1)
      return total + item.value
    }, 0)
  }

  const leftWeight = calculateWeight(leftSide)
  const rightWeight = calculateWeight(rightSide)
  const isBalanced = leftWeight === rightWeight

  const getScaleRotation = () => {
    const diff = leftWeight - rightWeight
    const maxRotation = 15
    return Math.max(-maxRotation, Math.min(maxRotation, diff * 3))
  }

  const renderSideContent = (side, sideLabel) => {
    return (
      <div className="flex flex-wrap gap-2 min-h-[60px] p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
        {side.map((item, index) => (
          <Badge
            key={index}
            variant={item.type === 'variable' ? 'default' : 'secondary'}
            className="text-lg px-3 py-1 cursor-move"
            draggable
            onDragStart={() => setDraggedItem({ item, side: sideLabel, index })}
          >
            {item.type === 'variable' ? `${item.coefficient || 1}x` : item.value}
          </Badge>
        ))}
        {side.length === 0 && (
          <span className="text-gray-400 italic">Drop items here</span>
        )}
      </div>
    )
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Interactive Balance Scale</span>
          <div className="flex items-center gap-2">
            <Badge variant={isBalanced ? 'default' : 'destructive'}>
              {isBalanced ? 'Balanced' : 'Unbalanced'}
            </Badge>
            <Button size="sm" variant="outline">
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Scale visualization */}
          <div className="relative">
            <div className="flex justify-center mb-4">
              <div className="w-4 h-8 bg-gray-800 rounded-t"></div>
            </div>
            
            <div 
              className="relative transition-transform duration-300"
              style={{ transform: `rotate(${getScaleRotation()}deg)` }}
            >
              <div className="h-2 bg-gray-800 w-full rounded"></div>
              
              {/* Left pan */}
              <div className="absolute left-0 top-0 transform -translate-x-1/2 -translate-y-full">
                <div className="w-32 h-16 bg-gradient-to-b from-yellow-300 to-yellow-400 rounded-full border-2 border-yellow-600 flex items-center justify-center">
                  <span className="font-bold text-yellow-800">{leftWeight}</span>
                </div>
                <div className="w-1 h-8 bg-gray-600 mx-auto"></div>
              </div>
              
              {/* Right pan */}
              <div className="absolute right-0 top-0 transform translate-x-1/2 -translate-y-full">
                <div className="w-32 h-16 bg-gradient-to-b from-yellow-300 to-yellow-400 rounded-full border-2 border-yellow-600 flex items-center justify-center">
                  <span className="font-bold text-yellow-800">{rightWeight}</span>
                </div>
                <div className="w-1 h-8 bg-gray-600 mx-auto"></div>
              </div>
            </div>
          </div>

          {/* Equation display */}
          <div className="text-center">
            <div className="text-2xl font-mono bg-white p-4 rounded-lg border">
              <span className="text-blue-600">
                {leftSide.map((item, i) => (
                  <span key={i}>
                    {i > 0 && ' + '}
                    {item.type === 'variable' ? `${item.coefficient || 1}x` : item.value}
                  </span>
                )) || '0'}
              </span>
              <span className="mx-4">=</span>
              <span className="text-green-600">
                {rightSide.map((item, i) => (
                  <span key={i}>
                    {i > 0 && ' + '}
                    {item.type === 'variable' ? `${item.coefficient || 1}x` : item.value}
                  </span>
                )) || '0'}
              </span>
            </div>
          </div>

          {/* Left side */}
          <div>
            <h4 className="font-semibold mb-2">Left Side</h4>
            {renderSideContent(leftSide, 'left')}
          </div>

          {/* Right side */}
          <div>
            <h4 className="font-semibold mb-2">Right Side</h4>
            {renderSideContent(rightSide, 'right')}
          </div>

          {/* Available items */}
          <div>
            <h4 className="font-semibold mb-2">Available Items</h4>
            <div className="flex flex-wrap gap-2 p-4 bg-blue-50 rounded-lg">
              <Badge variant="default" className="cursor-move" draggable>x</Badge>
              <Badge variant="secondary" className="cursor-move" draggable>1</Badge>
              <Badge variant="secondary" className="cursor-move" draggable>2</Badge>
              <Badge variant="secondary" className="cursor-move" draggable>3</Badge>
              <Badge variant="secondary" className="cursor-move" draggable>5</Badge>
              <Badge variant="secondary" className="cursor-move" draggable>10</Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default BalanceScale

